# MEGA Cluster Android

Application Android open source qui regroupe plusieurs comptes MEGA dans un seul espace virtuel grâce à rclone Union.

## Ce que fait cette version

- ajoute plusieurs comptes MEGA ;
- crée automatiquement le remote `mega-cluster:` avec rclone Union ;
- expose ce remote comme `DocumentsProvider` Android ;
- permet aux sélecteurs de fichiers Android de voir **MEGA Cluster** ;
- prend en charge la navigation, création de dossiers, création de fichiers, lecture, écriture, suppression et renommage.

## Important

Cette version utilise rclone `v1.75.1` et sa bibliothèque gomobile officielle. Le mot de passe MEGA est stocké dans le fichier de configuration rclone privé à l'application. Une version ultérieure pourra déplacer les secrets vers Android Keystore.

Le backend MEGA de rclone demande actuellement les paramètres `user` et `pass`; l'option `2fa` est affichée dans l'interface si elle est acceptée par la version de rclone utilisée.

## Compilation sans PC

Le workflow GitHub Actions construit automatiquement `librclone.aar`, puis l'APK debug.

1. Importer le contenu de ce projet dans le dépôt GitHub.
2. Ouvrir **Actions**.
3. Choisir **Build APK**.
4. Cliquer **Run workflow**.
5. À la fin, ouvrir l'artefact **MegaCluster-debug-apk** et récupérer `app-debug.apk`.

Le projet est prévu pour un téléphone Android 64 bits moderne, notamment un Galaxy A56.


## Streaming v26

Le streaming vidéo utilise `rclone serve/http` avec VFS full. Le workflow doit importer `cmd/serve` dans librclone afin que `serve/start` soit disponible dans l’AAR.
