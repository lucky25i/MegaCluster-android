package com.example.megacluster

import android.content.Context
import org.json.JSONObject
import org.rclone.gomobile.Gomobile
import java.io.File

/** Small, synchronous wrapper around rclone's official gomobile RPC API. */
object Rclone {
    @Volatile private var initialized = false

    @Synchronized
    fun init(context: Context) {
        if (initialized) return

        val configDir = File(context.filesDir, "rclone")
        configDir.mkdirs()
        val configFile = File(configDir, "rclone.conf")

        Gomobile.rcloneInitialize()
        initialized = true
        call("config/setpath", JSONObject().put("path", configFile.absolutePath))
    }

    @Synchronized
    fun call(method: String, input: JSONObject = JSONObject()): JSONObject {
        check(initialized) { "rclone n'est pas initialisé" }
        val result = Gomobile.rcloneRPC(method, input.toString())
        val status = result.getStatus()
        val output = result.getOutput() ?: ""
        if (status != 200L) {
            throw IllegalStateException("$method ($status): $output")
        }
        return if (output.isBlank()) JSONObject() else JSONObject(output)
    }


    fun configPath(context: Context): String {
        return File(context.filesDir, "rclone/rclone.conf").absolutePath
    }

    fun nativeExecutablePath(context: Context): String {
        return File(context.applicationInfo.nativeLibraryDir, "librclone_exec.so").absolutePath
    }

    @Synchronized
    fun close() {
        // Do not finalize rclone from an Activity lifecycle callback: the
        // DocumentsProvider can outlive the Activity. The process owns rclone.
    }
}
