package com.example.megacluster

import android.widget.ImageView
import android.widget.FrameLayout
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import java.net.HttpURLConnection
import java.net.URLEncoder
import androidx.core.view.WindowCompat
import android.os.Bundle
import android.provider.DocumentsContract
import android.webkit.MimeTypeMap
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.drawable.Animatable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.GestureDetector
import android.widget.Button
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.HorizontalScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.File
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.OnBackPressedCallback
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var accounts: LinearLayout
    private val background = Executors.newSingleThreadExecutor()
    private val validationDelayMs = 3500L
    private var explorerOpen = false
    private var explorerPath = ""
    private var explorerRemote: String? = null
    private var explorerSort = "name"
    private var explorerSortAsc = true
    private var explorerFilter = "all"
    private var explorerSearchQuery = ""
    private var accountSort = "name"
    private var accountSortAsc = true
    private val explorerCache = mutableMapOf<String, List<ExplorerItem>>()
    private var mediaViewerRoot: View? = null
    private var mediaItems: List<ExplorerItem> = emptyList()
    private var mediaIndex = -1
    private var mediaPath = ""
    private var mediaRemote: String? = null
    private val mediaPrefetch = mutableMapOf<String, File>()

    // Local rclone HTTP/VFS server used for seekable video streaming.
    private var mediaServerId: String? = null
    private var mediaServerPort: Int? = null
    private var mediaServerFs: String? = null
    private val accountUsageCache = mutableMapOf<String, Int?>()
    private val mediaCacheMaxAgeMs = 6L * 60L * 60L * 1000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Rclone.init(this)
        cleanupMediaCache()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (mediaViewerRoot != null) {
                    closeMediaViewer()
                } else if (explorerOpen) {
                    if (explorerPath.isNotBlank()) {
                        val parent = explorerPath.substringBeforeLast('/', "")
                        openExplorer(parent, explorerRemote)
                    } else {
                        buildUi()
                        refreshAccounts()
                    }
                } else {
                    finish()
                }
            }
        })
        buildUi()
        refreshAccounts()
    }

    override fun onDestroy() {
        try {
            mediaServerId?.let { Rclone.call("serve/stop", JSONObject().put("id", it)) }
        } catch (_: Exception) { }
        mediaServerId = null
        mediaServerPort = null
        mediaServerFs = null
        background.shutdownNow()
        super.onDestroy()
    }

    private fun buildUi() {
        explorerOpen = false
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }
        root.addView(TextView(this).apply { text = "MEGA Cluster"; textSize = 30f })
        root.addView(TextView(this).apply {
            text = "Plusieurs comptes MEGA dans un seul espace"
            textSize = 15f
            setPadding(0, 4, 0, 20)
        })
        status = TextView(this).apply { text = "Initialisation…"; textSize = 16f }
        root.addView(status)

        root.addView(primaryButton("➕ Ajouter un compte MEGA") { addMegaDialog() })
        root.addView(primaryButton("📁 Explorer le cluster") { openExplorer("") })
        root.addView(primaryButton("🔄 Tester les comptes un par un") { validateAllStoredAccounts() })
        root.addView(primaryButton("🔧 Reconstruire le cluster") { rebuildUnion() })

        val advanced = Button(this).apply {
            text = "Outils Android / diagnostic"
            setOnClickListener { openDiagnosticsMenu() }
        }
        root.addView(advanced)

        root.addView(TextView(this).apply {
            text = "Comptes enregistrés"
            textSize = 21f
            setPadding(0, 24, 0, 10)
        })
        accounts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(accounts)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun primaryButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        setOnClickListener { action() }
    }

    private fun addMegaDialog(prefill: CredentialStore.Account? = null, cloneFrom: CredentialStore.Account? = null) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 0, 20, 0)
        }
        val displayName = EditText(this).apply {
            hint = "Nom du compte (ex. Compte 1)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setText(prefill?.displayName ?: cloneFrom?.let { "${it.displayName} - copie" } ?: "")
        }
        val email = EditText(this).apply {
            hint = "E-mail MEGA"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            setText(prefill?.email ?: cloneFrom?.email ?: "")
        }
        val pass = passwordEditor("Mot de passe", prefill?.password ?: cloneFrom?.password ?: "")
        val twofa = EditText(this).apply {
            hint = "2FA (si nécessaire)"
            inputType = InputType.TYPE_CLASS_TEXT
            setText(prefill?.twoFa ?: cloneFrom?.twoFa ?: "")
        }
        box.addView(displayName)
        box.addView(email)
        box.addView(pass)
        box.addView(twofa)

        val title = when {
            cloneFrom != null -> "Cloner ${cloneFrom.email}"
            prefill != null -> "Modifier le compte"
            else -> "Nouveau compte MEGA"
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton(if (prefill == null && cloneFrom == null) "Tester et ajouter" else "Tester et enregistrer", null)
            .setNegativeButton("Annuler", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val n = displayName.text.toString().trim()
                val e = email.text.toString().trim()
                val p = pass.text.toString()
                val t = twofa.text.toString().trim()
                if (n.isBlank() || e.isBlank() || p.isBlank()) {
                    Toast.makeText(this, "Nom, e-mail et mot de passe obligatoires.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = false
                val remoteToUpdate = if (cloneFrom != null) null else prefill?.remote
                validateAndSave(n, e, p, t, remoteToUpdate, cloneFrom != null) {
                    dialog.dismiss()
                }
            }
        }
        dialog.show()
    }

    private fun passwordEditor(hint: String, value: String): EditText {
        return EditText(this).apply {
            this.hint = hint
            setText(value)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setCompoundDrawablesWithIntrinsicBounds(0, 0, android.R.drawable.ic_menu_view, 0)
            setOnTouchListener { v, event ->
                if (event.action == android.view.MotionEvent.ACTION_UP && event.rawX >= right - 80) {
                    inputType = if (inputType and InputType.TYPE_TEXT_VARIATION_PASSWORD != 0) {
                        InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    } else {
                        InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                    }
                    setSelection(text.length)
                    true
                } else false
            }
        }
    }

    private fun validateAndSave(
        displayName: String,
        email: String,
        password: String,
        twoFa: String,
        existingRemote: String?,
        isClone: Boolean,
        success: () -> Unit
    ) {
        status.text = "Test de connexion MEGA en cours…"
        background.execute {
            val remote = existingRemote ?: "mega${nextIndex()}"
            var created = false
            try {
                if (existingRemote == null) {
                    createMegaRemote(remote, email, password, twoFa)
                    created = true
                } else {
                    Rclone.call(
                        "config/update",
                        JSONObject()
                            .put("name", remote)
                            .put("parameters", JSONObject().put("user", email).put("pass", password).apply {
                                if (twoFa.isNotBlank()) put("2fa", twoFa) else remove("2fa")
                            })
                    )
                }
                testRemote(remote)
                CredentialStore.upsert(this, CredentialStore.Account(remote, displayName, email, password, twoFa))
                accountUsageCache.remove(remote)
                safeDisconnect(remote)
                runOnUiThread {
                    status.text = "Compte validé : $email"
                    refreshAccounts()
                    if (isClone) Toast.makeText(this, "Compte cloné et validé.", Toast.LENGTH_LONG).show()
                    success()
                }
            } catch (e: Exception) {
                safeDisconnect(remote)
                if (created) {
                    try { Rclone.call("config/delete", JSONObject().put("name", remote)) } catch (_: Exception) {}
                }
                runOnUiThread {
                    status.text = "Connexion refusée pour $email"
                    Toast.makeText(this, "❌ Connexion impossible : ${cleanError(e)}\n\nLe compte n'a pas été enregistré.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun createMegaRemote(name: String, email: String, password: String, twoFa: String) {
        val parameters = JSONObject().put("user", email).put("pass", password)
        if (twoFa.isNotBlank()) parameters.put("2fa", twoFa)
        Rclone.call(
            "config/create",
            JSONObject().put("name", name).put("type", "mega").put("parameters", parameters)
        )
    }

    private fun testRemote(remote: String) {
        // A real remote operation forces rclone to authenticate with MEGA.
        Rclone.call("operations/about", JSONObject().put("fs", "$remote:"))
    }

    private fun safeDisconnect(remote: String) {
        try { Rclone.call("config/disconnect", JSONObject().put("name", "$remote:")) } catch (_: Exception) {}
        // rclone documents that successive MEGA logins can trigger blocking; leave a pause.
        try { Thread.sleep(validationDelayMs) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
    }

    private fun validateAllStoredAccounts() {
        val list = CredentialStore.load(this).filter { it.password.isNotBlank() }
        if (list.isEmpty()) {
            Toast.makeText(this, "Aucun compte avec un mot de passe enregistré à tester.", Toast.LENGTH_LONG).show()
            return
        }
        status.text = "Validation séquentielle : 0/${list.size}"
        background.execute {
            var valid = 0
            list.forEachIndexed { index, account ->
                if (Thread.currentThread().isInterrupted) return@forEachIndexed
                runOnUiThread { status.text = "Test ${index + 1}/${list.size} : ${account.email}" }
                try {
                    testRemote(account.remote)
                    valid++
                    runOnUiThread { status.text = "✓ ${account.email} — ${index + 1}/${list.size}" }
                } catch (_: Exception) {
                    runOnUiThread { status.text = "✗ ${account.email} — ${index + 1}/${list.size}" }
                } finally {
                    safeDisconnect(account.remote)
                }
            }
            runOnUiThread {
                status.text = "$valid/${list.size} compte(s) valide(s)"
                refreshAccounts()
                if (valid >= 2) rebuildUnion() else Toast.makeText(this, "Il faut au moins 2 comptes valides pour le cluster.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun refreshAccounts() {
        try {
            val remotes = Rclone.call("config/listremotes").optJSONArray("remotes") ?: JSONArray()
            val saved = CredentialStore.load(this)
            accounts.removeAllViews()
            val names = mutableListOf<String>()
            for (i in 0 until remotes.length()) {
                val name = remotes.getString(i).removeSuffix(":")
                if (name.startsWith("mega") && name != "mega-cluster") names += name
            }
            if (names.isEmpty()) {
                accounts.addView(TextView(this).apply { text = "Aucun compte configuré."; setPadding(0, 8, 0, 8) })
            }
            names.sorted().forEach { name ->
                val account = saved.firstOrNull { it.remote == name }
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(16, 14, 16, 14)
                    setBackgroundResource(android.R.drawable.dialog_holo_light_frame)
                }
                card.addView(TextView(this).apply {
                    text = "☁ ${account?.displayName ?: account?.email ?: name}"
                    textSize = 18f
                    setTextColor(Color.WHITE)
                })
                card.addView(TextView(this).apply {
                    text = if (account?.password?.isNotBlank() == true) "🔐 Mot de passe enregistré" else "🔐 Mot de passe à renseigner pour l'affichage/copie"
                    textSize = 13f
                    setTextColor(Color.WHITE)
                    setPadding(0, 4, 0, 8)
                })
                val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                actions.addView(smallButton("Gérer") { manageAccount(name) })
                actions.addView(smallButton("Cloner") { cloneAccount(name) })
                actions.addView(smallButton("Tester") { validateSingle(name) })
                card.addView(actions)
                accounts.addView(card)
            }
            status.text = "${names.size} compte(s) MEGA configuré(s)"
        } catch (e: Exception) {
            status.text = "Erreur : ${e.message}"
        }
    }

    private fun smallButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        setTextSize(12f)
        setOnClickListener { action() }
    }

    private fun manageAccount(remote: String) {
        val account = CredentialStore.find(this, remote)
        if (account == null) {
            AlertDialog.Builder(this)
                .setTitle("Compte $remote")
                .setMessage("Ce compte a été créé avec une ancienne version de l'application. Pour activer l'affichage et la copie du mot de passe, renseigne-le une fois.")
                .setPositiveButton("Renseigner") { _, _ -> addMegaDialog(prefill = CredentialStore.Account(remote, remote, "", "")) }
                .setNegativeButton("Fermer", null)
                .show()
            return
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 0, 20, 0) }
        val displayName = EditText(this).apply { setText(account.displayName); hint = "Nom du compte"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES }
        val email = EditText(this).apply { setText(account.email); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS }
        val pass = passwordEditor("Mot de passe", account.password)
        val copy = Button(this).apply {
            text = "📋 Copier le mot de passe"
            setOnClickListener { copyPassword(pass.text.toString()) }
        }
        box.addView(displayName); box.addView(email); box.addView(pass); box.addView(copy)
        AlertDialog.Builder(this)
            .setTitle("Gérer le compte")
            .setView(box)
            .setPositiveButton("Enregistrer") { _, _ ->
                CredentialStore.upsert(this, account.copy(displayName = displayName.text.toString().trim().ifBlank { email.text.toString().trim() }, email = email.text.toString().trim(), password = pass.text.toString()))
                Toast.makeText(this, "Compte enregistré.", Toast.LENGTH_SHORT).show()
                refreshAccounts()
            }
            .setNeutralButton("Supprimer") { _, _ -> deleteAccount(remote) }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun copyPassword(password: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(
            ClipData.newPlainText("Mot de passe MEGA", password)
        )
        Toast.makeText(this, "Mot de passe copié dans le presse-papier.", Toast.LENGTH_SHORT).show()
    }

    private fun cloneAccount(remote: String) {
        val account = CredentialStore.find(this, remote)
        if (account == null || account.password.isBlank()) {
            Toast.makeText(this, "Renseigne d'abord le mot de passe de ce compte.", Toast.LENGTH_LONG).show()
            manageAccount(remote)
            return
        }
        addMegaDialog(cloneFrom = account)
    }

    private fun validateSingle(remote: String) {
        val account = CredentialStore.find(this, remote)
        if (account == null || account.password.isBlank()) {
            Toast.makeText(this, "Renseigne le mot de passe dans Gérer avant le test.", Toast.LENGTH_LONG).show()
            return
        }
        status.text = "Test de $remote…"
        background.execute {
            try {
                testRemote(remote)
                runOnUiThread { status.text = "✓ ${account.email} : connexion réussie" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "✗ ${account.email} : ${cleanError(e)}" }
            } finally {
                safeDisconnect(remote)
                runOnUiThread { refreshAccounts() }
            }
        }
    }

    private fun deleteAccount(remote: String) {
        try {
            Rclone.call("config/delete", JSONObject().put("name", remote))
            CredentialStore.remove(this, remote)
            accountUsageCache.remove(remote)
            try { Rclone.call("config/disconnect", JSONObject().put("name", "$remote:")) } catch (_: Exception) {}
            refreshAccounts()
            Toast.makeText(this, "Compte supprimé.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, cleanError(e), Toast.LENGTH_LONG).show()
        }
    }

    private fun nextIndex(): Int {
        val remotes = Rclone.call("config/listremotes").optJSONArray("remotes") ?: JSONArray()
        var max = 0
        for (i in 0 until remotes.length()) {
            val name = remotes.getString(i).removeSuffix(":")
            if (name.startsWith("mega") && name != "mega-cluster") {
                name.removePrefix("mega").toIntOrNull()?.let { max = maxOf(max, it) }
            }
        }
        return max + 1
    }

    private fun rebuildUnion() {
        try {
            val remotes = Rclone.call("config/listremotes").optJSONArray("remotes") ?: JSONArray()
            val upstreams = mutableListOf<String>()
            for (i in 0 until remotes.length()) {
                val name = remotes.getString(i).removeSuffix(":")
                if (name.startsWith("mega") && name != "mega-cluster") upstreams += "$name:"
            }
            if (upstreams.size < 2) {
                status.text = "Cluster non créé : il faut au moins 2 comptes MEGA."
                Toast.makeText(this, "Il faut au moins 2 comptes MEGA pour construire le cluster.", Toast.LENGTH_LONG).show()
                return
            }
            try { Rclone.call("config/delete", JSONObject().put("name", "mega-cluster")) } catch (_: Exception) {}
            val parameters = JSONObject()
                .put("upstreams", upstreams.joinToString(" "))
                .put("create_policy", "eplfs")
                .put("action_policy", "epall")
                .put("search_policy", "ff")
            Rclone.call("config/create", JSONObject().put("name", "mega-cluster").put("type", "union").put("parameters", parameters))
            status.text = "Cluster prêt : ${upstreams.size} compte(s)"
        } catch (e: Exception) {
            status.text = "Erreur cluster : ${cleanError(e)}"
        }
    }

    private fun cleanError(e: Exception): String {
        val raw = e.message ?: "Erreur inconnue"
        return raw.replace(Regex("pass(?:word)?\\s*[=:]\\s*[^\\s,}]+", RegexOption.IGNORE_CASE), "password=***")
    }

    private fun openExplorer(path: String, selectedRemote: String? = explorerRemote) {
        explorerOpen = true
        explorerPath = path
        explorerRemote = selectedRemote

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = if (path.isBlank()) "MEGA Cluster" else path.substringAfterLast('/', path).ifBlank { "MEGA Cluster" }
            textSize = 21f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(35, 39, 47))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        header.addView(title)
        header.addView(Button(this).apply {
            text = "↻"
            contentDescription = "Actualiser"
            setOnClickListener {
                explorerCache.remove(explorerCacheKey(explorerPath, explorerRemote))
                openExplorer(explorerPath, explorerRemote)
            }
        })
        root.addView(header)

        if (path.isNotBlank()) {
            root.addView(Button(this).apply {
                text = "‹  Dossier parent"
                setOnClickListener {
                    val parent = path.substringBeforeLast('/', "")
                    openExplorer(parent, explorerRemote)
                }
            })
        }

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        toolbar.addView(TextView(this).apply {
            text = "Trier"
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(55, 65, 81))
            setPadding(dp(4), 0, dp(10), 0)
        })
        val sortSpinner = Spinner(this).apply {
            val options = arrayOf(
                "Nom ↑", "Nom ↓",
                "Type ↑", "Type ↓",
                "Date ↑", "Date ↓",
                "Taille ↑", "Taille ↓"
            )
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, options)
            val current = when (explorerSort to explorerSortAsc) {
                "name" to true -> 0
                "name" to false -> 1
                "type" to true -> 2
                "type" to false -> 3
                "date" to true -> 4
                "date" to false -> 5
                "size" to true -> 6
                else -> 7
            }
            setSelection(current, false)
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (position < 0) return
                    val modes = arrayOf(
                        "name" to true, "name" to false,
                        "type" to true, "type" to false,
                        "date" to true, "date" to false,
                        "size" to true, "size" to false
                    )
                    val selected = modes[position]
                    if (explorerSort != selected.first || explorerSortAsc != selected.second) {
                        explorerSort = selected.first
                        explorerSortAsc = selected.second
                        openExplorer(explorerPath, explorerRemote)
                    }
                }
            }
        }
        toolbar.addView(sortSpinner, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(toolbar)

        val filterScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(0, dp(2), 0, dp(4))
        }
        val filterRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val filters = listOf(
            "all" to "Tout",
            "photo" to "📷 Photos",
            "gif" to "GIF",
            "video" to "🎬 Vidéos",
            "archive" to "ZIP/RAR",
            "audio" to "🎵 Audio",
            "document" to "📄 Documents"
        )
        filters.forEach { (key, label) ->
            filterRow.addView(filterChip(key, label))
        }
        filterScroll.addView(filterRow)
        root.addView(filterScroll)

        val search = EditText(this).apply {
            hint = "🔍 Rechercher dans ce dossier"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
            setText(explorerSearchQuery)
            setSelection(text.length)
        }
        root.addView(search)

        val statusView = TextView(this).apply {
            text = "Lecture du cluster…"
            setPadding(8, 8, 8, 8)
            setTextColor(Color.DKGRAY)
        }
        root.addView(statusView)

        val split = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }

        val accountPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 4, 8, 4)
            setBackgroundResource(android.R.drawable.dialog_holo_light_frame)
            layoutParams = LinearLayout.LayoutParams(dp(145), LinearLayout.LayoutParams.MATCH_PARENT)
        }
        accountPanel.addView(TextView(this).apply {
            text = "COMPTES"
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(8, 8, 4, 8)
        })
        accountPanel.addView(Button(this).apply {
            text = "☁ Tous"
            setTextSize(11f)
            setOnClickListener { openExplorer(explorerPath, null) }
        })
        accountPanel.addView(Button(this).apply {
            text = "Tri: ${accountSortLabel()} ${if (accountSortAsc) "↑" else "↓"}"
            setTextSize(10f)
            setOnClickListener { cycleAccountSort() }
        })
        split.addView(ScrollView(this).apply { addView(accountPanel) })

        val filesScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        }
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        filesScroll.addView(list)
        split.addView(filesScroll)
        root.addView(split)

        root.addView(Button(this).apply {
            text = "← Menu principal"
            setOnClickListener { buildUi(); refreshAccounts() }
        })

        setContentView(root)

        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                explorerSearchQuery = s?.toString()?.trim() ?: ""
                val cachedNow = explorerCache[explorerCacheKey(explorerPath, explorerRemote)]
                if (cachedNow != null) {
                    renderExplorerContent(list, accountPanel, statusView, cachedNow, CredentialStore.load(this@MainActivity), explorerRemote)
                }
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })

        val cacheKey = explorerCacheKey(explorerPath, explorerRemote)
        val cached = explorerCache[cacheKey]
        if (cached != null) {
            renderExplorerContent(list, accountPanel, statusView, cached, CredentialStore.load(this), explorerRemote)
        } else {
            loadExplorerContent(cacheKey, list, accountPanel, statusView, explorerPath, explorerRemote, forceRefresh = false)
        }
    }

    private fun explorerCacheKey(path: String, remote: String?): String = "${remote ?: "__cluster__"}|$path"

    private fun loadExplorerContent(
        cacheKey: String,
        list: LinearLayout,
        accountPanel: LinearLayout,
        statusView: TextView,
        path: String,
        selectedRemote: String?,
        forceRefresh: Boolean
    ) {
        statusView.text = if (forceRefresh) "Actualisation…" else "Lecture du cluster…"
        background.execute {
            val saved = CredentialStore.load(this)
            val usage = mutableMapOf<String, Int?>()
            saved.forEach { account ->
                if (!accountUsageCache.containsKey(account.remote) || forceRefresh) {
                    try {
                        val about = Rclone.call("operations/about", JSONObject().put("fs", "${account.remote}:"))
                        val total = about.optDouble("total", 0.0)
                        val used = about.optDouble("used", 0.0)
                        accountUsageCache[account.remote] = if (total > 0) ((used / total) * 100.0).toInt().coerceIn(0, 100) else null
                    } catch (_: Exception) { accountUsageCache[account.remote] = null }
                    finally { safeDisconnect(account.remote) }
                }
                usage[account.remote] = accountUsageCache[account.remote]
            }
            try {
                val result = Rclone.call(
                    "operations/list",
                    JSONObject()
                        .put("fs", if (selectedRemote == null) "mega-cluster:" else "$selectedRemote:")
                        .put("remote", path)
                        .put("opt", JSONObject().put("filesOnly", false))
                )
                val items = result.optJSONArray("list") ?: JSONArray()
                val models = mutableListOf<ExplorerItem>()
                for (i in 0 until items.length()) {
                    val item = items.getJSONObject(i)
                    val name = item.optString("Name")
                    if (name.isBlank()) continue
                    models += ExplorerItem(
                        name = name,
                        isDir = item.optBoolean("IsDir", false),
                        size = item.optLong("Size", 0L),
                        modTime = item.optString("ModTime", "")
                    )
                }
                explorerCache[cacheKey] = models
                val currentUsage = usage.toMap()
                runOnUiThread {
                    renderExplorerContent(list, accountPanel, statusView, models, saved, selectedRemote, currentUsage)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusView.text = "Erreur lors de la lecture du cluster"
                    list.removeAllViews()
                    list.addView(TextView(this).apply { text = "Impossible de lire cet emplacement:\n${cleanError(e)}"; setPadding(16, 20, 16, 20) })
                }
            }
        }
    }

    private fun renderExplorerContent(
        list: LinearLayout,
        accountPanel: LinearLayout,
        statusView: TextView,
        models: List<ExplorerItem>,
        saved: List<CredentialStore.Account>,
        selectedRemote: String?,
        usageOverride: Map<String, Int?> = emptyMap()
    ) {
        val usage = if (usageOverride.isNotEmpty()) usageOverride else saved.associate { it.remote to accountUsageCache[it.remote] }
        list.removeAllViews()
        if (accountPanel.childCount > 3) accountPanel.removeViews(3, accountPanel.childCount - 3)
        sortAccounts(saved, usage).forEach { account ->
            val percent = usage[account.remote]
            val label = "☁ ${account.displayName}\n${percent?.let { "$it %" } ?: "? %"}"
            accountPanel.addView(Button(this).apply {
                text = label
                setTextSize(10f)
                setTextColor(Color.WHITE)
                setGravity(Gravity.START or Gravity.CENTER_VERTICAL)
                setOnClickListener { openExplorer(explorerPath, account.remote) }
            })
        }
        val searchQuery = explorerSearchQuery.trim().lowercase()
        val filtered = filterExplorerItems(models).filter {
            searchQuery.isBlank() || it.name.lowercase().contains(searchQuery)
        }
        val sorted = sortExplorerItems(filtered)
        statusView.text = "${sorted.size} élément(s)" + if (selectedRemote == null) " • Tous les comptes" else " • ${saved.firstOrNull { it.remote == selectedRemote }?.displayName ?: selectedRemote}"
        sorted.forEach { item ->
            val row = createExplorerItemView(item, explorerPath, selectedRemote)
            row.tag = item.name
            list.addView(row)
        }
        if (sorted.isEmpty()) list.addView(TextView(this).apply { text = "Dossier vide"; setPadding(16, 20, 16, 20) })
    }

    private data class ExplorerItem(val name: String, val isDir: Boolean, val size: Long, val modTime: String)

    private fun accountSortLabel(): String = if (accountSort == "usage") "Occupation" else "Nom"

    private fun cycleAccountSort() {
        if (accountSort == "name" && accountSortAsc) accountSortAsc = false
        else if (accountSort == "name" && !accountSortAsc) { accountSort = "usage"; accountSortAsc = true }
        else if (accountSort == "usage" && accountSortAsc) accountSortAsc = false
        else { accountSort = "name"; accountSortAsc = true }
        openExplorer(explorerPath, explorerRemote)
    }

    private fun sortAccounts(accounts: List<CredentialStore.Account>, usage: Map<String, Int?>): List<CredentialStore.Account> {
        return if (accountSort == "usage") {
            val sorted = accounts.sortedWith(compareBy<CredentialStore.Account> { usage[it.remote] ?: -1 })
            if (accountSortAsc) sorted else sorted.asReversed()
        } else {
            val sorted = accounts.sortedBy { it.displayName.lowercase() }
            if (accountSortAsc) sorted else sorted.asReversed()
        }
    }

    private fun createExplorerItemView(item: ExplorerItem, path: String, remote: String?): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.rgb(248, 249, 251))
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.rgb(225, 229, 235))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            isClickable = true
            isFocusable = true
        }

        val icon = TextView(this).apply {
            text = explorerIcon(item)
            textSize = 27f
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(46), dp(46))
        }
        card.addView(icon)

        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, dp(4), 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        texts.addView(TextView(this).apply {
            text = item.name
            textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(35, 39, 47))
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        val details = if (item.isDir) "Dossier" else "${formatSize(item.size)}  •  ${item.modTime.replace("T", " ").take(16)}"
        texts.addView(TextView(this).apply {
            text = details
            textSize = 12f
            setTextColor(Color.rgb(105, 112, 122))
            setPadding(0, dp(3), 0, 0)
        })
        card.addView(texts)

        card.setOnClickListener {
            if (item.isDir) {
                val next = if (path.isBlank()) item.name else "$path/${item.name}"
                openExplorer(next, remote)
            } else {
                openFileInInstalledApp(item.name, path, remote)
            }
        }
        return card
    }

    private fun filterChip(key: String, label: String): TextView = TextView(this).apply {
        text = label
        textSize = 12.5f
        gravity = Gravity.CENTER
        setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(38)).apply {
            setMargins(dp(3), 0, dp(3), 0)
        }
        refreshFilterChip(this, key)
        setOnClickListener {
            explorerFilter = key
            openExplorer(explorerPath, explorerRemote)
        }
    }

    private fun refreshFilterChip(view: TextView, key: String) {
        val selected = explorerFilter == key
        view.setTextColor(if (selected) Color.WHITE else Color.rgb(55, 65, 81))
        view.background = GradientDrawable().apply {
            setColor(if (selected) Color.rgb(55, 105, 185) else Color.rgb(239, 242, 246))
            cornerRadius = dp(19).toFloat()
        }
    }

    private fun filterExplorerItems(items: List<ExplorerItem>): List<ExplorerItem> {
        if (explorerFilter == "all") return items
        return items.filter { item ->
            if (item.isDir) return@filter false
            when (explorerFilter) {
                "photo" -> extensionOf(item.name) in setOf("jpg", "jpeg", "png", "webp", "bmp", "heic", "heif", "avif")
                "gif" -> extensionOf(item.name) == "gif"
                "video" -> isVideo(item.name)
                "archive" -> extensionOf(item.name) in setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz")
                "audio" -> extensionOf(item.name) in setOf("mp3", "m4a", "aac", "flac", "ogg", "opus", "wav", "wma", "alac")
                "document" -> extensionOf(item.name) in setOf("pdf", "txt", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "csv", "epub", "rtf")
                else -> true
            }
        }
    }

    private fun explorerIcon(item: ExplorerItem): String {
        if (item.isDir) return "📁"
        return when {
            extensionOf(item.name) == "gif" -> "🎞️"
            isVideo(item.name) -> "🎬"
            extensionOf(item.name) in setOf("jpg", "jpeg", "png", "webp", "bmp", "heic", "heif", "avif") -> "🖼️"
            extensionOf(item.name) in setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz") -> "📦"
            extensionOf(item.name) in setOf("mp3", "m4a", "aac", "flac", "ogg", "opus", "wav", "wma", "alac") -> "🎵"
            extensionOf(item.name) in setOf("pdf", "txt", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "csv", "epub", "rtf") -> "📄"
            else -> "📎"
        }
    }

    private fun openFileInInstalledApp(name: String, path: String, remote: String?) {
        val items = explorerCache[explorerCacheKey(path, remote)].orEmpty()
        if (isImage(name)) {
            val photos = items.filter { !it.isDir && isImage(it.name) }
            val index = photos.indexOfFirst { it.name == name }
            if (index >= 0) {
                mediaItems = photos
                mediaIndex = index
                mediaPath = path
                mediaRemote = remote
                openPhotoViewer()
                return
            }
        }
        // Videos and all other files stay with the installed Android apps.
        openFileInInstalledAppExternal(name, path, remote)
    }

    private fun openFileInInstalledAppExternal(name: String, path: String, remote: String?) {
        if (isVideo(name)) {
            openVideoStream(name, path)
            return
        }

        val mime = MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase())
            ?: "application/octet-stream"
        val temp = mediaCacheFile(remote, path, name)
        Toast.makeText(this, "Préparation du fichier…", Toast.LENGTH_SHORT).show()
        background.execute {
            try {
                downloadToCache(name, path, remote, temp)
                runOnUiThread {
                    try {
                        val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", temp)
                        val intent = Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(uri, mime)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            clipData = ClipData.newRawUri("MEGA Cluster", uri)
                        }
                        startActivity(Intent.createChooser(intent, "Ouvrir avec…"))
                    } catch (e: Exception) {
                        Toast.makeText(this, "Impossible d'ouvrir le fichier : ${cleanError(e)}", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                temp.delete()
                runOnUiThread { Toast.makeText(this, "Téléchargement impossible : ${cleanError(e)}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun stopMediaServer() {
        try {
            mediaServerId?.let { Rclone.call("serve/stop", JSONObject().put("id", it)) }
        } catch (_: Exception) { }
        mediaServerId = null
        mediaServerPort = null
        mediaServerFs = null
    }

    private fun ensureMediaServer(path: String, remote: String?): Int {
        val fs = if (remote.isNullOrBlank()) {
            if (path.isBlank()) "mega-cluster:" else "mega-cluster:$path"
        } else {
            if (path.isBlank()) "$remote:" else "$remote:$path"
        }

        if (mediaServerPort != null && mediaServerId != null && mediaServerFs == fs) {
            return mediaServerPort!!
        }
        stopMediaServer()

        val cacheDir = File(cacheDir, "rclone-video-cache").apply { mkdirs() }
        val result = Rclone.call("serve/start", JSONObject()
            .put("type", "http")
            .put("fs", fs)
            .put("addr", "127.0.0.1:0")
            .put("read_only", true)
            .put("disable_dir_list", true)
            .put("dir_cache_time", "10m")
            .put("buffer_size", "16M")
            .put("vfs_cache_mode", "full")
            .put("vfs_cache_max_size", "20G")
            .put("vfs_cache_max_age", "168h")
            .put("vfs_read_ahead", "64M")
            .put("vfs_read_chunk_size", "128M")
            .put("vfs_read_chunk_size_limit", "1G")
            .put("cache_dir", cacheDir.absolutePath))

        val addr = result.getString("addr")
        val port = addr.substringAfterLast(':').removeSuffix("]").toInt()
        mediaServerId = result.getString("id")
        mediaServerPort = port
        mediaServerFs = fs
        return port
    }

    private fun buildVideoStreamUri(port: Int, name: String): android.net.Uri {
        return android.net.Uri.Builder()
            .scheme("http")
            .encodedAuthority("127.0.0.1:$port")
            .appendPath(name)
            .build()
    }

    private fun streamEndpointWorks(uri: android.net.Uri): Boolean {
        return try {
            val connection = (java.net.URL(uri.toString()).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                setRequestProperty("Range", "bytes=0-0")
                connectTimeout = 8000
                readTimeout = 12000
                instanceFollowRedirects = true
            }
            val code = connection.responseCode
            connection.disconnect()
            code in 200..299 || code == 206
        } catch (_: Exception) {
            false
        }
    }

    private fun openVideoWithCachedFile(name: String, path: String, remote: String?, message: String? = null) {
        val mime = MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "video/*"
        val temp = mediaCacheFile(remote, path, name)
        if (message != null) runOnUiThread { Toast.makeText(this, message, Toast.LENGTH_SHORT).show() }
        background.execute {
            try {
                downloadToCache(name, path, remote, temp)
                runOnUiThread {
                    try {
                        val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", temp)
                        val intent = Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(uri, mime)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            clipData = ClipData.newRawUri("MEGA Cluster", uri)
                        }
                        startActivity(Intent.createChooser(intent, "Lire la vidéo avec…"))
                    } catch (e: Exception) {
                        Toast.makeText(this, "Aucun lecteur compatible : ${cleanError(e)}", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Téléchargement impossible : ${cleanError(e)}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun openVideoStream(name: String, path: String, remote: String? = explorerRemote) {
        background.execute {
            try {
                val port = ensureMediaServer(path, remote)
                val uri = buildVideoStreamUri(port, name)
                if (!streamEndpointWorks(uri)) {
                    runOnUiThread {
                        Toast.makeText(this, "Streaming indisponible pour cette vidéo — ouverture avec cache local…", Toast.LENGTH_SHORT).show()
                    }
                    openVideoWithCachedFile(name, path, remote)
                    return@execute
                }
                val mime = MimeTypeMap.getSingleton()
                    .getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "video/*"
                runOnUiThread {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(uri, mime)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        startActivity(Intent.createChooser(intent, "Lire la vidéo avec…"))
                    } catch (e: Exception) {
                        openVideoWithCachedFile(name, path, remote, "Lecteur streaming incompatible — cache local…")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Streaming indisponible — ouverture avec cache local…", Toast.LENGTH_SHORT).show()
                    openVideoWithCachedFile(name, path, remote)
                }
            }
        }
    }

    private fun openPhotoViewer() {
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowCompat.getInsetsController(window, window.decorView).hide(
            androidx.core.view.WindowInsetsCompat.Type.systemBars()
        )
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            setPadding(0, 0, 0, 0)
        }
        mediaViewerRoot = root

        val title = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(72), 0)
            setBackgroundColor(0xCC000000.toInt())
            visibility = View.GONE
        }
        root.addView(title, FrameLayout.LayoutParams(-1, dp(52), Gravity.TOP))

        val imageHolder = FrameLayout(this)
        root.addView(imageHolder, FrameLayout.LayoutParams(-1, -1))

        val close = Button(this).apply {
            text = "✕"
            setOnClickListener { closeMediaViewer() }
        }
        val closeLp = FrameLayout.LayoutParams(dp(56), dp(52), Gravity.TOP or Gravity.END).apply {
            topMargin = dp(2)
            rightMargin = dp(2)
        }
        root.addView(close, closeLp)

        fun render(idx: Int) {
            if (idx !in mediaItems.indices) return
            mediaIndex = idx
            imageHolder.removeAllViews()
            val item = mediaItems[idx]
            title.text = "${idx + 1}/${mediaItems.size}  ${item.name}"
            val file = mediaCacheFile(mediaRemote, mediaPath, item.name)
            if (file.exists() && file.length() > 0) {
                val image = ZoomableImageView(this)
                imageHolder.addView(image, FrameLayout.LayoutParams(-1, -1))
                image.onSwipe = { direction ->
                    val next = if (direction < 0) mediaIndex + 1 else mediaIndex - 1
                    if (next in mediaItems.indices) render(next)
                }
                image.onTap = {
                    title.visibility = if (title.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                }
                background.execute {
                    try {
                        val targetW = imageHolder.width.coerceAtLeast(1080)
                        val targetH = imageHolder.height.coerceAtLeast(1080)
                        val isGif = extensionOf(item.name) == "gif"
                        if (isGif) {
                            val drawable = decodeGifForView(file, targetW, targetH)
                                ?: throw IllegalStateException("GIF non pris en charge ou fichier invalide")
                            runOnUiThread {
                                if (mediaIndex == idx && mediaViewerRoot != null) {
                                    image.setImageDrawable(drawable)
                                    image.post { image.resetToFit() }
                                    if (drawable is Animatable) drawable.start()
                                } else if (drawable is Animatable) {
                                    drawable.stop()
                                }
                            }
                        } else {
                            val bitmap = decodePhotoForView(file, targetW, targetH)
                                ?: throw IllegalStateException("format d'image non pris en charge ou fichier invalide")
                            runOnUiThread {
                                if (mediaIndex == idx && mediaViewerRoot != null) {
                                    image.setImageBitmap(bitmap)
                                    image.post { image.resetToFit() }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            if (mediaIndex == idx) {
                                imageHolder.removeAllViews()
                                val error = TextView(this).apply {
                                    text = "Impossible d'afficher l'image\n${cleanError(e)}"
                                    setTextColor(Color.WHITE)
                                    textSize = 16f
                                    gravity = Gravity.CENTER
                                    setPadding(dp(24), dp(24), dp(24), dp(24))
                                }
                                imageHolder.addView(error, FrameLayout.LayoutParams(-1, -1))
                            }
                        }
                    }
                }
            } else {
                val loading = TextView(this).apply {
                    text = "Chargement de l’image…"
                    setTextColor(Color.WHITE)
                    textSize = 18f
                    gravity = Gravity.CENTER
                }
                imageHolder.addView(loading, FrameLayout.LayoutParams(-1, -1))
                background.execute {
                    try {
                        downloadToCache(item.name, mediaPath, mediaRemote, file)
                        runOnUiThread { if (mediaIndex == idx) render(idx) }
                    } catch (e: Exception) {
                        runOnUiThread { loading.text = "Impossible de charger : ${cleanError(e)}" }
                    }
                }
            }
            prefetchMedia(idx - 1)
            prefetchMedia(idx + 1)
        }

        setContentView(root)
        render(mediaIndex)
    }

    private fun closeMediaViewer() {
        WindowCompat.getInsetsController(window, window.decorView).show(
            androidx.core.view.WindowInsetsCompat.Type.systemBars()
        )
        WindowCompat.setDecorFitsSystemWindows(window, true)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        // Return to the exact explorer context from which the photo was opened.
        // Do not rebuild the main menu: the photo viewer is a child screen of the explorer.
        val returnPath = mediaPath
        val returnRemote = mediaRemote
        mediaViewerRoot = null
        if (returnPath.isNotBlank() || explorerOpen) {
            openExplorer(returnPath, returnRemote)
        } else {
            buildUi()
            refreshAccounts()
        }
    }

    private class ZoomableImageView(context: Context) : androidx.appcompat.widget.AppCompatImageView(context) {
        var onSwipe: ((Int) -> Unit)? = null
        var onTap: (() -> Unit)? = null
        private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                if (drawable == null || width <= 0 || height <= 0) return false
                scaleFactor = (scaleFactor * detector.scaleFactor).coerceIn(1f, maxScale)
                applyMatrix()
                return true
            }
        })
        private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                onTap?.invoke()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (drawable == null) return true
                scaleFactor = if (scaleFactor <= 1.01f) calculateOneToOneScale() else 1f
                applyMatrix()
                return true
            }

            override fun onFling(
                e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float
            ): Boolean {
                if (e1 != null) {
                    val dx = e2.x - e1.x
                    val dy = e2.y - e1.y
                    val horizontal = kotlin.math.abs(dx) >= dpStatic(55) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.15f
                    if (horizontal && kotlin.math.abs(velocityX) >= 250f) {
                        val direction = if (dx < 0) -1 else 1
                        // A horizontal fling always means previous/next, even while zoomed.
                        // Delay the replacement until the touch sequence has finished.
                        post { onSwipe?.invoke(direction) }
                        return true
                    }
                }
                return false
            }
        })

        private var scaleFactor = 1f
        private val maxScale = 6f
        private var lastX = 0f
        private var lastY = 0f
        private var isPanning = false
        private val imageMatrixValue = android.graphics.Matrix()

        init {
            scaleType = ScaleType.MATRIX
            setBackgroundColor(Color.BLACK)
            isClickable = true
        }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            post { resetToFit() }
        }

        private fun calculateOneToOneScale(): Float {
            val d = drawable ?: return 1f
            if (width <= 0 || height <= 0 || d.intrinsicWidth <= 0 || d.intrinsicHeight <= 0) return 1f
            val fit = minOf(width.toFloat() / d.intrinsicWidth, height.toFloat() / d.intrinsicHeight)
            return (1f / fit).coerceIn(1f, maxScale)
        }

        fun resetToFit() {
            val d = drawable ?: return
            if (width <= 0 || height <= 0 || d.intrinsicWidth <= 0 || d.intrinsicHeight <= 0) return
            val fit = minOf(width.toFloat() / d.intrinsicWidth, height.toFloat() / d.intrinsicHeight)
            scaleFactor = 1f
            imageMatrixValue.reset()
            imageMatrixValue.postScale(fit, fit)
            imageMatrixValue.postTranslate(
                (width - d.intrinsicWidth * fit) / 2f,
                (height - d.intrinsicHeight * fit) / 2f
            )
            imageMatrix = android.graphics.Matrix(imageMatrixValue)
        }

        private fun applyMatrix() {
            val d = drawable ?: return
            if (width <= 0 || height <= 0 || d.intrinsicWidth <= 0 || d.intrinsicHeight <= 0) return
            val fit = minOf(width.toFloat() / d.intrinsicWidth, height.toFloat() / d.intrinsicHeight)
            val scaledW = d.intrinsicWidth * fit * scaleFactor
            val scaledH = d.intrinsicHeight * fit * scaleFactor
            imageMatrixValue.reset()
            imageMatrixValue.postScale(fit * scaleFactor, fit * scaleFactor)
            imageMatrixValue.postTranslate((width - scaledW) / 2f, (height - scaledH) / 2f)
            imageMatrix = android.graphics.Matrix(imageMatrixValue)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            return try {
                gestureDetector.onTouchEvent(event)
                scaleDetector.onTouchEvent(event)

                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        lastX = event.x
                        lastY = event.y
                        isPanning = false
                        parent?.requestDisallowInterceptTouchEvent(true)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (!scaleDetector.isInProgress && scaleFactor > 1.01f && event.pointerCount == 1) {
                            val dx = event.x - lastX
                            val dy = event.y - lastY
                            // Keep a strong horizontal gesture available for next/previous.
                            if (kotlin.math.abs(dy) > kotlin.math.abs(dx) * 1.15f || kotlin.math.abs(dx) < dpStatic(8)) {
                                if (kotlin.math.abs(dx) > 0.5f || kotlin.math.abs(dy) > 0.5f) {
                                    imageMatrixValue.postTranslate(dx, dy)
                                    imageMatrix = android.graphics.Matrix(imageMatrixValue)
                                    isPanning = true
                                }
                            }
                        }
                        lastX = event.x
                        lastY = event.y
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        parent?.requestDisallowInterceptTouchEvent(false)
                        isPanning = false
                    }
                }
                true
            } catch (_: RuntimeException) {
                // A malformed/cancelled multi-touch sequence must never terminate the app.
                parent?.requestDisallowInterceptTouchEvent(false)
                true
            }
        }

        private fun dpStatic(v: Int): Float = v * resources.displayMetrics.density
    }

    private fun decodeGifForView(file: File, targetW: Int, targetH: Int): Drawable? {
        if (Build.VERSION.SDK_INT < 28) return null
        return try {
            val source = ImageDecoder.createSource(file)
            ImageDecoder.decodeDrawable(source) { decoder, info, _ ->
                val w = info.size.width
                val h = info.size.height
                if (w > 0 && h > 0 && targetW > 0 && targetH > 0) {
                    val ratio = minOf(targetW.toFloat() / w.toFloat(), targetH.toFloat() / h.toFloat(), 1f)
                    decoder.setTargetSize(
                        (w * ratio).toInt().coerceAtLeast(1),
                        (h * ratio).toInt().coerceAtLeast(1)
                    )
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun decodePhotoForView(file: File, targetW: Int, targetH: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (bounds.outWidth / sample > targetW * 2 || bounds.outHeight / sample > targetH * 2) {
            sample *= 2
        }
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return BitmapFactory.decodeFile(file.absolutePath, options)
    }

    private fun prefetchMedia(idx: Int) {
        if (idx !in mediaItems.indices) return
        val item = mediaItems[idx]
        val file = mediaCacheFile(mediaRemote, mediaPath, item.name)
        if (file.exists() && file.length() > 0) return
        val key = file.absolutePath
        if (mediaPrefetch.containsKey(key)) return
        mediaPrefetch[key] = file
        background.execute {
            try { downloadToCache(item.name, mediaPath, mediaRemote, file) } catch (_: Exception) { file.delete() }
            finally { mediaPrefetch.remove(key) }
        }
    }

    private fun downloadToCache(name: String, path: String, remote: String?, destination: File) {
        destination.parentFile?.mkdirs()
        val temp = File(destination.parentFile, destination.name + ".part")
        temp.delete()
        try {
            Rclone.call(
                "operations/copyfile",
                JSONObject()
                    .put("srcFs", if (remote == null) "mega-cluster:" else "$remote:")
                    .put("srcRemote", if (path.isBlank()) name else "$path/$name")
                    .put("dstFs", "/")
                    .put("dstRemote", temp.absolutePath)
            )
            if (!temp.exists() || temp.length() <= 0L) {
                throw IllegalStateException("le fichier téléchargé est vide")
            }
            if (!temp.renameTo(destination)) {
                temp.copyTo(destination, overwrite = true)
                temp.delete()
            }
            destination.setLastModified(System.currentTimeMillis())
        } finally {
            temp.delete()
        }
    }

    private fun mediaCacheFile(remote: String?, path: String, name: String): File {
        val key = java.security.MessageDigest.getInstance("SHA-256").digest(mediaKey(remote, path, name).toByteArray()).joinToString("") { "%02x".format(it) }
        val ext = name.substringAfterLast('.', "bin").replace(Regex("[^A-Za-z0-9]"), "")
        return File(File(cacheDir, "media_cache"), "$key.$ext")
    }

    private fun mediaKey(remote: String?, path: String, name: String): String = "${remote ?: "__cluster__"}|$path|$name"
    private fun isVideo(name: String): Boolean = extensionOf(name) in setOf("mp4", "mkv", "webm", "avi", "mov", "m4v", "ts", "m2ts", "3gp", "flv", "wmv", "ogv")
    private fun isImage(name: String): Boolean = extensionOf(name) in setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif", "avif")

    private fun extensionOf(name: String): String = name.substringAfterLast('.', "").lowercase()

    private fun cleanupMediaCache() {
        val dir = File(cacheDir, "media_cache")
        if (!dir.exists()) return
        val now = System.currentTimeMillis()
        dir.listFiles()?.forEach { file ->
            if (now - file.lastModified() > mediaCacheMaxAgeMs) file.delete()
        }
    }

    private fun cycleExplorerSort() {
        if (explorerSort == "name" && explorerSortAsc) { explorerSortAsc = false }
        else if (explorerSort == "name" && !explorerSortAsc) { explorerSort = "type"; explorerSortAsc = true }
        else if (explorerSort == "type" && explorerSortAsc) { explorerSortAsc = false }
        else if (explorerSort == "type" && !explorerSortAsc) { explorerSort = "size"; explorerSortAsc = true }
        else if (explorerSort == "size" && explorerSortAsc) { explorerSortAsc = false }
        else if (explorerSort == "size" && !explorerSortAsc) { explorerSort = "date"; explorerSortAsc = true }
        else if (explorerSort == "date" && explorerSortAsc) { explorerSortAsc = false }
        else { explorerSort = "name"; explorerSortAsc = true }
        openExplorer(explorerPath, explorerRemote)
    }

    private fun sortLabel(mode: String): String = when (mode) {
        "type" -> "Type"
        "size" -> "Taille"
        "date" -> "Date"
        else -> "Nom"
    }

    private fun sortExplorerItems(items: List<ExplorerItem>): List<ExplorerItem> {
        val keySorted = when (explorerSort) {
            "type" -> items.sortedWith(compareBy<ExplorerItem> { if (it.isDir) "" else extensionOf(it.name) }.thenBy { it.name.lowercase() })
            "size" -> items.sortedBy { it.size }
            "date" -> items.sortedBy { it.modTime }
            else -> items.sortedBy { it.name.lowercase() }
        }
        val ordered = if (explorerSortAsc) keySorted else keySorted.asReversed()
        val dirs = ordered.filter { it.isDir }
        val files = ordered.filterNot { it.isDir }
        return dirs + files
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun formatSize(bytes: Long): String = when {
        bytes < 1024 -> "$bytes o"
        bytes < 1024 * 1024 -> "%.1f Ko".format(bytes / 1024.0)
        bytes < 1024L * 1024L * 1024L -> "%.1f Mo".format(bytes / (1024.0 * 1024.0))
        else -> "%.1f Go".format(bytes / (1024.0 * 1024.0 * 1024.0))
    }

    private fun openDiagnosticsMenu() {
        val items = arrayOf("Tester le sélecteur Android", "Diagnostiquer le fournisseur", "Tester la racine", "Ouvrir directement MEGA Cluster")
        AlertDialog.Builder(this).setTitle("Outils Android").setItems(items) { _, which -> when (which) {
            0 -> openAndroidPicker(); 1 -> diagnoseProvider(); 2 -> diagnoseRoots(); 3 -> openMegaClusterRoot()
        }}.show()
    }

    private fun openAndroidPicker() {
        try {
            startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            })
        } catch (e: Exception) { Toast.makeText(this, cleanError(e), Toast.LENGTH_LONG).show() }
    }

    private fun diagnoseProvider() {
        val authority = "com.example.megacluster.documents"
        val provider = packageManager.resolveContentProvider(authority, 0)
        showDiagnostic(if (provider == null) "❌ Provider NON trouvé" else "✅ Provider trouvé\n\nNom : ${provider.name}\nAutorité : ${provider.authority}\nExporté : ${provider.exported}")
    }

    private fun diagnoseRoots() {
        try {
            val uri = DocumentsContract.buildRootsUri("com.example.megacluster.documents")
            contentResolver.query(uri, null, null, null, null).use { cursor -> showDiagnostic(if (cursor != null && cursor.moveToFirst()) "✅ Racine MEGA Cluster trouvée." else "❌ Aucune racine retournée.") }
        } catch (e: Exception) { showDiagnostic("❌ ${cleanError(e)}") }
    }

    private fun openMegaClusterRoot() {
        try {
            startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                putExtra(DocumentsContract.EXTRA_INITIAL_URI, DocumentsContract.buildDocumentUri("com.example.megacluster.documents", "mega-cluster"))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            })
        } catch (e: Exception) { showDiagnostic("❌ ${cleanError(e)}") }
    }

    private fun showDiagnostic(message: String) = AlertDialog.Builder(this).setTitle("MEGA Cluster").setMessage(message).setPositiveButton("OK", null).show()
}
