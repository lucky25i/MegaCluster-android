# MEGA Cluster — Android

Prototype open-source Android application for the following architecture:

MEGA account 1 + MEGA account 2 + ... -> rclone Union -> Android DocumentsProvider.

The app is designed to expose the virtual `mega-cluster:` remote to Android's Storage Access Framework.

## Important

This repository intentionally does **not** include a prebuilt `librclone.aar`.
The GitHub Actions workflow builds it from the official rclone source so the exact rclone version is reproducible.

The current prototype targets rclone v1.75.1 and Android arm64/other ABIs through the official gomobile build process.

## Build without a PC

1. Create a GitHub repository and upload this project.
2. Open Actions.
3. Run `Build APK`.
4. Download the generated APK artifact.
5. Install it on the Galaxy A56.

The workflow installs Gradle, Go, Android NDK and builds the official rclone `librclone` AAR automatically.

## Current scope

- multiple MEGA remotes
- rclone Union
- Android DocumentsProvider
- browse/read/write/delete/rename/create directory
- no root
- no Termux

## Security

MEGA credentials are stored in rclone's configuration inside the application's private storage. Before a public release, the configuration should be additionally protected with Android Keystore-backed encryption.

## Licensing

rclone is GPL-3.0. This application must preserve applicable rclone licensing obligations when distributed with librclone.
