package com.example.megacluster

import android.content.Context
import org.rclone.gomobile.Gomobile
import org.rclone.gomobile.RcloneRPCResult
import org.json.JSONObject
import java.io.File

object Rclone {
    private var initialized = false

    fun init(context: Context) {
        if (initialized) return
        File(context.filesDir, "rclone").mkdirs()
        Gomobile.rcloneInitialize()
        initialized = true
        call("config/setpath", JSONObject().put("path", File(context.filesDir, "rclone/rclone.conf").absolutePath))
    }

    fun call(method: String, input: JSONObject = JSONObject()): JSONObject {
        val result: RcloneRPCResult = Gomobile.rcloneRPC(method, input.toString())
        val output = result.output ?: ""
        if (result.status != 200 && result.status != 0) {
            throw IllegalStateException("$method (${result.status}): $output")
        }
        return if (output.isBlank()) JSONObject() else JSONObject(output)
    }

    fun close() {
        if (initialized) {
            Gomobile.rcloneFinalize()
            initialized = false
        }
    }
}
