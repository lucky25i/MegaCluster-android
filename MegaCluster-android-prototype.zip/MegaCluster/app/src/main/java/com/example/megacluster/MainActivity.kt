package com.example.megacluster

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var accounts: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Rclone.init(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "MEGA Cluster"
            textSize = 28f
        }
        root.addView(title)

        status = TextView(this).apply {
            text = "Initialisation…"
            textSize = 16f
        }
        root.addView(status)

        val add = Button(this).apply {
            text = "Ajouter un compte MEGA"
            setOnClickListener { addMegaDialog() }
        }
        root.addView(add)

        val refresh = Button(this).apply {
            text = "Reconstruire le cluster"
            setOnClickListener { rebuildUnion() }
        }
        root.addView(refresh)

        accounts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(accounts)

        setContentView(root)
        refreshAccounts()
    }

    private fun addMegaDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 0, 20, 0)
        }
        val email = EditText(this).apply { hint = "E-mail MEGA" }
        val pass = EditText(this).apply { hint = "Mot de passe"; inputType = 0x81 }
        val twofa = EditText(this).apply { hint = "2FA (facultatif)" }
        box.addView(email); box.addView(pass); box.addView(twofa)

        AlertDialog.Builder(this)
            .setTitle("Nouveau compte MEGA")
            .setView(box)
            .setPositiveButton("Ajouter") { _, _ ->
                try {
                    val n = "mega${nextIndex()}"
                    val p = JSONObject()
                        .put("user", email.text.toString())
                        .put("pass", pass.text.toString())
                    if (twofa.text.isNotBlank()) p.put("2fa", twofa.text.toString())
                    Rclone.call("config/create",
                        JSONObject().put("name", n).put("type", "mega").put("parameters", p))
                    rebuildUnion()
                    refreshAccounts()
                } catch (e: Exception) {
                    Toast.makeText(this, e.message ?: "Erreur", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun nextIndex(): Int {
        val r = Rclone.call("config/listremotes")
        val a = r.optJSONArray("remotes") ?: JSONArray()
        var max = 0
        for (i in 0 until a.length()) {
            val s = a.getString(i).removeSuffix(":")
            if (s.startsWith("mega")) s.removePrefix("mega").toIntOrNull()?.let { max = maxOf(max, it) }
        }
        return max + 1
    }

    private fun refreshAccounts() {
        try {
            val r = Rclone.call("config/listremotes")
            val a = r.optJSONArray("remotes") ?: JSONArray()
            accounts.removeAllViews()
            var count = 0
            for (i in 0 until a.length()) {
                val n = a.getString(i).removeSuffix(":")
                if (n.startsWith("mega")) {
                    accounts.addView(TextView(this).apply { text = "☁ $n"; textSize = 18f })
                    count++
                }
            }
            status.text = "$count compte(s) MEGA configuré(s)"
        } catch (e: Exception) {
            status.text = "Erreur : ${e.message}"
        }
    }

    private fun rebuildUnion() {
        try {
            val r = Rclone.call("config/listremotes")
            val a = r.optJSONArray("remotes") ?: JSONArray()
            val upstreams = mutableListOf<String>()
            for (i in 0 until a.length()) {
                val n = a.getString(i).removeSuffix(":")
                if (n.startsWith("mega")) upstreams.add("$n:")
            }
            if (upstreams.isEmpty()) {
                status.text = "Ajoute d'abord au moins un compte MEGA."
                return
            }
            val p = JSONObject()
                .put("type", "union")
                .put("upstreams", upstreams.joinToString(" "))
                .put("create_policy", "eplfs")
                .put("action_policy", "epall")
                .put("search_policy", "ff")
            try { Rclone.call("config/delete", JSONObject().put("name", "mega-cluster")) } catch (_: Exception) {}
            Rclone.call("config/create",
                JSONObject().put("name", "mega-cluster").put("type", "union")
                    .put("parameters", JSONObject()
                        .put("upstreams", upstreams.joinToString(" "))
                        .put("create_policy", "eplfs")
                        .put("action_policy", "epall")
                        .put("search_policy", "ff")))
            status.text = "Cluster prêt : ${upstreams.size} compte(s)"
        } catch (e: Exception) {
            status.text = "Erreur cluster : ${e.message}"
        }
    }

    override fun onDestroy() {
        Rclone.close()
        super.onDestroy()
    }
}
