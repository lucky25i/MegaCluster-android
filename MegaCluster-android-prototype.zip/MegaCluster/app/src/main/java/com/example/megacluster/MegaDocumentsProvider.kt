package com.example.megacluster

import android.database.Cursor
import android.database.MatrixCursor
import android.graphics.Point
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import android.provider.DocumentsProvider
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.FileInputStream
import java.util.concurrent.Executors
import android.net.Uri

class MegaDocumentsProvider : DocumentsProvider() {
    private val executor = Executors.newCachedThreadPool()
    private val rootId = "mega-cluster"

    override fun onCreate(): Boolean {
        context?.let { Rclone.init(it) }
        return true
    }

    override fun queryRoots(projection: Array<out String>?): Cursor {
        val c = MatrixCursor(projection ?: DEFAULT_ROOT_PROJECTION)
        val row = c.newRow()
        row.add(Document.COLUMN_ROOT_ID, rootId)
        row.add(Document.COLUMN_DOCUMENT_ID, rootId)
        row.add(Document.COLUMN_TITLE, "MEGA Cluster")
        row.add(Document.COLUMN_FLAGS, Document.FLAG_SUPPORTS_CREATE)
        row.add(Document.COLUMN_MIME_TYPES, "*/*")
        row.add(Document.COLUMN_AVAILABLE_BYTES, Long.MAX_VALUE)
        return c
    }

    override fun queryDocument(documentId: String, projection: Array<out String>?): Cursor {
        val c = MatrixCursor(projection ?: DEFAULT_DOCUMENT_PROJECTION)
        if (documentId == rootId) {
            includeDocument(c, rootId, "MEGA Cluster", Document.MIME_TYPE_DIR, 0, Document.FLAG_DIR_SUPPORTS_CREATE)
        } else {
            val path = decode(documentId)
            val parent = path.substringBeforeLast("/", "")
            val name = path.substringAfterLast("/")
            val r = Rclone.call("operations/list", JSONObject()
                .put("fs", "mega-cluster:")
                .put("remote", parent)
                .put("opt", JSONObject().put("filesOnly", false)))
            val list = r.optJSONArray("list") ?: org.json.JSONArray()
            for (i in 0 until list.length()) {
                val o = list.getJSONObject(i)
                if (o.optString("Name") == name) {
                    val isDir = o.optBoolean("IsDir")
                    val mime = if (isDir) Document.MIME_TYPE_DIR else mimeFor(name)
                    val flags = if (isDir) Document.FLAG_DIR_SUPPORTS_CREATE else
                        Document.FLAG_SUPPORTS_WRITE or Document.FLAG_SUPPORTS_DELETE or Document.FLAG_SUPPORTS_RENAME
                    includeDocument(c, documentId, name, mime, o.optLong("Size", 0), flags)
                    break
                }
            }
        }
        return c
    }

    override fun queryChildDocuments(parentDocumentId: String, projection: Array<out String>?, sortOrder: String?): Cursor {
        val c = MatrixCursor(projection ?: DEFAULT_DOCUMENT_PROJECTION)
        val remote = if (parentDocumentId == rootId) "" else decode(parentDocumentId)
        val r = Rclone.call("operations/list", JSONObject()
            .put("fs", "mega-cluster:")
            .put("remote", remote)
            .put("opt", JSONObject().put("filesOnly", false)))
        val list = r.optJSONArray("list") ?: org.json.JSONArray()
        for (i in 0 until list.length()) {
            val o = list.getJSONObject(i)
            val name = o.optString("Name")
            val path = if (remote.isEmpty()) name else "$remote/$name"
            val id = encode(path)
            val dir = o.optBoolean("IsDir")
            includeDocument(c, id, name, if (dir) Document.MIME_TYPE_DIR else mimeFor(name),
                o.optLong("Size", 0),
                if (dir) Document.FLAG_DIR_SUPPORTS_CREATE else
                    Document.FLAG_SUPPORTS_WRITE or Document.FLAG_SUPPORTS_DELETE or Document.FLAG_SUPPORTS_RENAME)
        }
        return c
    }

    override fun openDocument(documentId: String, mode: String, signal: CancellationSignal?, callback: android.os.Handler?): ParcelFileDescriptor {
        val read = mode.contains("r") && !mode.contains("w")
        val pipe = ParcelFileDescriptor.createPipe()
        val path = decode(documentId)
        val temp = File(context!!.cacheDir, "io_${System.nanoTime()}")
        if (read) {
            executor.execute {
                ParcelFileDescriptor.AutoCloseOutputStream(pipe[1]).use { out ->
                    try {
                        val local = temp.absolutePath
                        Rclone.call("operations/copyfile", JSONObject()
                            .put("srcFs", "mega-cluster:").put("srcRemote", path)
                            .put("dstFs", "local:").put("dstRemote", local))
                        FileInputStream(temp).use { it.copyTo(out) }
                    } finally { temp.delete() }
                }
            }
            return pipe[0]
        } else {
            executor.execute {
                ParcelFileDescriptor.AutoCloseInputStream(pipe[0]).use { input ->
                    FileOutputStream(temp).use { input.copyTo(it) }
                    Rclone.call("operations/copyfile", JSONObject()
                        .put("srcFs", "local:").put("srcRemote", temp.absolutePath)
                        .put("dstFs", "mega-cluster:").put("dstRemote", path))
                    temp.delete()
                }
            }
            return pipe[1]
        }
    }

    override fun createDocument(parentDocumentId: String, mimeType: String, displayName: String): String {
        val parent = if (parentDocumentId == rootId) "" else decode(parentDocumentId)
        val path = if (parent.isEmpty()) displayName else "$parent/$displayName"
        if (mimeType == Document.MIME_TYPE_DIR) {
            Rclone.call("operations/mkdir", JSONObject().put("fs", "mega-cluster:").put("remote", path))
        } else {
            val temp = File(context!!.cacheDir, "empty_${System.nanoTime()}")
            temp.createNewFile()
            Rclone.call("operations/copyfile", JSONObject()
                .put("srcFs", "local:").put("srcRemote", temp.absolutePath)
                .put("dstFs", "mega-cluster:").put("dstRemote", path))
            temp.delete()
        }
        return encode(path)
    }

    override fun deleteDocument(documentId: String) {
        val path = decode(documentId)
        val isDir = queryDocumentIsDirectory(path)
        if (isDir) {
            Rclone.call("operations/rmdir", JSONObject().put("fs", "mega-cluster:").put("remote", path))
        } else {
            Rclone.call("operations/deletefile", JSONObject().put("fs", "mega-cluster:").put("remote", path))
        }
    }

    override fun renameDocument(documentId: String, displayName: String): String {
        val old = decode(documentId)
        val parent = old.substringBeforeLast("/", "")
        val newPath = if (parent.isEmpty()) displayName else "$parent/$displayName"
        Rclone.call("operations/movefile", JSONObject()
            .put("srcFs", "mega-cluster:").put("srcRemote", old)
            .put("dstFs", "mega-cluster:").put("dstRemote", newPath))
        return encode(newPath)
    }


    private fun queryDocumentIsDirectory(path: String): Boolean {
        val parent = path.substringBeforeLast("/", "")
        val name = path.substringAfterLast("/")
        val r = Rclone.call("operations/list", JSONObject()
            .put("fs", "mega-cluster:")
            .put("remote", parent)
            .put("opt", JSONObject().put("filesOnly", false)))
        val list = r.optJSONArray("list") ?: org.json.JSONArray()
        for (i in 0 until list.length()) {
            val o = list.getJSONObject(i)
            if (o.optString("Name") == name) return o.optBoolean("IsDir")
        }
        return false
    }

    private fun includeDocument(c: MatrixCursor, id: String, name: String, mime: String, size: Long, flags: Int) {
        val r = c.newRow()
        r.add(Document.COLUMN_DOCUMENT_ID, id)
        r.add(Document.COLUMN_DISPLAY_NAME, name)
        r.add(Document.COLUMN_MIME_TYPE, mime)
        r.add(Document.COLUMN_SIZE, size)
        r.add(Document.COLUMN_FLAGS, flags)
    }

    private fun mimeFor(name: String): String = android.webkit.MimeTypeMap.getSingleton()
        .getMimeTypeFromExtension(name.substringAfterLast('.', "")) ?: "application/octet-stream"

    private fun encode(s: String) = "p:" + android.util.Base64.encodeToString(s.toByteArray(), android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP)
    private fun decode(s: String) = if (s.startsWith("p:")) String(android.util.Base64.decode(s.substring(2), android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP)) else ""

    companion object {
        private val DEFAULT_ROOT_PROJECTION = arrayOf(
            Document.COLUMN_ROOT_ID, Document.COLUMN_DOCUMENT_ID, Document.COLUMN_TITLE,
            Document.COLUMN_FLAGS, Document.COLUMN_MIME_TYPES, Document.COLUMN_AVAILABLE_BYTES)
        private val DEFAULT_DOCUMENT_PROJECTION = arrayOf(
            Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE,
            Document.COLUMN_SIZE, Document.COLUMN_FLAGS)
    }
}
