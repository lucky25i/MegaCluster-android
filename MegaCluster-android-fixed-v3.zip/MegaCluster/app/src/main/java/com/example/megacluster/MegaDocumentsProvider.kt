package com.example.megacluster

import android.database.Cursor
import android.database.MatrixCursor
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import android.provider.DocumentsContract.Root
import android.provider.DocumentsProvider
import android.webkit.MimeTypeMap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.time.Instant
import java.util.concurrent.Executors

/**
 * Exposes the rclone union as an Android Storage Access Framework provider.
 * This is what makes MEGA Cluster appear in Android file pickers.
 */
class MegaDocumentsProvider : DocumentsProvider() {
    private val executor = Executors.newCachedThreadPool()
    private val rootId = "mega-cluster"

    override fun onCreate(): Boolean {
        val ctx = context ?: return false
        Rclone.init(ctx)
        return true
    }

    override fun queryRoots(projection: Array<out String>?): Cursor {
        val columns = projection?.let { p -> Array(p.size) { i -> p[i] } } ?: DEFAULT_ROOT_PROJECTION
        val cursor = MatrixCursor(columns)
        val row = cursor.newRow()
        val available = try {
            Rclone.call("operations/about", JSONObject().put("fs", "mega-cluster:"))
                .optLong("free", -1L)
        } catch (_: Exception) {
            -1L
        }

        put(row, columns, Root.COLUMN_ROOT_ID, rootId)
        put(row, columns, Root.COLUMN_ICON, android.R.drawable.ic_menu_save)
        put(row, columns, Root.COLUMN_TITLE, "MEGA Cluster")
        put(row, columns, Root.COLUMN_SUMMARY, "Stockage rclone Union")
        put(row, columns, Root.COLUMN_FLAGS, Root.FLAG_SUPPORTS_CREATE)
        put(row, columns, Root.COLUMN_DOCUMENT_ID, rootId)
        put(row, columns, Root.COLUMN_MIME_TYPES, "*/*")
        put(row, columns, Root.COLUMN_AVAILABLE_BYTES, available)
        return cursor
    }

    override fun queryDocument(documentId: String, projection: Array<out String>?): Cursor {
        val columns = projection?.let { p -> Array(p.size) { i -> p[i] } } ?: DEFAULT_DOCUMENT_PROJECTION
        val cursor = MatrixCursor(columns)

        if (documentId == rootId) {
            addDocumentRow(
                cursor, columns, rootId, "MEGA Cluster", Document.MIME_TYPE_DIR,
                0L, Document.FLAG_DIR_SUPPORTS_CREATE, System.currentTimeMillis()
            )
            return cursor
        }

        val path = decode(documentId)
        val item = Rclone.call(
            "operations/stat",
            JSONObject().put("fs", "mega-cluster:").put("remote", path)
        ).optJSONObject("item") ?: return cursor

        val name = item.optString("Name", path.substringAfterLast('/'))
        val isDir = item.optBoolean("IsDir", false)
        val flags = if (isDir) {
            Document.FLAG_DIR_SUPPORTS_CREATE or Document.FLAG_SUPPORTS_DELETE or Document.FLAG_SUPPORTS_RENAME
        } else {
            Document.FLAG_SUPPORTS_WRITE or Document.FLAG_SUPPORTS_DELETE or Document.FLAG_SUPPORTS_RENAME
        }
        addDocumentRow(
            cursor, columns, documentId, name,
            if (isDir) Document.MIME_TYPE_DIR else mimeFor(name),
            item.optLong("Size", 0L), flags, modTime(item)
        )
        return cursor
    }

    override fun queryChildDocuments(
        parentDocumentId: String,
        projection: Array<out String>?,
        sortOrder: String?
    ): Cursor {
        val columns = projection?.let { p -> Array(p.size) { i -> p[i] } } ?: DEFAULT_DOCUMENT_PROJECTION
        val cursor = MatrixCursor(columns)
        val remote = if (parentDocumentId == rootId) "" else decode(parentDocumentId)

        val result = Rclone.call(
            "operations/list",
            JSONObject()
                .put("fs", "mega-cluster:")
                .put("remote", remote)
                .put("opt", JSONObject().put("filesOnly", false))
        )
        val list = result.optJSONArray("list") ?: JSONArray()

        for (i in 0 until list.length()) {
            val item = list.getJSONObject(i)
            val name = item.optString("Name")
            if (name.isBlank()) continue
            val path = if (remote.isBlank()) name else "$remote/$name"
            val id = encode(path)
            val isDir = item.optBoolean("IsDir", false)
            val flags = if (isDir) {
                Document.FLAG_DIR_SUPPORTS_CREATE or Document.FLAG_SUPPORTS_DELETE or Document.FLAG_SUPPORTS_RENAME
            } else {
                Document.FLAG_SUPPORTS_WRITE or Document.FLAG_SUPPORTS_DELETE or Document.FLAG_SUPPORTS_RENAME
            }
            addDocumentRow(
                cursor, columns, id, name,
                if (isDir) Document.MIME_TYPE_DIR else mimeFor(name),
                item.optLong("Size", 0L), flags, modTime(item)
            )
        }
        return cursor
    }

    override fun openDocument(
        documentId: String,
        mode: String,
        signal: CancellationSignal?
    ): ParcelFileDescriptor {
        require(documentId != rootId) { "Le dossier racine ne peut pas être ouvert comme fichier" }
        val path = decode(documentId)
        val write = mode.contains('w')
        val pipe = ParcelFileDescriptor.createPipe()
        val cacheDir = context!!.cacheDir
        val temp = File(cacheDir, "megacluster_${System.nanoTime()}")

        if (!write) {
            executor.execute {
                try {
                    if (signal?.isCanceled == true) return@execute
                    Rclone.call(
                        "operations/copyfile",
                        JSONObject()
                            .put("srcFs", "mega-cluster:")
                            .put("srcRemote", path)
                            .put("dstFs", "/")
                            .put("dstRemote", temp.absolutePath)
                    )
                    ParcelFileDescriptor.AutoCloseOutputStream(pipe[1]).use { out ->
                        FileInputStream(temp).use { input -> input.copyTo(out) }
                    }
                } catch (_: Exception) {
                    try { pipe[1].close() } catch (_: Exception) {}
                } finally {
                    temp.delete()
                }
            }
            return pipe[0]
        }

        executor.execute {
            try {
                ParcelFileDescriptor.AutoCloseInputStream(pipe[0]).use { input ->
                    FileOutputStream(temp).use { output -> input.copyTo(output) }
                }
                if (signal?.isCanceled != true) {
                    Rclone.call(
                        "operations/copyfile",
                        JSONObject()
                            .put("srcFs", "/")
                            .put("srcRemote", temp.absolutePath)
                            .put("dstFs", "mega-cluster:")
                            .put("dstRemote", path)
                    )
                }
            } catch (_: Exception) {
                // The caller receives the normal file-descriptor lifecycle; transfer errors
                // are deliberately kept out of the Binder thread.
            } finally {
                temp.delete()
            }
        }
        return pipe[1]
    }

    override fun createDocument(parentDocumentId: String, mimeType: String, displayName: String): String {
        val parent = if (parentDocumentId == rootId) "" else decode(parentDocumentId)
        val path = if (parent.isBlank()) displayName else "$parent/$displayName"

        if (mimeType == Document.MIME_TYPE_DIR) {
            Rclone.call("operations/mkdir", JSONObject().put("fs", "mega-cluster:").put("remote", path))
        notifyRootsChanged()
        } else {
            val temp = File(context!!.cacheDir, "empty_${System.nanoTime()}")
            try {
                FileOutputStream(temp).use { }
                Rclone.call(
                    "operations/copyfile",
                    JSONObject()
                        .put("srcFs", "/")
                        .put("srcRemote", temp.absolutePath)
                        .put("dstFs", "mega-cluster:")
                        .put("dstRemote", path)
                )
            } finally {
                temp.delete()
            }
        }
        notifyRootsChanged()
        return encode(path)
    }

    override fun deleteDocument(documentId: String) {
        val path = decode(documentId)
        val item = Rclone.call(
            "operations/stat",
            JSONObject().put("fs", "mega-cluster:").put("remote", path)
        ).optJSONObject("item")
        if (item?.optBoolean("IsDir", false) == true) {
            Rclone.call("operations/rmdir", JSONObject().put("fs", "mega-cluster:").put("remote", path))
        } else {
            Rclone.call("operations/deletefile", JSONObject().put("fs", "mega-cluster:").put("remote", path))
        }
        notifyRootsChanged()
    }

    override fun renameDocument(documentId: String, displayName: String): String {
        val oldPath = decode(documentId)
        val parent = oldPath.substringBeforeLast('/', "")
        val newPath = if (parent.isBlank()) displayName else "$parent/$displayName"
        Rclone.call(
            "operations/movefile",
            JSONObject()
                .put("srcFs", "mega-cluster:")
                .put("srcRemote", oldPath)
                .put("dstFs", "mega-cluster:")
                .put("dstRemote", newPath)
        )
        notifyRootsChanged()
        return encode(newPath)
    }

    private fun notifyRootsChanged() {
        context?.contentResolver?.notifyChange(
            DocumentsContract.buildRootsUri(context!!.packageName),
            null
        )
    }

    private fun addDocumentRow(
        cursor: MatrixCursor,
        columns: Array<String>,
        id: String,
        name: String,
        mime: String,
        size: Long,
        flags: Int,
        modified: Long
    ) {
        val row = cursor.newRow()
        put(row, columns, Document.COLUMN_DOCUMENT_ID, id)
        put(row, columns, Document.COLUMN_DISPLAY_NAME, name)
        put(row, columns, Document.COLUMN_MIME_TYPE, mime)
        put(row, columns, Document.COLUMN_SIZE, size)
        put(row, columns, Document.COLUMN_FLAGS, flags)
        put(row, columns, Document.COLUMN_LAST_MODIFIED, modified)
    }

    private fun put(row: MatrixCursor.RowBuilder, columns: Array<String>, column: String, value: Any?) {
        if (columns.contains(column)) row.add(value)
    }

    private fun modTime(item: JSONObject): Long {
        val raw = item.optString("ModTime")
        return try { Instant.parse(raw).toEpochMilli() } catch (_: Exception) { 0L }
    }

    private fun mimeFor(name: String): String = MimeTypeMap.getSingleton()
        .getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase())
        ?: "application/octet-stream"

    private fun encode(path: String): String = "p:" + android.util.Base64.encodeToString(
        path.toByteArray(Charsets.UTF_8),
        android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP
    )

    private fun decode(id: String): String = if (id.startsWith("p:")) {
        String(
            android.util.Base64.decode(
                id.substring(2),
                android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP
            ),
            Charsets.UTF_8
        )
    } else ""

    companion object {
        private val DEFAULT_ROOT_PROJECTION = arrayOf(
            Root.COLUMN_ROOT_ID,
            Root.COLUMN_ICON,
            Root.COLUMN_TITLE,
            Root.COLUMN_FLAGS,
            Root.COLUMN_DOCUMENT_ID,
            Root.COLUMN_MIME_TYPES,
            Root.COLUMN_AVAILABLE_BYTES
        )

        private val DEFAULT_DOCUMENT_PROJECTION = arrayOf(
            Document.COLUMN_DOCUMENT_ID,
            Document.COLUMN_DISPLAY_NAME,
            Document.COLUMN_MIME_TYPE,
            Document.COLUMN_SIZE,
            Document.COLUMN_FLAGS,
            Document.COLUMN_LAST_MODIFIED
        )
    }
}
