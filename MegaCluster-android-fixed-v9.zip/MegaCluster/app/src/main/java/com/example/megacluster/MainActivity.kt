package com.example.megacluster

import android.app.AlertDialog
import android.content.Intent
import android.provider.DocumentsContract
import android.content.pm.ProviderInfo
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var accounts: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Rclone.init(this)
        buildUi()
        refreshAccounts()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        root.addView(TextView(this).apply {
            text = "MEGA Cluster"
            textSize = 28f
        })

        status = TextView(this).apply {
            text = "Initialisation…"
            textSize = 16f
        }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "Ajouter un compte MEGA"
            setOnClickListener { addMegaDialog() }
        })

        root.addView(Button(this).apply {
            text = "Reconstruire le cluster"
            setOnClickListener { rebuildUnion() }
        })

        root.addView(Button(this).apply {
            text = "📁 Explorer le cluster"
            setOnClickListener { openExplorer("") }
        })

        root.addView(Button(this).apply {
            text = "Tester MEGA Cluster dans le sélecteur Android"
            setOnClickListener { openAndroidPicker() }
        })

        root.addView(Button(this).apply {
            text = "Diagnostiquer le fournisseur Android"
            setOnClickListener { diagnoseProvider() }
        })

        root.addView(Button(this).apply {
            text = "Tester la racine MEGA Cluster"
            setOnClickListener { diagnoseRoots() }
        })

        root.addView(Button(this).apply {
            text = "Ouvrir directement MEGA Cluster"
            setOnClickListener { openMegaClusterRoot() }
        })

        accounts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        root.addView(accounts)

        setContentView(root)
    }

    private fun addMegaDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 0, 20, 0)
        }
        val email = EditText(this).apply {
            hint = "E-mail MEGA"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        }
        val pass = EditText(this).apply {
            hint = "Mot de passe"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val twofa = EditText(this).apply {
            hint = "2FA (si nécessaire)"
            inputType = InputType.TYPE_CLASS_TEXT
        }
        box.addView(email)
        box.addView(pass)
        box.addView(twofa)

        AlertDialog.Builder(this)
            .setTitle("Nouveau compte MEGA")
            .setView(box)
            .setPositiveButton("Ajouter") { _, _ ->
                try {
                    val name = "mega${nextIndex()}"
                    val parameters = JSONObject()
                        .put("user", email.text.toString().trim())
                        .put("pass", pass.text.toString())
                    if (twofa.text.toString().isNotBlank()) {
                        parameters.put("2fa", twofa.text.toString().trim())
                    }
                    Rclone.call(
                        "config/create",
                        JSONObject()
                            .put("name", name)
                            .put("type", "mega")
                            .put("parameters", parameters)
                    )
                    rebuildUnion()
                    refreshAccounts()
                } catch (e: Exception) {
                    Toast.makeText(this, e.message ?: "Erreur MEGA", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun nextIndex(): Int {
        val remotes = Rclone.call("config/listremotes").optJSONArray("remotes") ?: JSONArray()
        var max = 0
        for (i in 0 until remotes.length()) {
            val name = remotes.getString(i).removeSuffix(":")
            if (name.startsWith("mega")) {
                name.removePrefix("mega").toIntOrNull()?.let { max = maxOf(max, it) }
            }
        }
        return max + 1
    }

    private fun refreshAccounts() {
        try {
            val remotes = Rclone.call("config/listremotes").optJSONArray("remotes") ?: JSONArray()
            accounts.removeAllViews()
            var count = 0
            for (i in 0 until remotes.length()) {
                val name = remotes.getString(i).removeSuffix(":")
                if (name.startsWith("mega") && name != "mega-cluster") {
                    accounts.addView(TextView(this).apply {
                        text = "☁ $name  (compte configuré)"
                        textSize = 18f
                        setPadding(0, 12, 0, 12)
                    })
                    count++
                }
            }
            status.text = "$count compte(s) MEGA configuré(s)"
        } catch (e: Exception) {
            status.text = "Erreur : ${e.message}"
        }
    }

    private fun openExplorer(path: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        val title = TextView(this).apply {
            text = if (path.isBlank()) "MEGA Cluster" else "MEGA Cluster / $path"
            textSize = 24f
            setPadding(0, 0, 0, 16)
        }
        root.addView(title)
        if (path.isNotBlank()) {
            root.addView(Button(this).apply {
                text = "⬅ Dossier parent"
                setOnClickListener {
                    val parent = path.substringBeforeLast('/', "")
                    openExplorer(parent)
                }
            })
        }
        root.addView(Button(this).apply {
            text = "↻ Actualiser"
            setOnClickListener { openExplorer(path) }
        })
        val statusView = TextView(this).apply {
            text = "Lecture du cluster…"
            textSize = 16f
            setPadding(0, 16, 0, 16)
        }
        root.addView(statusView)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        root.addView(Button(this).apply {
            text = "← Retour à MEGA Cluster"
            setOnClickListener { buildUi(); refreshAccounts() }
        })
        setContentView(ScrollView(this).apply { addView(root) })

        Thread {
            try {
                val result = Rclone.call(
                    "operations/list",
                    JSONObject()
                        .put("fs", "mega-cluster:")
                        .put("remote", path)
                        .put("opt", JSONObject().put("filesOnly", false))
                )
                val items = result.optJSONArray("list") ?: JSONArray()
                runOnUiThread {
                    statusView.text = if (items.length() == 0) "Dossier vide" else "${items.length()} élément(s)"
                    for (i in 0 until items.length()) {
                        val item = items.getJSONObject(i)
                        val name = item.optString("Name")
                        if (name.isBlank()) continue
                        val isDir = item.optBoolean("IsDir", false)
                        val size = item.optLong("Size", 0L)
                        val row = Button(this).apply {
                            text = if (isDir) "📁 $name" else "📄 $name  (${formatSize(size)})"
                            setOnClickListener {
                                if (isDir) {
                                    openExplorer(if (path.isBlank()) name else "$path/$name")
                                } else {
                                    showDiagnostic("Fichier : $name\n\nTaille : ${formatSize(size)}\n\nLe fichier est bien visible dans le cluster.")
                                }
                            }
                        }
                        list.addView(row)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusView.text = "Erreur lors de la lecture du cluster"
                    showDiagnostic("Impossible de lire mega-cluster:\n\n${e.message}")
                }
            }
        }.start()
    }

    private fun formatSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes o"
        if (bytes < 1024 * 1024) return "%.1f Ko".format(bytes / 1024.0)
        if (bytes < 1024L * 1024L * 1024L) return "%.1f Mo".format(bytes / (1024.0 * 1024.0))
        return "%.1f Go".format(bytes / (1024.0 * 1024.0 * 1024.0))
    }

    private fun openAndroidPicker() {
        try {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "Impossible d'ouvrir le sélecteur Android", Toast.LENGTH_LONG).show()
        }
    }


    private fun diagnoseProvider() {
        val authority = "com.example.megacluster.documents"
        val pm = packageManager
        val provider = pm.resolveContentProvider(authority, 0)
        val message = if (provider == null) {
            "❌ Provider NON trouvé\n\nAutorité testée : $authority\n\nCela signifie que l'APK installé ne contient pas la déclaration DocumentsProvider attendue."
        } else {
            "✅ Provider trouvé\n\nNom : ${provider.name}\nAutorité : ${provider.authority}\nExporté : ${provider.exported}\nPermission : ${provider.readPermission ?: "aucune"}\n\nAndroid reconnaît bien MEGA Cluster comme DocumentsProvider."
        }
        AlertDialog.Builder(this)
            .setTitle("Diagnostic MEGA Cluster")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun diagnoseRoots() {
        val authority = "com.example.megacluster.documents"
        try {
            val uri = DocumentsContract.buildRootsUri(authority)
            val projection = arrayOf(
                DocumentsContract.Root.COLUMN_ROOT_ID,
                DocumentsContract.Root.COLUMN_TITLE,
                DocumentsContract.Root.COLUMN_FLAGS,
                DocumentsContract.Root.COLUMN_DOCUMENT_ID,
                DocumentsContract.Root.COLUMN_MIME_TYPES
            )
            contentResolver.query(uri, projection, null, null, null).use { cursor ->
                if (cursor == null) {
                    showDiagnostic("❌ Android n'a pas retourné de curseur pour les racines.")
                    return
                }
                if (!cursor.moveToFirst()) {
                    showDiagnostic("❌ Provider trouvé, mais il ne retourne AUCUNE racine.\n\nC'est la raison pour laquelle le sélecteur ne peut pas afficher MEGA Cluster.")
                    return
                }
                val rootId = cursor.getString(cursor.getColumnIndexOrThrow(DocumentsContract.Root.COLUMN_ROOT_ID))
                val title = cursor.getString(cursor.getColumnIndexOrThrow(DocumentsContract.Root.COLUMN_TITLE))
                val flags = cursor.getLong(cursor.getColumnIndexOrThrow(DocumentsContract.Root.COLUMN_FLAGS))
                val documentId = cursor.getString(cursor.getColumnIndexOrThrow(DocumentsContract.Root.COLUMN_DOCUMENT_ID))
                val mime = cursor.getString(cursor.getColumnIndexOrThrow(DocumentsContract.Root.COLUMN_MIME_TYPES))
                showDiagnostic("✅ Racine trouvée\n\nTitre : $title\nID : $rootId\nDocument : $documentId\nFlags : $flags\nMIME : $mime\n\nAndroid reçoit bien la racine MEGA Cluster.")
            }
        } catch (e: Exception) {
            showDiagnostic("❌ Erreur lors de la lecture de la racine\n\n${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun openMegaClusterRoot() {
        val authority = "com.example.megacluster.documents"
        try {
            val rootId = "mega-cluster"
            val documentUri = DocumentsContract.buildDocumentUri(authority, rootId)
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(DocumentsContract.EXTRA_INITIAL_URI, documentUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (e: Exception) {
            showDiagnostic("❌ Impossible d'ouvrir directement MEGA Cluster\n\n${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun showDiagnostic(message: String) {
        AlertDialog.Builder(this)
            .setTitle("Diagnostic MEGA Cluster")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun rebuildUnion() {
        try {
            val remotes = Rclone.call("config/listremotes").optJSONArray("remotes") ?: JSONArray()
            val upstreams = mutableListOf<String>()
            for (i in 0 until remotes.length()) {
                val name = remotes.getString(i).removeSuffix(":")
                if (name.startsWith("mega") && name != "mega-cluster") {
                    upstreams += "$name:"
                }
            }

            if (upstreams.isEmpty()) {
                status.text = "Ajoute d'abord au moins un compte MEGA."
                return
            }

            try {
                Rclone.call("config/delete", JSONObject().put("name", "mega-cluster"))
            } catch (_: Exception) {
                // It is normal for the union not to exist on first launch.
            }

            val parameters = JSONObject()
                .put("upstreams", upstreams.joinToString(" "))
                .put("create_policy", "eplfs")
                .put("action_policy", "epall")
                .put("search_policy", "ff")

            Rclone.call(
                "config/create",
                JSONObject()
                    .put("name", "mega-cluster")
                    .put("type", "union")
                    .put("parameters", parameters)
            )
            status.text = "Cluster prêt : ${upstreams.size} compte(s)"
        } catch (e: Exception) {
            status.text = "Erreur cluster : ${e.message}"
        }
    }

}
