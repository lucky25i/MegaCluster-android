package com.example.megacluster

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.DocumentsContract
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var accounts: LinearLayout
    private val background = Executors.newSingleThreadExecutor()
    private val validationDelayMs = 3500L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Rclone.init(this)
        buildUi()
        refreshAccounts()
    }

    override fun onDestroy() {
        background.shutdownNow()
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }
        root.addView(TextView(this).apply { text = "MEGA Cluster"; textSize = 30f })
        root.addView(TextView(this).apply {
            text = "Plusieurs comptes MEGA dans un seul espace"
            textSize = 15f
            setPadding(0, 4, 0, 20)
        })
        status = TextView(this).apply { text = "Initialisation…"; textSize = 16f }
        root.addView(status)

        root.addView(primaryButton("➕ Ajouter un compte MEGA") { addMegaDialog() })
        root.addView(primaryButton("📁 Explorer le cluster") { openExplorer("") })
        root.addView(primaryButton("🔄 Tester les comptes un par un") { validateAllStoredAccounts() })
        root.addView(primaryButton("🔧 Reconstruire le cluster") { rebuildUnion() })

        val advanced = Button(this).apply {
            text = "Outils Android / diagnostic"
            setOnClickListener { openDiagnosticsMenu() }
        }
        root.addView(advanced)

        root.addView(TextView(this).apply {
            text = "Comptes enregistrés"
            textSize = 21f
            setPadding(0, 24, 0, 10)
        })
        accounts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(accounts)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun primaryButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        setOnClickListener { action() }
    }

    private fun addMegaDialog(prefill: CredentialStore.Account? = null, cloneFrom: CredentialStore.Account? = null) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 0, 20, 0)
        }
        val email = EditText(this).apply {
            hint = "E-mail MEGA"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            setText(prefill?.email ?: cloneFrom?.email ?: "")
        }
        val pass = passwordEditor("Mot de passe", prefill?.password ?: cloneFrom?.password ?: "")
        val twofa = EditText(this).apply {
            hint = "2FA (si nécessaire)"
            inputType = InputType.TYPE_CLASS_TEXT
            setText(prefill?.twoFa ?: cloneFrom?.twoFa ?: "")
        }
        box.addView(email)
        box.addView(pass)
        box.addView(twofa)

        val title = when {
            cloneFrom != null -> "Cloner ${cloneFrom.email}"
            prefill != null -> "Modifier le compte"
            else -> "Nouveau compte MEGA"
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton(if (prefill == null && cloneFrom == null) "Tester et ajouter" else "Tester et enregistrer", null)
            .setNegativeButton("Annuler", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val e = email.text.toString().trim()
                val p = pass.text.toString()
                val t = twofa.text.toString().trim()
                if (e.isBlank() || p.isBlank()) {
                    Toast.makeText(this, "E-mail et mot de passe obligatoires.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = false
                validateAndSave(e, p, t, prefill?.remote ?: cloneFrom?.remote, cloneFrom != null) {
                    dialog.dismiss()
                }
            }
        }
        dialog.show()
    }

    private fun passwordEditor(hint: String, value: String): EditText {
        return EditText(this).apply {
            this.hint = hint
            setText(value)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setCompoundDrawablesWithIntrinsicBounds(0, 0, android.R.drawable.ic_menu_view, 0)
            setOnTouchListener { v, event ->
                if (event.action == android.view.MotionEvent.ACTION_UP && event.rawX >= right - 80) {
                    inputType = if (inputType and InputType.TYPE_TEXT_VARIATION_PASSWORD != 0) {
                        InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    } else {
                        InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                    }
                    setSelection(text.length)
                    true
                } else false
            }
        }
    }

    private fun validateAndSave(
        email: String,
        password: String,
        twoFa: String,
        existingRemote: String?,
        isClone: Boolean,
        success: () -> Unit
    ) {
        status.text = "Test de connexion MEGA en cours…"
        background.execute {
            val remote = existingRemote ?: "mega${nextIndex()}"
            var created = false
            try {
                if (existingRemote == null) {
                    createMegaRemote(remote, email, password, twoFa)
                    created = true
                } else {
                    Rclone.call(
                        "config/update",
                        JSONObject()
                            .put("name", remote)
                            .put("parameters", JSONObject().put("user", email).put("pass", password).apply {
                                if (twoFa.isNotBlank()) put("2fa", twoFa) else remove("2fa")
                            })
                    )
                }
                testRemote(remote)
                CredentialStore.upsert(this, CredentialStore.Account(remote, email, password, twoFa))
                safeDisconnect(remote)
                runOnUiThread {
                    status.text = "Compte validé : $email"
                    refreshAccounts()
                    if (isClone) Toast.makeText(this, "Compte cloné et validé.", Toast.LENGTH_LONG).show()
                    success()
                }
            } catch (e: Exception) {
                safeDisconnect(remote)
                if (created) {
                    try { Rclone.call("config/delete", JSONObject().put("name", remote)) } catch (_: Exception) {}
                }
                runOnUiThread {
                    status.text = "Connexion refusée pour $email"
                    Toast.makeText(this, "❌ Connexion impossible : ${cleanError(e)}\n\nLe compte n'a pas été enregistré.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun createMegaRemote(name: String, email: String, password: String, twoFa: String) {
        val parameters = JSONObject().put("user", email).put("pass", password)
        if (twoFa.isNotBlank()) parameters.put("2fa", twoFa)
        Rclone.call(
            "config/create",
            JSONObject().put("name", name).put("type", "mega").put("parameters", parameters)
        )
    }

    private fun testRemote(remote: String) {
        // A real remote operation forces rclone to authenticate with MEGA.
        Rclone.call("operations/about", JSONObject().put("fs", "$remote:"))
    }

    private fun safeDisconnect(remote: String) {
        try { Rclone.call("config/disconnect", JSONObject().put("name", "$remote:")) } catch (_: Exception) {}
        // rclone documents that successive MEGA logins can trigger blocking; leave a pause.
        try { Thread.sleep(validationDelayMs) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
    }

    private fun validateAllStoredAccounts() {
        val list = CredentialStore.load(this).filter { it.password.isNotBlank() }
        if (list.isEmpty()) {
            Toast.makeText(this, "Aucun compte avec un mot de passe enregistré à tester.", Toast.LENGTH_LONG).show()
            return
        }
        status.text = "Validation séquentielle : 0/${list.size}"
        background.execute {
            var valid = 0
            list.forEachIndexed { index, account ->
                if (Thread.currentThread().isInterrupted) return@forEachIndexed
                runOnUiThread { status.text = "Test ${index + 1}/${list.size} : ${account.email}" }
                try {
                    testRemote(account.remote)
                    valid++
                    runOnUiThread { status.text = "✓ ${account.email} — ${index + 1}/${list.size}" }
                } catch (_: Exception) {
                    runOnUiThread { status.text = "✗ ${account.email} — ${index + 1}/${list.size}" }
                } finally {
                    safeDisconnect(account.remote)
                }
            }
            runOnUiThread {
                status.text = "$valid/${list.size} compte(s) valide(s)"
                refreshAccounts()
                if (valid >= 2) rebuildUnion() else Toast.makeText(this, "Il faut au moins 2 comptes valides pour le cluster.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun refreshAccounts() {
        try {
            val remotes = Rclone.call("config/listremotes").optJSONArray("remotes") ?: JSONArray()
            val saved = CredentialStore.load(this)
            accounts.removeAllViews()
            val names = mutableListOf<String>()
            for (i in 0 until remotes.length()) {
                val name = remotes.getString(i).removeSuffix(":")
                if (name.startsWith("mega") && name != "mega-cluster") names += name
            }
            if (names.isEmpty()) {
                accounts.addView(TextView(this).apply { text = "Aucun compte configuré."; setPadding(0, 8, 0, 8) })
            }
            names.sorted().forEach { name ->
                val account = saved.firstOrNull { it.remote == name }
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(16, 14, 16, 14)
                    setBackgroundResource(android.R.drawable.dialog_holo_light_frame)
                }
                card.addView(TextView(this).apply {
                    text = "☁ ${account?.email ?: name}"
                    textSize = 18f
                })
                card.addView(TextView(this).apply {
                    text = if (account?.password?.isNotBlank() == true) "🔐 Mot de passe enregistré" else "🔐 Mot de passe à renseigner pour l'affichage/copie"
                    textSize = 13f
                    setPadding(0, 4, 0, 8)
                })
                val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                actions.addView(smallButton("Gérer") { manageAccount(name) })
                actions.addView(smallButton("Cloner") { cloneAccount(name) })
                actions.addView(smallButton("Tester") { validateSingle(name) })
                card.addView(actions)
                accounts.addView(card)
            }
            status.text = "${names.size} compte(s) MEGA configuré(s)"
        } catch (e: Exception) {
            status.text = "Erreur : ${e.message}"
        }
    }

    private fun smallButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        setTextSize(12f)
        setOnClickListener { action() }
    }

    private fun manageAccount(remote: String) {
        val account = CredentialStore.find(this, remote)
        if (account == null) {
            AlertDialog.Builder(this)
                .setTitle("Compte $remote")
                .setMessage("Ce compte a été créé avec une ancienne version de l'application. Pour activer l'affichage et la copie du mot de passe, renseigne-le une fois.")
                .setPositiveButton("Renseigner") { _, _ -> addMegaDialog(prefill = CredentialStore.Account(remote, "", "")) }
                .setNegativeButton("Fermer", null)
                .show()
            return
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 0, 20, 0) }
        val email = EditText(this).apply { setText(account.email); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS }
        val pass = passwordEditor("Mot de passe", account.password)
        val copy = Button(this).apply {
            text = "📋 Copier le mot de passe"
            setOnClickListener { copyPassword(pass.text.toString()) }
        }
        box.addView(email); box.addView(pass); box.addView(copy)
        AlertDialog.Builder(this)
            .setTitle("Gérer le compte")
            .setView(box)
            .setPositiveButton("Enregistrer") { _, _ ->
                CredentialStore.upsert(this, account.copy(email = email.text.toString().trim(), password = pass.text.toString()))
                Toast.makeText(this, "Compte enregistré.", Toast.LENGTH_SHORT).show()
                refreshAccounts()
            }
            .setNeutralButton("Supprimer") { _, _ -> deleteAccount(remote) }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun copyPassword(password: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(
            ClipData.newPlainText("Mot de passe MEGA", password)
        )
        Toast.makeText(this, "Mot de passe copié dans le presse-papier.", Toast.LENGTH_SHORT).show()
    }

    private fun cloneAccount(remote: String) {
        val account = CredentialStore.find(this, remote)
        if (account == null || account.password.isBlank()) {
            Toast.makeText(this, "Renseigne d'abord le mot de passe de ce compte.", Toast.LENGTH_LONG).show()
            manageAccount(remote)
            return
        }
        addMegaDialog(cloneFrom = account)
    }

    private fun validateSingle(remote: String) {
        val account = CredentialStore.find(this, remote)
        if (account == null || account.password.isBlank()) {
            Toast.makeText(this, "Renseigne le mot de passe dans Gérer avant le test.", Toast.LENGTH_LONG).show()
            return
        }
        status.text = "Test de $remote…"
        background.execute {
            try {
                testRemote(remote)
                runOnUiThread { status.text = "✓ ${account.email} : connexion réussie" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "✗ ${account.email} : ${cleanError(e)}" }
            } finally {
                safeDisconnect(remote)
                runOnUiThread { refreshAccounts() }
            }
        }
    }

    private fun deleteAccount(remote: String) {
        try {
            Rclone.call("config/delete", JSONObject().put("name", remote))
            CredentialStore.remove(this, remote)
            try { Rclone.call("config/disconnect", JSONObject().put("name", "$remote:")) } catch (_: Exception) {}
            refreshAccounts()
            Toast.makeText(this, "Compte supprimé.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, cleanError(e), Toast.LENGTH_LONG).show()
        }
    }

    private fun nextIndex(): Int {
        val remotes = Rclone.call("config/listremotes").optJSONArray("remotes") ?: JSONArray()
        var max = 0
        for (i in 0 until remotes.length()) {
            val name = remotes.getString(i).removeSuffix(":")
            if (name.startsWith("mega") && name != "mega-cluster") {
                name.removePrefix("mega").toIntOrNull()?.let { max = maxOf(max, it) }
            }
        }
        return max + 1
    }

    private fun rebuildUnion() {
        try {
            val remotes = Rclone.call("config/listremotes").optJSONArray("remotes") ?: JSONArray()
            val upstreams = mutableListOf<String>()
            for (i in 0 until remotes.length()) {
                val name = remotes.getString(i).removeSuffix(":")
                if (name.startsWith("mega") && name != "mega-cluster") upstreams += "$name:"
            }
            if (upstreams.size < 2) {
                status.text = "Cluster non créé : il faut au moins 2 comptes MEGA."
                Toast.makeText(this, "Il faut au moins 2 comptes MEGA pour construire le cluster.", Toast.LENGTH_LONG).show()
                return
            }
            try { Rclone.call("config/delete", JSONObject().put("name", "mega-cluster")) } catch (_: Exception) {}
            val parameters = JSONObject()
                .put("upstreams", upstreams.joinToString(" "))
                .put("create_policy", "eplfs")
                .put("action_policy", "epall")
                .put("search_policy", "ff")
            Rclone.call("config/create", JSONObject().put("name", "mega-cluster").put("type", "union").put("parameters", parameters))
            status.text = "Cluster prêt : ${upstreams.size} compte(s)"
        } catch (e: Exception) {
            status.text = "Erreur cluster : ${cleanError(e)}"
        }
    }

    private fun cleanError(e: Exception): String {
        val raw = e.message ?: "Erreur inconnue"
        return raw.replace(Regex("pass(?:word)?\\s*[=:]\\s*[^\\s,}]+", RegexOption.IGNORE_CASE), "password=***")
    }

    private fun openExplorer(path: String) {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        root.addView(TextView(this).apply { text = if (path.isBlank()) "MEGA Cluster" else "MEGA Cluster / $path"; textSize = 24f })
        if (path.isNotBlank()) root.addView(Button(this).apply { text = "⬅ Dossier parent"; setOnClickListener { openExplorer(path.substringBeforeLast('/', "")) } })
        root.addView(Button(this).apply { text = "↻ Actualiser"; setOnClickListener { openExplorer(path) } })
        val statusView = TextView(this).apply { text = "Lecture du cluster…"; setPadding(0, 16, 0, 16) }
        root.addView(statusView)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        root.addView(Button(this).apply { text = "← Retour à MEGA Cluster"; setOnClickListener { buildUi(); refreshAccounts() } })
        setContentView(ScrollView(this).apply { addView(root) })
        background.execute {
            try {
                val result = Rclone.call("operations/list", JSONObject().put("fs", "mega-cluster:").put("remote", path).put("opt", JSONObject().put("filesOnly", false)))
                val items = result.optJSONArray("list") ?: JSONArray()
                runOnUiThread {
                    statusView.text = if (items.length() == 0) "Dossier vide" else "${items.length()} élément(s)"
                    for (i in 0 until items.length()) {
                        val item = items.getJSONObject(i)
                        val name = item.optString("Name")
                        if (name.isBlank()) continue
                        val isDir = item.optBoolean("IsDir", false)
                        val size = item.optLong("Size", 0L)
                        list.addView(Button(this).apply {
                            text = if (isDir) "📁 $name" else "📄 $name  (${formatSize(size)})"
                            setOnClickListener { if (isDir) openExplorer(if (path.isBlank()) name else "$path/$name") else showDiagnostic("Fichier : $name\n\nTaille : ${formatSize(size)}\n\nLe fichier est bien visible dans le cluster.") }
                        })
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { statusView.text = "Erreur lors de la lecture du cluster"; showDiagnostic("Impossible de lire mega-cluster:\n\n${cleanError(e)}") }
            }
        }
    }

    private fun formatSize(bytes: Long): String = when {
        bytes < 1024 -> "$bytes o"
        bytes < 1024 * 1024 -> "%.1f Ko".format(bytes / 1024.0)
        bytes < 1024L * 1024L * 1024L -> "%.1f Mo".format(bytes / (1024.0 * 1024.0))
        else -> "%.1f Go".format(bytes / (1024.0 * 1024.0 * 1024.0))
    }

    private fun openDiagnosticsMenu() {
        val items = arrayOf("Tester le sélecteur Android", "Diagnostiquer le fournisseur", "Tester la racine", "Ouvrir directement MEGA Cluster")
        AlertDialog.Builder(this).setTitle("Outils Android").setItems(items) { _, which -> when (which) {
            0 -> openAndroidPicker(); 1 -> diagnoseProvider(); 2 -> diagnoseRoots(); 3 -> openMegaClusterRoot()
        }}.show()
    }

    private fun openAndroidPicker() {
        try {
            startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            })
        } catch (e: Exception) { Toast.makeText(this, cleanError(e), Toast.LENGTH_LONG).show() }
    }

    private fun diagnoseProvider() {
        val authority = "com.example.megacluster.documents"
        val provider = packageManager.resolveContentProvider(authority, 0)
        showDiagnostic(if (provider == null) "❌ Provider NON trouvé" else "✅ Provider trouvé\n\nNom : ${provider.name}\nAutorité : ${provider.authority}\nExporté : ${provider.exported}")
    }

    private fun diagnoseRoots() {
        try {
            val uri = DocumentsContract.buildRootsUri("com.example.megacluster.documents")
            contentResolver.query(uri, null, null, null, null).use { cursor -> showDiagnostic(if (cursor != null && cursor.moveToFirst()) "✅ Racine MEGA Cluster trouvée." else "❌ Aucune racine retournée.") }
        } catch (e: Exception) { showDiagnostic("❌ ${cleanError(e)}") }
    }

    private fun openMegaClusterRoot() {
        try {
            startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                putExtra(DocumentsContract.EXTRA_INITIAL_URI, DocumentsContract.buildDocumentUri("com.example.megacluster.documents", "mega-cluster"))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            })
        } catch (e: Exception) { showDiagnostic("❌ ${cleanError(e)}") }
    }

    private fun showDiagnostic(message: String) = AlertDialog.Builder(this).setTitle("MEGA Cluster").setMessage(message).setPositiveButton("OK", null).show()
}
