package com.example.megacluster

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

/** Encrypted local storage for the credentials entered through the app UI. */
object CredentialStore {
    private const val PREFS = "mega_cluster_credentials"
    private const val KEY_DATA = "accounts"
    private const val KEYSTORE = "AndroidKeyStore"
    private const val KEY_ALIAS = "MegaClusterCredentialsKey"

    data class Account(
        val remote: String,
        val email: String,
        val password: String,
        val twoFa: String = ""
    )

    private fun secretKey(): SecretKey {
        val ks = java.security.KeyStore.getInstance(KEYSTORE).apply { load(null) }
        val existing = ks.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setUserAuthenticationRequired(false)
                .build()
        )
        return generator.generateKey()
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val iv = cipher.iv
        val encrypted = cipher.doFinal(value.toByteArray(StandardCharsets.UTF_8))
        return Base64.encodeToString(iv + encrypted, Base64.NO_WRAP)
    }

    private fun decrypt(value: String): String {
        val raw = Base64.decode(value, Base64.NO_WRAP)
        require(raw.size > 12) { "Données de compte invalides" }
        val iv = raw.copyOfRange(0, 12)
        val encrypted = raw.copyOfRange(12, raw.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(encrypted), StandardCharsets.UTF_8)
    }

    @Synchronized
    fun load(context: Context): MutableList<Account> {
        val encoded = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_DATA, null) ?: return mutableListOf()
        return try {
            val array = JSONArray(decrypt(encoded))
            MutableList(array.length()) { i ->
                val o = array.getJSONObject(i)
                Account(
                    o.getString("remote"),
                    o.getString("email"),
                    o.optString("password"),
                    o.optString("twoFa")
                )
            }
        } catch (_: Exception) {
            mutableListOf()
        }
    }

    @Synchronized
    fun save(context: Context, accounts: List<Account>) {
        val array = JSONArray()
        accounts.forEach {
            array.put(
                JSONObject()
                    .put("remote", it.remote)
                    .put("email", it.email)
                    .put("password", it.password)
                    .put("twoFa", it.twoFa)
            )
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_DATA, encrypt(array.toString()))
            .apply()
    }

    fun upsert(context: Context, account: Account) {
        val list = load(context)
        val index = list.indexOfFirst { it.remote == account.remote }
        if (index >= 0) list[index] = account else list.add(account)
        save(context, list)
    }

    fun remove(context: Context, remote: String) {
        save(context, load(context).filterNot { it.remote == remote })
    }

    fun find(context: Context, remote: String): Account? =
        load(context).firstOrNull { it.remote == remote }
}
