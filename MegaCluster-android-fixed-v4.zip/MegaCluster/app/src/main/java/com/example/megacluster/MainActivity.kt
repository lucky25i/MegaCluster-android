package com.example.megacluster

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var accounts: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Rclone.init(this)
        buildUi()
        refreshAccounts()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        root.addView(TextView(this).apply {
            text = "MEGA Cluster"
            textSize = 28f
        })

        status = TextView(this).apply {
            text = "Initialisation…"
            textSize = 16f
        }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "Ajouter un compte MEGA"
            setOnClickListener { addMegaDialog() }
        })

        root.addView(Button(this).apply {
            text = "Reconstruire le cluster"
            setOnClickListener { rebuildUnion() }
        })

        root.addView(Button(this).apply {
            text = "Tester MEGA Cluster dans le sélecteur Android"
            setOnClickListener { openAndroidPicker() }
        })

        accounts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        root.addView(accounts)

        setContentView(root)
    }

    private fun addMegaDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 0, 20, 0)
        }
        val email = EditText(this).apply {
            hint = "E-mail MEGA"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        }
        val pass = EditText(this).apply {
            hint = "Mot de passe"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val twofa = EditText(this).apply {
            hint = "2FA (si nécessaire)"
            inputType = InputType.TYPE_CLASS_TEXT
        }
        box.addView(email)
        box.addView(pass)
        box.addView(twofa)

        AlertDialog.Builder(this)
            .setTitle("Nouveau compte MEGA")
            .setView(box)
            .setPositiveButton("Ajouter") { _, _ ->
                try {
                    val name = "mega${nextIndex()}"
                    val parameters = JSONObject()
                        .put("user", email.text.toString().trim())
                        .put("pass", pass.text.toString())
                    if (twofa.text.toString().isNotBlank()) {
                        parameters.put("2fa", twofa.text.toString().trim())
                    }
                    Rclone.call(
                        "config/create",
                        JSONObject()
                            .put("name", name)
                            .put("type", "mega")
                            .put("parameters", parameters)
                    )
                    rebuildUnion()
                    refreshAccounts()
                } catch (e: Exception) {
                    Toast.makeText(this, e.message ?: "Erreur MEGA", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun nextIndex(): Int {
        val remotes = Rclone.call("config/listremotes").optJSONArray("remotes") ?: JSONArray()
        var max = 0
        for (i in 0 until remotes.length()) {
            val name = remotes.getString(i).removeSuffix(":")
            if (name.startsWith("mega")) {
                name.removePrefix("mega").toIntOrNull()?.let { max = maxOf(max, it) }
            }
        }
        return max + 1
    }

    private fun refreshAccounts() {
        try {
            val remotes = Rclone.call("config/listremotes").optJSONArray("remotes") ?: JSONArray()
            accounts.removeAllViews()
            var count = 0
            for (i in 0 until remotes.length()) {
                val name = remotes.getString(i).removeSuffix(":")
                if (name.startsWith("mega") && name != "mega-cluster") {
                    accounts.addView(TextView(this).apply {
                        text = "☁ $name"
                        textSize = 18f
                    })
                    count++
                }
            }
            status.text = "$count compte(s) MEGA configuré(s)"
        } catch (e: Exception) {
            status.text = "Erreur : ${e.message}"
        }
    }

    private fun openAndroidPicker() {
        try {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "Impossible d'ouvrir le sélecteur Android", Toast.LENGTH_LONG).show()
        }
    }

    private fun rebuildUnion() {
        try {
            val remotes = Rclone.call("config/listremotes").optJSONArray("remotes") ?: JSONArray()
            val upstreams = mutableListOf<String>()
            for (i in 0 until remotes.length()) {
                val name = remotes.getString(i).removeSuffix(":")
                if (name.startsWith("mega") && name != "mega-cluster") {
                    upstreams += "$name:"
                }
            }

            if (upstreams.isEmpty()) {
                status.text = "Ajoute d'abord au moins un compte MEGA."
                return
            }

            try {
                Rclone.call("config/delete", JSONObject().put("name", "mega-cluster"))
            } catch (_: Exception) {
                // It is normal for the union not to exist on first launch.
            }

            val parameters = JSONObject()
                .put("upstreams", upstreams.joinToString(" "))
                .put("create_policy", "eplfs")
                .put("action_policy", "epall")
                .put("search_policy", "ff")

            Rclone.call(
                "config/create",
                JSONObject()
                    .put("name", "mega-cluster")
                    .put("type", "union")
                    .put("parameters", parameters)
            )
            status.text = "Cluster prêt : ${upstreams.size} compte(s)"
        } catch (e: Exception) {
            status.text = "Erreur cluster : ${e.message}"
        }
    }

}
