//! Debug commands for troubleshooting and developer tools
//!
//! These commands are available via both desktop and headless modes.

use serde::Serialize;
use tauri::AppHandle;

use crate::core::{bridge, paths::AppPaths};

/// Debug information response
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DebugInfo {
    pub logs_dir: String,
    pub config_dir: String,
    pub cache_dir: String,
    pub mode: String,
    pub app_version: String,
    pub platform: String,
    pub arch: String,
}

/// Get debug information (paths, versions, build info)
#[bridge]
pub fn get_debug_info(app: AppHandle) -> Result<DebugInfo, String> {
    // Get paths from centralized AppPaths
    let paths = AppPaths::from_app_handle(&app)?;

    // Runtime mode (build-time selected, but user-visible as runtime behavior)
    let mode = if cfg!(feature = "web-server") {
        "headless"
    } else {
        "desktop"
    };

    let app_version = app.package_info().version.to_string();

    Ok(DebugInfo {
        logs_dir: paths.logs_dir.to_string_lossy().to_string(),
        config_dir: paths.config_dir.to_string_lossy().to_string(),
        cache_dir: paths.cache_dir.to_string_lossy().to_string(),
        mode: mode.to_string(),
        app_version,
        platform: std::env::consts::OS.to_string(),
        arch: std::env::consts::ARCH.to_string(),
    })
}

/// Open `WebView` developer tools
#[bridge]
#[cfg(all(
    not(feature = "web-server"),
    not(target_os = "android"),
    not(target_os = "ios")
))]
pub fn open_devtools(window: tauri::WebviewWindow) -> Result<String, String> {
    window.open_devtools();
    log::debug!("🔧 Opened DevTools for window: {}", window.label());
    Ok("DevTools opened".to_string())
}
