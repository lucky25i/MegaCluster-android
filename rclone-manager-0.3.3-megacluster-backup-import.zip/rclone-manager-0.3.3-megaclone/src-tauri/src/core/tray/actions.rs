use crate::core::settings::AppSettingsManager;
use log::{error, info};
use tauri::{AppHandle, Manager};

use crate::utils::spawn;
use crate::utils::types::origin::Origin;
use crate::{
    rclone::{
        backend::BackendManager,
        commands::{
            job::stop_job,
            mount::{mount_remote_profile, unmount_remote},
            serve::{start_serve_profile, stop_serve},
            sync::start_profile_batch,
        },
    },
    utils::{
        app::notification::{JobStage, NotificationEvent, SystemStage, notify},
        types::{
            jobs::{JobStatus, JobType},
            remotes::{OperationType, ProfileParams},
        },
    },
};

#[cfg(not(feature = "web-server"))]
pub fn show_main_window(app: AppHandle) {
    info!("Presenting main window");
    crate::utils::app::builder::present_main_window(&app);
}

fn profile_params(remote_name: &str, profile_name: &str) -> ProfileParams {
    ProfileParams {
        remote_name: remote_name.to_string(),
        profile_name: profile_name.to_string(),
        source: Some(Origin::Dashboard),
        no_cache: None,
        scoped_targets: None,
    }
}

// Quick Runs

pub fn handle_start_quick_run(app: AppHandle, quick_run_id: String) {
    spawn(async move {
        match crate::core::flow::quick_run::commands::start_quick_run(
            app,
            quick_run_id.clone(),
            None,
            None,
        )
        .await
        {
            Ok(res) => info!(
                "Started quick run {quick_run_id} (job id: {:?}, exec id: {})",
                res.job_id, res.execute_id
            ),
            Err(e) => error!("Failed to start quick run {quick_run_id}: {e}"),
        }
    });
}

pub fn handle_stop_quick_run(app: AppHandle, quick_run_id: String) {
    spawn(async move {
        match crate::core::flow::quick_run::commands::stop_quick_run(
            app,
            quick_run_id.clone(),
            None,
        )
        .await
        {
            Ok(()) => info!("Stopped quick run {quick_run_id}"),
            Err(e) => error!("Failed to stop quick run {quick_run_id}: {e}"),
        }
    });
}

// Workflows

pub fn handle_start_workflow(app: AppHandle, workflow_id: String) {
    spawn(async move {
        match crate::core::flow::workflow::engine::execute_workflow(app, workflow_id.clone(), false)
            .await
        {
            Ok(res) => info!(
                "Workflow {workflow_id} executed from tray: success={}",
                res.success
            ),
            Err(e) => error!("Failed to execute workflow {workflow_id} from tray: {e}"),
        }
    });
}

pub fn handle_stop_workflow(app: AppHandle, workflow_id: String) {
    spawn(async move {
        match crate::core::flow::workflow::engine::stop_workflow(&app, &workflow_id).await {
            Ok(()) => info!("Stopped workflow {workflow_id} from tray"),
            Err(e) => error!("Failed to stop workflow {workflow_id} from tray: {e}"),
        }
    });
}

// Transfer jobs

pub fn handle_start_job_profile(
    app: AppHandle,
    remote_name: &str,
    profile_name: &str,
    transfer_type: OperationType,
) {
    let params = profile_params(remote_name, profile_name);
    let remote = remote_name.to_string();
    let profile = profile_name.to_string();
    let type_label = format!("{transfer_type:?}");

    spawn(async move {
        match start_profile_batch(app, transfer_type, params).await {
            Ok(_) => info!("Started {type_label} for {remote} / {profile}"),
            Err(e) => error!("Failed to start {type_label} for {remote} / {profile}: {e}"),
        }
    });
}

pub fn handle_stop_job_profile(
    app: AppHandle,
    remote_name: &str,
    profile_name: &str,
    job_type: JobType,
) {
    let remote = remote_name.to_string();
    let profile = profile_name.to_string();

    spawn(async move {
        let backend_manager = app.state::<BackendManager>();
        let running_job = backend_manager
            .job_cache
            .get_jobs()
            .await
            .into_iter()
            .find(|j| {
                j.remote_name == remote
                    && j.job_type == job_type
                    && j.profile.as_deref() == Some(&profile)
                    && j.status == JobStatus::Running
            });

        if let Some(job) = running_job {
            match stop_job(app.clone(), job.jobid, remote.clone()).await {
                Ok(()) => info!(
                    "Stopped {job_type} job {} for {remote} / {profile}",
                    job.jobid
                ),
                Err(e) => error!("Failed to stop {job_type} job {}: {e}", job.jobid),
            }
        } else {
            error!("No active {job_type} job found for {remote} / {profile}");
            let backend_name = backend_manager.get_active_name().await;
            notify(
                &app,
                NotificationEvent::Job(JobStage::Failed {
                    backend: backend_name,
                    remote,
                    profile: Some(profile),
                    job_type,
                    error: "no active job".to_string(),
                    origin: Origin::Dashboard,
                    source: None,
                    destination: None,
                }),
            );
        }
    });
}

// Mount

fn get_mount_dest(manager: &AppSettingsManager, remote: &str, profile: &str) -> Option<String> {
    let settings = crate::utils::types::remotes::RemoteSettings::load(manager, remote).ok()?;
    let mount_configs = settings.mount_configs.as_ref()?;
    let config_profile = mount_configs.get(profile)?;
    config_profile.dest_str().map(str::to_string)
}

pub fn handle_mount_profile(app: AppHandle, remote_name: &str, profile_name: &str) {
    let params = profile_params(remote_name, profile_name);
    let remote = remote_name.to_string();
    let profile = profile_name.to_string();

    spawn(async move {
        match mount_remote_profile(app, params).await {
            Ok(()) => info!("Mounted {remote} / {profile}"),
            Err(e) => error!("Failed to mount {remote} / {profile}: {e}"),
        }
    });
}

pub fn handle_unmount_profile(app: AppHandle, remote_name: &str, profile_name: &str) {
    let remote = remote_name.to_string();
    let profile = profile_name.to_string();

    spawn(async move {
        let manager = app.state::<AppSettingsManager>();
        let mount_point = get_mount_dest(&manager, &remote, &profile).unwrap_or_default();

        match unmount_remote(app, mount_point.clone(), remote.clone()).await {
            Ok(_) => info!("Unmounted {remote} / {profile}"),
            Err(e) => error!("Failed to unmount {remote} / {profile}: {e}"),
        }
    });
}

// Serve

pub fn handle_serve_profile(app: AppHandle, remote_name: &str, profile_name: &str) {
    let params = profile_params(remote_name, profile_name);
    let remote = remote_name.to_string();
    let profile = profile_name.to_string();

    spawn(async move {
        match start_serve_profile(app, params).await {
            Ok(response) => info!(
                "Started serve for {remote} / {profile} at {}",
                response.addr
            ),
            Err(e) => error!("Failed to start serve for {remote} / {profile}: {e}"),
        }
    });
}

pub fn handle_stop_serve_profile(app: AppHandle, serve_id: &str) {
    let serve_id = serve_id.to_string();

    spawn(async move {
        let backend_manager = app.state::<BackendManager>();
        let all_serves = backend_manager.remote_cache.get_serves().await;

        let instance = all_serves
            .iter()
            .find(|s| s.profile.as_deref() == Some(&serve_id) || s.id == serve_id);

        let actual_id = instance
            .map(|s| s.id.clone())
            .unwrap_or_else(|| serve_id.clone());
        let remote_name = instance.and_then(|s| s.params["fs"].as_str()).map_or_else(
            || "unknown_remote".to_string(),
            |fs| fs.split(':').next().unwrap_or("").to_string(),
        );

        match stop_serve(app.clone(), actual_id.clone(), remote_name.clone()).await {
            Ok(_) => info!("Stopped serve {actual_id} for {remote_name}"),
            Err(e) => error!("Failed to stop serve {actual_id}: {e}"),
        }
    });
}

// Global actions

pub fn handle_stop_all_jobs(app: AppHandle) {
    spawn(async move {
        match crate::core::lifecycle::shutdown::stop_all_active_jobs(app.clone()).await {
            Ok(()) => {
                notify(&app, NotificationEvent::System(SystemStage::AllJobsStopped));
            }
            Err(e) => error!("Failed to stop all active jobs: {e}"),
        }
    });
}

#[cfg(not(feature = "web-server"))]
pub fn handle_browse_remote(app: &AppHandle, remote_name: &str, profile_name: &str) {
    use tauri_plugin_opener::OpenerExt;
    let remote = remote_name.to_string();
    let profile = profile_name.to_string();
    let app_clone = app.clone();

    spawn(async move {
        let mount_point =
            get_mount_dest(&app_clone.state::<AppSettingsManager>(), &remote, &profile)
                .unwrap_or_default();

        match app_clone.opener().open_path(mount_point, None::<&str>) {
            Ok(()) => info!("Opened file manager for {remote} / {profile}"),
            Err(e) => error!("Failed to open file manager for {remote} / {profile}: {e}"),
        }
    });
}

#[cfg(not(feature = "web-server"))]
pub fn handle_browse_in_app(app: &AppHandle, remote_name: Option<&str>) {
    info!(
        "Opening in-app browser{}",
        remote_name.map(|n| format!(" for {n}")).unwrap_or_default()
    );

    let label = remote_name
        .map(|name| {
            let slug: String = name
                .chars()
                .map(|c| {
                    if c.is_alphanumeric() || c == '-' {
                        c
                    } else {
                        '_'
                    }
                })
                .collect();
            format!("nautilus-{slug}")
        })
        .unwrap_or_else(|| "nautilus".to_string());

    let url = match remote_name {
        Some(name) => format!("index.html#/nautilus/{}", urlencoding::encode(name)),
        None => "index.html#/nautilus".to_string(),
    };

    let remote_name_owned = remote_name.map(std::string::ToString::to_string);
    let app_clone = app.clone();
    spawn(async move {
        crate::utils::app::builder::new_window(
            app_clone,
            crate::utils::app::builder::WindowOptions {
                label,
                url,
                title: "RClone Nautilus".to_string(),
                width: Some(1024.0),
                height: Some(768.0),
                remote: remote_name_owned,
                path: None,
            },
        )
        .await;
    });
}
