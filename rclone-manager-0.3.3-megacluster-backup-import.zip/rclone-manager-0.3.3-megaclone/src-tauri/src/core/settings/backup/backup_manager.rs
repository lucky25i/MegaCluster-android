//! Backup management using rcman library
//!
//! This module provides backup and analysis commands using the rcman library.

use crate::core::{bridge, settings::AppSettingsManager};
use crate::rclone::queries::get_rclone_config_file;
use crate::utils::types::backup_types::{BackupAnalysis, BackupContentsInfo, ExportType};
use log::{error, info};
use std::path::PathBuf;
use tauri::{AppHandle, Manager};

// BACKUP COMMAND

#[bridge]
#[allow(clippy::too_many_arguments)]
pub async fn backup_settings(
    app_handle: AppHandle,
    backup_dir: String,
    export_type: ExportType,
    password: Option<String>,
    remote_name: Option<String>,
    user_note: Option<String>,
    include_profiles: Option<Vec<String>>,
    include_secrets: Option<bool>,
) -> Result<String, String> {
    let manager = app_handle.state::<AppSettingsManager>();
    info!("Starting backup with rcman to: {backup_dir}");

    // Map app's ExportType to rcman's ExportType
    let rcman_export_type = match &export_type {
        ExportType::All => rcman::ExportType::Full,
        ExportType::Settings => rcman::ExportType::SettingsOnly,
        ExportType::SpecificRemote => rcman::ExportType::Single {
            settings_type: "remotes".into(),
            name: remote_name.clone().unwrap_or_default(),
        },
        ExportType::Category(_) => rcman::ExportType::SettingsOnly,
    };

    // Build rcman backup options
    let mut options = rcman::BackupOptions::new()
        .output_dir(&backup_dir)
        .export_type(rcman_export_type);

    if matches!(
        export_type,
        ExportType::Category(_) | ExportType::SpecificRemote
    ) {
        options = options.include_settings(false);
    }

    if let ExportType::Category(ref category) = export_type {
        if category == "alerts" {
            options = options.include_sub_settings(crate::utils::constants::SUB_ALERTS_RULES);
            options = options.include_sub_settings(crate::utils::constants::SUB_ALERTS_ACTIONS);
        } else {
            options = options.include_sub_settings(category);
        }
        if category == "remotes" {
            register_rclone_config_provider(&app_handle, &manager).await?;
            options = options.include_external("rclone.conf");
        }
        options = options.filename_suffix(category);
    }

    if matches!(export_type, ExportType::All) {
        register_rclone_config_provider(&app_handle, &manager).await?;
        options = options.include_external("rclone.conf");
        options = options.include_sub_settings(crate::utils::constants::SUB_REMOTES);
        options = options.include_sub_settings(crate::utils::constants::SUB_BACKEND);
        options = options.include_sub_settings(crate::utils::constants::SUB_CONNECTIONS);
        options = options.include_sub_settings(crate::utils::constants::SUB_ALERTS_RULES);
        options = options.include_sub_settings(crate::utils::constants::SUB_ALERTS_ACTIONS);
        options = options.include_sub_settings(crate::utils::constants::SUB_QUICK_RUNS);
        options = options.include_sub_settings(crate::utils::constants::SUB_WORKFLOWS);
        options = options.include_sub_settings(crate::utils::constants::SUB_TEMPLATES);
    }

    if matches!(export_type, ExportType::SpecificRemote)
        && let Some(ref name) = remote_name
    {
        use super::rclone_config_provider::RcloneConfigProvider;
        use crate::rclone::backend::BackendManager;
        let backend_manager = app_handle.state::<BackendManager>();

        let all_configs = backend_manager.remote_cache.get_configs().await;
        let remote_config = all_configs.get(name).cloned();

        let provider = RcloneConfigProvider::for_remote(name, remote_config)
            .map_err(|e| format!("Failed to serialize remote config: {e}"))?;
        manager.register_external_provider(Box::new(provider));
        options = options.include_external(format!("remote:{name}"));
    }

    if let Some(ref pw) = password {
        let trimmed = pw.trim();
        if !trimmed.is_empty() {
            options = options.password(trimmed);
        }
    }

    // Determine secret export policy
    let include_secrets_flag = include_secrets.unwrap_or(false);
    if include_secrets_flag {
        // If user requested including secrets, require a valid password to avoid plaintext secrets
        let pw_ok = password.as_ref().is_some_and(|s| s.trim().len() >= 4);
        if !pw_ok {
            return Err(crate::localized_error!(
                "backendErrors.backup.secretRequirePassword"
            ));
        }
        options = options.secret_policy(rcman::SecretBackupPolicy::EncryptedOnly);
    } else {
        options = options.secret_policy(rcman::SecretBackupPolicy::Exclude);
    }

    if let Some(note) = user_note {
        options = options.note(note);
    }

    if let Some(profiles) = include_profiles {
        for profile in profiles {
            options = options.include_profile(profile);
        }
    }

    let backup_path = manager.backup().create(&options).map_err(|e| {
        error!("Backup failed: {e}");
        format!("Backup failed: {e}")
    })?;

    info!("Backup complete: {}", backup_path.display());
    Ok(format!("Backup created at: {}", backup_path.display()))
}

pub(super) async fn register_rclone_config_provider(
    app_handle: &AppHandle,
    manager: &AppSettingsManager,
) -> Result<(), String> {
    use crate::core::settings::backup::rclone_config_provider::RcloneConfigProvider;

    let config_path = get_rclone_config_file(app_handle.clone())
        .await
        .map_err(|e| format!("Failed to fetch rclone config path: {e}"))?;

    manager.register_external_provider(Box::new(RcloneConfigProvider::from_path(config_path)));

    Ok(())
}

// BACKUP ANALYSIS

#[bridge]
pub async fn analyze_backup_file(
    app_handle: AppHandle,
    path: PathBuf,
) -> Result<BackupAnalysis, String> {
    let manager = app_handle.state::<AppSettingsManager>();
    let ext = path
        .extension()
        .and_then(|s| s.to_str())
        .unwrap_or("")
        .to_lowercase();

    if ext != "rcman" {
        return Err(crate::localized_error!(
            "backendErrors.backup.unsupportedArchive"
        ));
    }

    match manager.backup().analyze(&path) {
        Ok(analysis) => {
            let contents = BackupContentsInfo {
                settings: analysis.manifest.contents.settings,
                backend_config: analysis
                    .manifest
                    .contents
                    .sub_settings
                    .contains_key("backend"),
                rclone_config: analysis
                    .manifest
                    .contents
                    .external_configs
                    .iter()
                    .any(|id| id == "rclone.conf" || id == "rclone_config"),
                remote_count: analysis.manifest.contents.sub_settings.get("remotes").map(
                    |r| match r {
                        rcman::SubSettingsManifestEntry::MultiFile(items) => items.len(),
                        rcman::SubSettingsManifestEntry::SingleFile(_) => 1,
                        rcman::SubSettingsManifestEntry::Profiled { profiles } => profiles
                            .values()
                            .map(|entry| match entry {
                                rcman::ProfileEntry::Single(_) => 1,
                                rcman::ProfileEntry::Multiple(items) => items.len(),
                            })
                            .sum(),
                    },
                ),
                remote_names: analysis.manifest.contents.sub_settings.get("remotes").map(
                    |r| match r {
                        rcman::SubSettingsManifestEntry::MultiFile(items) => items.clone(),
                        rcman::SubSettingsManifestEntry::SingleFile(name) => vec![name.clone()],
                        rcman::SubSettingsManifestEntry::Profiled { profiles } => {
                            let mut names = Vec::new();
                            for (profile, entry) in profiles {
                                match entry {
                                    rcman::ProfileEntry::Single(item) => {
                                        names.push(format!("{profile}: {item}"));
                                    }
                                    rcman::ProfileEntry::Multiple(items) => {
                                        for item in items {
                                            names.push(format!("{profile}: {item}"));
                                        }
                                    }
                                }
                            }
                            names
                        }
                    },
                ),
                profiles: analysis
                    .manifest
                    .contents
                    .sub_settings
                    .get("remotes")
                    .and_then(|r| match r {
                        rcman::SubSettingsManifestEntry::Profiled { profiles } => {
                            Some(profiles.keys().cloned().collect())
                        }
                        _ => None,
                    }),
            };

            Ok(BackupAnalysis {
                is_encrypted: analysis.is_encrypted,
                archive_type: if analysis.requires_password {
                    "zip-aes".into()
                } else {
                    "zip".into()
                },
                format_version: analysis.format_version,
                created_at: Some(analysis.created_at),
                backup_type: Some(analysis.backup_type),
                user_note: analysis.user_note,
                contents: Some(contents),
            })
        }
        Err(e) => Err(crate::localized_error!(
            "backendErrors.backup.invalidArchive",
            "error" => e
        )),
    }
}
