use std::sync::atomic::Ordering;
use std::time::Duration;

use log::{info, warn};
use tauri::{AppHandle, Manager};
use tokio::time::sleep;

use crate::core::settings::AppSettingsManager;

/// How often to poll for updates in the background.
const UPDATE_CHECK_INTERVAL: Duration = Duration::from_secs(4 * 60 * 60);

/// Starts the auto-update background task (no-op if already running).
pub fn init_auto_updater(app: AppHandle) {
    if app
        .state::<crate::utils::types::state::RcloneState>()
        .updater_running
        .swap(true, Ordering::AcqRel)
    {
        warn!("Auto-updater is already running");
        return;
    }

    info!(
        "Initializing auto-updater (interval: {}h)",
        UPDATE_CHECK_INTERVAL.as_secs() / 3600
    );

    crate::utils::spawn(async move {
        // Run initial check immediately on startup
        run_update_checks(&app).await;

        while app
            .state::<crate::utils::types::state::RcloneState>()
            .updater_running
            .load(Ordering::Acquire)
        {
            sleep(UPDATE_CHECK_INTERVAL).await;
            run_update_checks(&app).await;
        }

        info!("Auto-updater stopped.");
    });
}

/// Signals the background task to exit on its next iteration.
pub fn stop_auto_updater(app: &AppHandle) {
    let state = app.state::<crate::utils::types::state::RcloneState>();
    state.updater_running.store(false, Ordering::Release);
}

async fn run_update_checks(app: &AppHandle) {
    info!("Running scheduled update checks...");

    let config = app
        .state::<AppSettingsManager>()
        .get_all()
        .unwrap_or_default();

    if config.runtime.app_auto_check_updates {
        let channel = config.runtime.app_update_channel.clone();
        info!("Checking for app updates (channel: {channel})...");
        if let Err(e) = check_app_update(app, &channel).await {
            warn!("App update check failed: {e}");
        }
    }

    #[cfg(not(feature = "librclone"))]
    if config.runtime.rclone_auto_check_updates {
        let channel = config.runtime.rclone_update_channel.clone();
        info!("Checking for rclone updates (channel: {channel})...");
        if let Err(e) =
            crate::utils::rclone::updater::check_rclone_update(app.clone(), Some(channel)).await
        {
            warn!("Rclone update check failed: {e}");
        }
    }
}

async fn check_app_update(app: &AppHandle, channel: &str) -> Result<(), String> {
    crate::utils::app::updater::fetch_update(app.clone(), channel.to_string())
        .await
        .map(|_| ())
        .map_err(|e| e.to_string())
}
