use log::{error, info};
use tauri::{AppHandle, Manager};

use crate::core::settings::AppSettingsManager;
use crate::rclone::backend::BackendManager;
use crate::utils::types::events::SYSTEM_STATUS;
use crate::utils::types::monitoring::SystemStatusPayload;
use crate::utils::types::state::{RcApiEngine, RcloneState};
use crate::utils::{
    process::process_manager::kill_processes_on_port,
    rclone::{
        endpoints::core,
        process_common::{build_rclone_process_command, graceful_shutdown},
    },
};

use super::error::{EngineError, EngineResult};

impl RcApiEngine {
    pub async fn spawn_process(&mut self, app: &AppHandle) -> EngineResult<tokio::process::Child> {
        let backend_manager = app.state::<BackendManager>();
        let backend = backend_manager.get_active().await;

        self.current_api_port = backend.port;

        let engine_cmd = match build_rclone_process_command(app).await {
            Ok(cmd) => cmd,
            Err(e) => {
                error!("Failed to create engine command: {e}");
                if let EngineError::PasswordRequired = e {
                    self.mark_password_failed();
                }
                return Err(e);
            }
        };

        match engine_cmd.spawn() {
            Ok(child) => {
                info!("Rclone process spawned");
                #[cfg(not(feature = "librclone"))]
                if matches!(
                    self.phase,
                    crate::utils::types::state::EnginePhase::FailedPath
                ) {
                    self.clear_errors();
                }
                Ok(child)
            }
            Err(e) => {
                error!("Failed to spawn rclone process: {e}");
                if e.kind() == std::io::ErrorKind::NotFound {
                    self.mark_path_failed();
                    return Err(EngineError::InvalidPath);
                }
                self.mark_other_failed(e.to_string());
                Err(EngineError::SpawnFailed(e.to_string()))
            }
        }
    }

    pub async fn kill_process(&mut self, app: &AppHandle) -> EngineResult<()> {
        let backend_manager = app.state::<BackendManager>();
        let backend = backend_manager.get_active().await;

        if let Some(child) = self.process.take() {
            if child.id().is_some() {
                let state = app.state::<RcloneState>();
                let quit_request =
                    backend.inject_auth(state.client.post(backend.url_for(core::QUIT)));

                if let Err(e) = graceful_shutdown(child, quit_request).await {
                    log::warn!("Graceful shutdown failed: {e}");
                }
            } else {
                log::debug!("Engine process had already terminated");
            }
        }

        if backend.is_local {
            let _ = kill_processes_on_port(backend.port);
        }

        self.mark_stopped();

        if backend.is_auth_generated {
            let mut updated_backend = backend.clone();
            updated_backend.username = None;
            updated_backend.password = None;
            updated_backend.is_auth_generated = false;
            let settings_manager = app.state::<AppSettingsManager>();
            let _ = backend_manager
                .update(&settings_manager, &backend.name, updated_backend)
                .await;
        }

        crate::core::bridge::emit(SYSTEM_STATUS, SystemStatusPayload::inactive());

        Ok(())
    }
}
