use log::debug;
use serde_json::{Value, json};
use tauri::{AppHandle, Manager};

use crate::utils::logging::log::log_operation;
use crate::utils::rclone::endpoints::{core, operations};
use crate::utils::types::jobs::JobType;
use crate::utils::types::logs::LogLevel;
use crate::utils::types::origin::Origin;
use crate::utils::types::state::RcloneState;
use crate::{
    core::bridge,
    rclone::{
        backend::BackendManager,
        commands::job::{JobMetadata, SubmitJobOptions, submit_job_with_options},
    },
};

#[bridge]
pub async fn archive_create(
    app: AppHandle,
    source: String,
    destination: String,
    format: Option<String>,
    prefix: Option<String>,
    full_path: Option<bool>,
    include: Option<Vec<String>>,
) -> Result<Value, String> {
    debug!("archive_create: source={source} destination={destination} include={include:?}");

    let backend_manager = app.state::<BackendManager>();
    let backend = backend_manager.get_active().await;

    let group_id = format!("archive_create_{}", uuid::Uuid::new_v4().simple());

    let (endpoint, mut payload) = if backend.is_librclone_local() {
        let mut p = json!({
            "action": "create",
            "src": source,
            "dst": destination,
            "_async": true,
        });

        if let Some(f) = format {
            p["format"] = json!(f);
        }
        if let Some(pr) = prefix {
            p["prefix"] = json!(pr);
        }
        if let Some(fp) = full_path {
            p["full_path"] = json!(fp);
        }
        if let Some(inc) = include {
            p["include"] = json!(inc);
        }
        (operations::ARCHIVE, p)
    } else {
        let mut args = vec!["create".to_string(), source.clone(), destination.clone()];
        if let Some(f) = format {
            args.push(format!("--format={f}"));
        }
        if let Some(p) = prefix {
            args.push(format!("--prefix={p}"));
        }
        if full_path.unwrap_or(false) {
            args.push("--full-path".to_string());
        }
        if let Some(inc) = include {
            for i in inc {
                args.push(format!("--include={i}"));
            }
        }
        let os = backend_manager.get_runtime_os(&backend.name).await;
        (
            core::COMMAND,
            backend.build_core_command_payload("archive", args, true, os),
        )
    };

    crate::rclone::commands::common::ensure_group(&mut payload, &group_id);

    let metadata = JobMetadata::new(
        destination.clone(),
        JobType::ArchiveCreate,
        vec![source.clone()],
        destination.clone(),
    )
    .with_origin(Some(Origin::FileManager))
    .with_group(Some(group_id))
    .with_execute_id(Some(uuid::Uuid::new_v4().to_string()));

    let (jobid, _response, _execute_id) = submit_job_with_options(
        app.clone(),
        endpoint,
        payload,
        metadata,
        SubmitJobOptions {
            wait_for_completion: false,
        },
    )
    .await?;

    Ok(json!({ "success": true, "jobid": jobid }))
}

#[bridge]
pub async fn archive_extract(
    app: AppHandle,
    source: String,
    destination: String,
) -> Result<Value, String> {
    debug!("archive_extract: source={source} destination={destination}");

    let backend_manager = app.state::<BackendManager>();
    let backend = backend_manager.get_active().await;

    let group_id = format!("archive_extract_{}", uuid::Uuid::new_v4().simple());

    let (endpoint, mut payload) = if backend.is_librclone_local() {
        (
            operations::ARCHIVE,
            json!({
                "action": "extract",
                "src": source,
                "dst": destination,
                "_async": true,
            }),
        )
    } else {
        let args = vec!["extract".to_string(), source.clone(), destination.clone()];
        let os = backend_manager.get_runtime_os(&backend.name).await;
        (
            core::COMMAND,
            backend.build_core_command_payload("archive", args, true, os),
        )
    };

    crate::rclone::commands::common::ensure_group(&mut payload, &group_id);

    let metadata = JobMetadata::new(
        source.clone(),
        JobType::ArchiveExtract,
        vec![source.clone()],
        destination.clone(),
    )
    .with_origin(Some(Origin::FileManager))
    .with_group(Some(group_id))
    .with_execute_id(Some(uuid::Uuid::new_v4().to_string()));

    let (jobid, _response, _execute_id) = submit_job_with_options(
        app.clone(),
        endpoint,
        payload,
        metadata,
        SubmitJobOptions {
            wait_for_completion: false,
        },
    )
    .await?;

    Ok(json!({ "success": true, "jobid": jobid }))
}

#[bridge]
pub async fn archive_list(
    app: AppHandle,
    source: String,
    long: Option<bool>,
    plain: Option<bool>,
    files_only: Option<bool>,
    dirs_only: Option<bool>,
) -> Result<Value, String> {
    debug!("archive_list: source={source}");

    let backend_manager = app.state::<BackendManager>();
    let backend = backend_manager.get_active().await;
    let transport = app.state::<RcloneState>().transport.clone();

    let (endpoint, payload) = if backend.is_librclone_local() {
        let mut p = json!({
            "action": "list",
            "src": source,
        });

        if let Some(l) = long {
            p["long"] = json!(l);
        }
        if let Some(pr) = plain {
            p["plain"] = json!(pr);
        }
        if let Some(fo) = files_only {
            p["files_only"] = json!(fo);
        }
        if let Some(do_val) = dirs_only {
            p["dirs_only"] = json!(do_val);
        }
        (operations::ARCHIVE, p)
    } else {
        let mut args = vec!["list".to_string(), source.clone()];
        if long.unwrap_or(false) {
            args.push("--long".to_string());
        }
        if plain.unwrap_or(false) {
            args.push("--plain".to_string());
        }
        if files_only.unwrap_or(false) {
            args.push("--files-only".to_string());
        }
        if dirs_only.unwrap_or(false) {
            args.push("--dirs-only".to_string());
        }
        let os = backend_manager.get_runtime_os(&backend.name).await;
        (
            core::COMMAND,
            backend.build_core_command_payload("archive", args, false, os),
        )
    };

    let remote_name =
        Some(crate::utils::json_helpers::extract_remote_name_from_fs(&source).into_owned());

    log_operation(
        LogLevel::Info,
        remote_name.clone(),
        Some("Archive list".to_string()),
        format!("Listing archive at {source}"),
        Some(json!({
            "arguments": crate::rclone::commands::common::redact_value(&payload, &app),
        })),
    );

    let response = transport.rpc(endpoint, Some(&payload)).await.map_err(|e| {
        let err_msg = format!("Failed to list archive: {e}");
        log_operation(
            LogLevel::Error,
            remote_name.clone(),
            Some("Archive list".to_string()),
            err_msg.clone(),
            None,
        );
        err_msg
    })?;

    let error = response
        .get("error")
        .and_then(serde_json::Value::as_bool)
        .unwrap_or(false);
    let result = response
        .get("result")
        .and_then(|v| v.as_str())
        .unwrap_or("");

    if error {
        let err_msg = format!("Archive list failed: {result}");
        log_operation(
            LogLevel::Error,
            remote_name.clone(),
            Some("Archive list".to_string()),
            err_msg.clone(),
            None,
        );
        return Err(err_msg);
    }

    log_operation(
        LogLevel::Info,
        remote_name.clone(),
        Some("Archive list".to_string()),
        format!("Successfully listed archive at {source}"),
        None,
    );

    let is_long = long.unwrap_or(false);
    let is_plain = plain.unwrap_or(false);

    let mut items = Vec::new();
    for line in result.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }

        let mut item = serde_json::Map::new();

        if is_plain {
            item.insert("path".to_string(), json!(trimmed));
            item.insert("isDir".to_string(), json!(trimmed.ends_with('/')));
        } else if is_long {
            // Format: size date time path
            // Example: 6 2025-10-30 09:46:23.000000000 file.txt
            // Note: Rclone uses varying whitespace for padding. We use a robust split.
            // Assumption: Rclone output format remains [size] [date] [time] [path].
            // This may be fragile if the time field contains spaces in some locales/OS,
            // though Rclone typically uses ISO-like formats.
            let parts = split_n_robust(trimmed, 4);
            if parts.len() >= 4 {
                let size = parts[0].parse::<i64>().unwrap_or(0);
                let date = parts[1];
                let time = parts[2].split('.').next().unwrap_or(parts[2]); // Remove nanoseconds
                let path = parts[3];
                let is_dir = path.ends_with('/');

                item.insert("size".to_string(), json!(size));
                item.insert("date".to_string(), json!(date));
                item.insert("time".to_string(), json!(time));
                item.insert(
                    "path".to_string(),
                    json!(if is_dir {
                        path.trim_end_matches('/')
                    } else {
                        path
                    }),
                );
                item.insert("isDir".to_string(), json!(is_dir));
            } else {
                item.insert("path".to_string(), json!(trimmed));
                item.insert("isDir".to_string(), json!(trimmed.ends_with('/')));
            }
        } else {
            // Default Format: size path
            // Example: 6 file.txt
            // Note: Rclone uses varying whitespace for padding. We use a robust split.
            let parts = split_n_robust(trimmed, 2);
            if parts.len() >= 2 {
                let size = parts[0].parse::<i64>().unwrap_or(0);
                let path = parts[1];
                let is_dir = path.ends_with('/');

                item.insert("size".to_string(), json!(size));
                item.insert(
                    "path".to_string(),
                    json!(if is_dir {
                        path.trim_end_matches('/')
                    } else {
                        path
                    }),
                );
                item.insert("isDir".to_string(), json!(is_dir));
            } else {
                item.insert("path".to_string(), json!(trimmed));
                item.insert("isDir".to_string(), json!(trimmed.ends_with('/')));
            }
        }

        items.push(Value::Object(item));
    }

    Ok(json!({ "success": true, "items": items }))
}

/// Robustly splits a string into N parts based on whitespace.
/// Unlike `splitn`, this handles multiple whitespace characters between parts
/// and preserves any remaining content (including spaces) in the final part.
fn split_n_robust(s: &str, n: usize) -> Vec<&str> {
    let mut parts = Vec::with_capacity(n);
    let mut current = s;
    for _ in 0..n - 1 {
        let trimmed = current.trim_start();
        if let Some(pos) = trimmed.find(|c: char| c.is_whitespace()) {
            parts.push(&trimmed[..pos]);
            current = &trimmed[pos..];
        } else {
            break;
        }
    }
    let final_part = current.trim_start();
    if !final_part.is_empty() {
        parts.push(final_part);
    }
    parts
}
