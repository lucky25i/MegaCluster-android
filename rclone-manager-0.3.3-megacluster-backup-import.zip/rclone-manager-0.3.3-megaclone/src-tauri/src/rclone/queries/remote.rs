use std::collections::HashMap;

use serde_json::Value;
use tauri::AppHandle;

use crate::{core::bridge, utils::rclone::endpoints::config};

pub async fn get_all_remote_configs(app: AppHandle) -> Result<serde_json::Value, String> {
    let json = crate::rclone::commands::common::transport(&app)
        .rpc(config::DUMP, None)
        .await
        .map_err(|e| format!("❌ Failed to fetch remote configs: {e}"))?;

    Ok(json)
}

/// Fetch all remote types
#[bridge]
pub async fn get_remote_types(app: AppHandle) -> Result<HashMap<String, Vec<Value>>, String> {
    let json = crate::rclone::commands::common::transport(&app)
        .rpc(config::PROVIDERS, None)
        .await
        .map_err(|e| format!("❌ Failed to send request: {e}"))?;

    let providers: HashMap<String, Vec<Value>> =
        serde_json::from_value(json).map_err(|e| format!("❌ Failed to parse response: {e}"))?;

    Ok(providers)
}

/// Fetch only OAuth-supported remotes
#[bridge]
pub async fn get_oauth_supported_remotes(
    app: AppHandle,
) -> Result<HashMap<String, Vec<Value>>, String> {
    let providers = get_remote_types(app).await?;

    // Extract all OAuth-supported remotes with their full information
    let mut oauth_remotes = HashMap::new();

    for (provider_type, remotes) in providers {
        let supported_remotes: Vec<Value> = remotes
            .into_iter()
            .filter(|remote| {
                remote
                    .get("Options")
                    .and_then(|options| options.as_array())
                    .is_some_and(|opts| {
                        opts.iter().any(|opt| {
                            opt.get("Name").and_then(|n| n.as_str()) == Some("token")
                                && opt.get("Help").and_then(|h| h.as_str()).is_some_and(|h| {
                                    h.contains("OAuth Access Token as a JSON blob")
                                })
                        })
                    })
            })
            .collect();

        if !supported_remotes.is_empty() {
            oauth_remotes.insert(provider_type, supported_remotes);
        }
    }

    Ok(oauth_remotes)
}
