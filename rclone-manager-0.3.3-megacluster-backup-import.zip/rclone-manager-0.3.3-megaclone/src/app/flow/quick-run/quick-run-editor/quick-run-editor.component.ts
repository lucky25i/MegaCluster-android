import {
  Component,
  ChangeDetectionStrategy,
  DestroyRef,
  computed,
  effect,
  inject,
  input,
  output,
  signal,
  untracked,
  afterNextRender,
  OnInit,
} from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormArray,
  FormControl,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDividerModule } from '@angular/material/divider';
import { MatTabsModule } from '@angular/material/tabs';
import { MatListModule } from '@angular/material/list';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSidenavModule, MatDrawerMode } from '@angular/material/sidenav';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CdkMenuModule } from '@angular/cdk/menu';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';

import {
  AppConfig,
  FlagType,
  OperationDefinition,
  PrimaryActionType,
  QuickRun,
  QuickRunConfig,
  QuickRunInput,
  RcConfigOption,
  TemplateCategory,
  PROFILE_ICONS,
  ALL_PRIMARY_ACTIONS,
  OPERATION_REGISTRY,
  WorkflowNode,
  isRclonePathKey,
} from '@app/types';
import { WorkflowStateService } from 'src/app/services/flow/workflow-state.service';
import { OperationConfigComponent } from 'src/app/shared/remote-config/app-operation-config/app-operation-config.component';
import { FlagConfigStepComponent } from 'src/app/shared/remote-config/flag-config-step/flag-config-step.component';
import { RemoteConfigStepComponent } from 'src/app/shared/remote-config/remote-config-step/remote-config-step.component';
import { AlertBannerComponent } from 'src/app/shared/components/alert-banner/alert-banner.component';
import { SearchContainerComponent } from 'src/app/shared/components/search-container/search-container.component';
import { CliImportComponent } from 'src/app/shared/remote-config/cli-import/cli-import.component';
import { ImportResult } from 'src/app/services/remote/cli-flag-mapper.service';
import { ObscureToolComponent } from 'src/app/shared/remote-config/obscure-tool/obscure-tool.component';
import {
  PresetTemplateBarComponent,
  ApplyTemplateEvent,
} from 'src/app/shared/remote-config/preset-template-bar/preset-template-bar.component';
import { FlagConfigService } from 'src/app/services/remote/flag-config.service';
import { RemoteManagementService } from 'src/app/services/remote/remote-management.service';
import { RemoteFacadeService } from 'src/app/services/facade/remote-facade.service';
import { QuickRunService } from 'src/app/services/flow/quick-run.service';
import { QuickRunEditorModalOptions } from 'src/app/services/ui/modal.service';
import { RemotePresetsService } from 'src/app/services/remote/remote-presets';
import { NotificationService } from 'src/app/services/ui/notification.service';
import { IconService } from 'src/app/services/ui/icon.service';
import { PathService, DefaultPathOp } from 'src/app/services/infrastructure/platform/path.service';
import { PathInspectionService } from 'src/app/services/infrastructure/platform/path-inspection.service';
import { RcloneValueMapperService } from 'src/app/services/remote/rclone-value-mapper.service';
import { EscapeCloseDirective } from 'src/app/shared/directives/escape-close.directive';
import {
  syncResponsiveSidebar,
  extractProfileSource,
  extractProfileDest,
} from 'src/app/shared/utils';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

const ALL_FLAG_TYPES = [
  'sync',
  'copy',
  'move',
  'bisync',
  'mount',
  'serve',
  'check',
  'delete',
  'copyurl',
  'vfs',
  'filter',
  'backend',
] as const;

/**
 * Inline editor panel for the Flow workspace's Quick Run feature.
 */
@Component({
  selector: 'app-quick-run-editor',
  hostDirectives: [EscapeCloseDirective],
  imports: [
    ReactiveFormsModule,
    MatIconModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDividerModule,
    MatTabsModule,
    MatListModule,
    MatProgressBarModule,
    MatSidenavModule,
    CdkMenuModule,
    TranslatePipe,
    OperationConfigComponent,
    FlagConfigStepComponent,
    RemoteConfigStepComponent,
    AlertBannerComponent,
    SearchContainerComponent,
    CliImportComponent,
    ObscureToolComponent,
    PresetTemplateBarComponent,
  ],
  templateUrl: './quick-run-editor.component.html',
  styleUrls: ['./quick-run-editor.component.scss', '../../../styles/_shared-modal.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class QuickRunEditorComponent implements OnInit {
  private readonly fb = inject(FormBuilder);
  private readonly quickRunService = inject(QuickRunService);
  private readonly flagConfigService = inject(FlagConfigService);
  private readonly remoteManagementService = inject(RemoteManagementService);
  private readonly remoteFacade = inject(RemoteFacadeService);
  private readonly remotePresetsService = inject(RemotePresetsService);
  private readonly notificationService = inject(NotificationService);
  private readonly pathService = inject(PathService);
  private readonly pathInspectionService = inject(PathInspectionService);
  private readonly translate = inject(TranslateService);
  private readonly valueMapper = inject(RcloneValueMapperService);
  readonly iconService = inject(IconService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly workflowStateService = inject(WorkflowStateService, { optional: true });
  private readonly dialogRef = inject(MatDialogRef<QuickRunEditorComponent>, { optional: true });
  private readonly dialogData = inject<QuickRunEditorModalOptions | null>(MAT_DIALOG_DATA, {
    optional: true,
  });

  /** When set, the editor loads this workflow node for editing. */
  readonly workflowNode = input<WorkflowNode | null>(null);
  /** When set, the editor loads this quick run for editing. */
  readonly editTarget = input<QuickRun | null>(null);
  /** Resolved target QuickRun whether passed via dialog data or input property. */
  readonly targetQuickRun = computed(() => this.dialogData?.quickRun ?? this.editTarget());
  /** Resolved target WorkflowNode whether passed via dialog data or input property. */
  readonly targetNode = computed(() => this.dialogData?.workflowNode ?? this.workflowNode());
  /** True when editing a WorkflowNode instead of a standalone QuickRun. */
  readonly isWorkflowMode = computed(() => !!this.targetNode());
  /** Emitted when the user cancels or after a successful save. */
  readonly closed = output<void>();

  // ── Form ──────────────────────────────────────────────────────────────────

  /**
   * Top-level form built with static sub-groups for all flag types, matching
   * `RemoteConfigStateService.createRemoteConfigForm()` structure.
   */
  readonly form: FormGroup = this.createForm();

  readonly runtimeRemoteFields = signal<RcConfigOption[]>([]);
  readonly isLoadingRuntimeRemoteFields = signal(false);
  readonly runtimeRemoteForm = signal<FormGroup>(
    this.fb.group({
      type: [''],
    })
  );
  readonly mountTypes = this.flagConfigService.mountTypes;
  readonly availableServeTypes = this.flagConfigService.availableServeTypes;
  readonly selectedServeType = signal('http');
  readonly dynamicServeFields = signal<RcConfigOption[]>([]);
  readonly isLoadingServeFields = signal(false);
  private readonly _serveLoadToken = { token: 0 };
  private seedRcloneConfig?: Record<string, unknown>;
  private destPathGeneration = 0;

  // ── UI state ──────────────────────────────────────────────────────────────

  readonly isSaving = computed(() =>
    this.isWorkflowMode() ? false : this.quickRunService.isSaving()
  );
  readonly showSearch = signal(false);
  readonly showCliImport = signal(false);
  readonly showObscureTool = signal(false);
  readonly activeTab = signal<FlagType | 'runtimeRemote'>('sync');
  readonly isSidebarOpen = signal(true);
  readonly sidebarMode = signal<MatDrawerMode>('side');
  readonly isLoadingFlags = signal(false);
  readonly searchQuery = signal('');
  readonly currentOpType = signal<PrimaryActionType>('sync');
  readonly currentRemoteName = signal<string>('');

  readonly activeSensitiveFields = computed(() => {
    const tab = this.activeTab();
    const fields: RcConfigOption[] =
      tab === 'runtimeRemote' ? this.runtimeRemoteFields() : this.getFlagFields(tab);

    return this.valueMapper.extractSensitiveFields(fields);
  });

  readonly remotes = computed(() => this.remoteFacade.orderedVisibleRemotes());
  readonly existingRemoteNames = computed(() => this.remotes().map(r => r.name));
  readonly selectedRemoteType = computed(() => {
    const rName = (this.currentRemoteName() || '').replace(/:+$/, '').trim();
    if (!rName) return '';
    const match = this.remotes().find(r => r.name.replace(/:+$/, '').trim() === rName);
    return match?.type ?? '';
  });
  readonly operations: readonly OperationDefinition[] = OPERATION_REGISTRY.filter(
    op => op.isPrimary
  ) as readonly OperationDefinition[];

  /** Dynamic flag fields per FlagType (operation + vfs + filter + backend). */
  readonly dynamicFlagFields = signal<Record<string, RcConfigOption[]>>({});

  readonly existingProfiles = signal<Record<string, string[]>>({});
  readonly highlightedFields = signal<Set<string>>(new Set());

  /**
   * Tab definitions. The operation tab is always shown; VFS/Filter/Backend
   * are "shared profile" tabs that any operation can optionally configure.
   */
  readonly flagTabs = computed<{ key: FlagType | 'runtimeRemote'; label: string; icon: string }[]>(
    () => {
      const op = this.currentOpType() as FlagType;
      const tabs: { key: FlagType | 'runtimeRemote'; label: string; icon: string }[] = [
        { key: op, label: this.getOperationLabel(op), icon: PROFILE_ICONS[op] ?? 'operations' },
      ];

      if (op === 'mount' || op === 'serve') {
        tabs.push({
          key: 'vfs',
          label: 'flow.quickRun.editor.tabVfs',
          icon: PROFILE_ICONS['vfs'] ?? 'vfs',
        });
      }

      tabs.push(
        {
          key: 'filter',
          label: 'flow.quickRun.editor.tabFilter',
          icon: PROFILE_ICONS['filter'] ?? 'filter',
        },
        {
          key: 'backend',
          label: 'flow.quickRun.editor.tabBackend',
          icon: PROFILE_ICONS['backend'] ?? 'database',
        },
        {
          key: 'runtimeRemote',
          label: 'flow.quickRun.editor.tabRuntimeRemote',
          icon: PROFILE_ICONS['runtimeRemote'] ?? 'gear',
        }
      );

      return tabs;
    }
  );

  constructor() {
    afterNextRender(() => {
      syncResponsiveSidebar(768, this.sidebarMode, this.isSidebarOpen, this.destroyRef);
    });

    effect(() => {
      const all = this.flagConfigService.allFlagFields();
      if (all) {
        this.dynamicFlagFields.set(all as Record<string, RcConfigOption[]>);
        untracked(() => this.syncAllDynamicControls());
      }
    });

    effect(() => {
      const type = this.selectedRemoteType();
      if (!type) {
        this.runtimeRemoteFields.set([]);
        this.runtimeRemoteForm.set(this.fb.group({ type: [''] }));
      } else {
        untracked(() => {
          void this.loadRuntimeRemoteFields(type);
        });
      }
    });

    this.form.valueChanges
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => this.formVersion.update(v => v + 1));
  }

  // ── Lifecycle ─────────────────────────────────────────────────────────────

  ngOnInit(): void {
    const targetNode = this.targetNode();
    const target = this.targetQuickRun();
    const cloneData = this.dialogData?.cloneData;
    const initOp = this.dialogData?.initialOpType;
    const initRemote = this.dialogData?.initialRemoteName;

    if (targetNode) {
      const cfg = targetNode.config || {};
      const opType = (targetNode.type as PrimaryActionType) || initOp || 'sync';
      const remote = (cfg['remoteName'] ?? cfg['remote'] ?? initRemote ?? '') as string;
      const seed =
        (cfg['config'] as QuickRunConfig | undefined) ?? (cfg as unknown as QuickRunConfig);

      this.form.patchValue({
        name: targetNode.title,
        description: targetNode.subtitle ?? '',
        operationType: opType,
        remoteName: remote,
      });
      this.currentOpType.set(opType);
      this.activeTab.set(opType as FlagType);
      this.currentRemoteName.set(remote);

      this.populateFormFromSeed(seed);
    } else if (target) {
      this.form.patchValue({
        name: target.name,
        description: target.description ?? '',
        operationType: target.operationType,
        remoteName: target.remoteName,
      });
      this.currentOpType.set(target.operationType);
      this.activeTab.set(target.operationType as FlagType);
      this.currentRemoteName.set(target.remoteName);
      this.populateFormFromSeed(target.config);
    } else if (cloneData) {
      this.form.patchValue({
        name: cloneData.name,
        description: cloneData.description ?? '',
        operationType: cloneData.operationType,
        remoteName: cloneData.remoteName,
      });
      this.currentOpType.set(cloneData.operationType);
      this.activeTab.set(cloneData.operationType as FlagType);
      this.currentRemoteName.set(cloneData.remoteName);
      this.populateFormFromSeed(cloneData.config);
    } else {
      if (initOp) {
        this.selectOperation(initOp);
      }
      if (initRemote) {
        this.form.patchValue({ remoteName: initRemote });
        this.currentRemoteName.set(initRemote);
      }
    }

    void this.loadAllFlagFields();

    const opCtrl = this.form.get('operationType');
    if (opCtrl) {
      opCtrl.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((op: unknown) => {
        const opType = op as PrimaryActionType;
        const prevOp = this.currentOpType();
        this.currentOpType.set(opType);
        if (prevOp !== opType) {
          this.rebuildOpConfigGroup(prevOp, opType);
        }
        this.syncAllDynamicControls();
        this.checkAndSetDefaultDestPath();
        if (opType === 'serve') {
          void this.loadServeFields();
        }
        if (this.activeTab() === (prevOp as FlagType)) {
          this.activeTab.set(opType as FlagType);
        }
      });
    }

    const remoteCtrl = this.form.get('remoteName');
    if (remoteCtrl) {
      remoteCtrl.valueChanges
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe((name: unknown) => {
          const rName = (name as string) ?? '';
          this.currentRemoteName.set(rName);
          this.checkAndSetDefaultDestPath();
        });
    }
  }

  // ── Form creation ─────────────────────────────────────────────────────────

  private createForm(): FormGroup {
    const configControls: Record<string, FormGroup> = {};
    for (const flag of ALL_FLAG_TYPES) {
      const isShared = flag === 'vfs' || flag === 'filter' || flag === 'backend';
      configControls[`${flag}Config`] = isShared
        ? this.createSharedConfigGroup()
        : this.createOpConfigGroup(flag as PrimaryActionType);
    }

    const mountOpts = configControls['mountConfig']?.get('options') as FormGroup | null;
    if (mountOpts && !mountOpts.contains('mountType')) {
      mountOpts.addControl('mountType', new FormControl('mount'));
    }
    const serveOpts = configControls['serveConfig']?.get('options') as FormGroup | null;
    if (serveOpts && !serveOpts.contains('type')) {
      serveOpts.addControl('type', new FormControl('http'));
    }

    return this.fb.group({
      name: ['', [Validators.required, Validators.minLength(1)]],
      description: [''],
      operationType: ['sync' as PrimaryActionType, Validators.required],
      remoteName: ['', Validators.required],
      ...configControls,
    });
  }

  getOpFormGroup(opType: string): FormGroup {
    return (this.form.get(`${opType}Config`) as FormGroup) ?? this.fb.group({});
  }

  private rebuildOpConfigGroup(prevOp: PrimaryActionType, newOp: PrimaryActionType): void {
    const prevGroup = this.form.get(`${prevOp}Config`) as FormGroup | null;
    const prevRaw = prevGroup?.getRawValue() as Record<string, unknown> | undefined;

    // Build a seed from the shared app-config fields so they carry over.
    const seed: QuickRunConfig | undefined = prevRaw
      ? {
          app: {
            autoStart: !!prevRaw['autoStart'],
            showOnTray: prevRaw['showOnTray'] !== undefined ? !!prevRaw['showOnTray'] : true,
            cronEnabled: !!prevRaw['cronEnabled'],
            cronExpression: (prevRaw['cronExpression'] as string | null) ?? null,
            watchEnabled: !!prevRaw['watchEnabled'],
            watchDelay: (prevRaw['watchDelay'] as number) ?? 5,
            watchChangedOnly: !!prevRaw['watchChangedOnly'],
          },
          rclone: {},
        }
      : undefined;

    const newGroup = this.createOpConfigGroup(newOp, seed);
    this.form.setControl(`${newOp}Config`, newGroup);
    if (newOp === 'serve') {
      const sType = (newGroup.get('options.type')?.value as string) || 'http';
      this.selectedServeType.set(sType);
      void this.loadServeFields();
    }
  }

  private createSharedConfigGroup(): FormGroup {
    return this.fb.group({
      options: this.fb.group({}),
    });
  }

  private createOpConfigGroup(opType: PrimaryActionType, seed?: QuickRunConfig): FormGroup {
    const app = seed?.app;
    const rclone = seed?.rclone as Record<string, unknown> | undefined;

    const isSingleSource =
      opType === 'mount' || opType === 'serve' || opType === 'bisync' || opType === 'archivecreate';
    const seedSourcePath = this.extractSourcePath(rclone);
    const seedDestPath = this.extractDestPath(rclone);

    const source = isSingleSource
      ? this.createPathGroup(seedSourcePath)
      : this.fb.array([this.createPathGroup(seedSourcePath)]);

    const hasDest = opType !== 'serve' && opType !== 'delete';
    const dest = hasDest ? this.createDestGroup(seedDestPath) : null;

    const optionsGroup = this.fb.group({});
    if (rclone && typeof rclone === 'object') {
      for (const [k, v] of Object.entries(rclone)) {
        if (isRclonePathKey(k)) continue;
        if (typeof v === 'object' && v !== null && !Array.isArray(v)) continue;
        optionsGroup.addControl(k, new FormControl(v));
      }
      const opSubObj = rclone[opType] as Record<string, unknown> | undefined;
      if (opSubObj && typeof opSubObj === 'object') {
        for (const [k, v] of Object.entries(opSubObj)) {
          if (isRclonePathKey(k)) continue;
          if (typeof v === 'object' && v !== null && !Array.isArray(v)) continue;
          if (!optionsGroup.contains(k)) {
            optionsGroup.addControl(k, new FormControl(v));
          }
        }
      }
    }

    if (opType === 'mount' && !optionsGroup.contains('mountType')) {
      optionsGroup.addControl('mountType', new FormControl('mount'));
    } else if (opType === 'serve' && !optionsGroup.contains('type')) {
      optionsGroup.addControl('type', new FormControl('http'));
    }

    const group: Record<string, unknown> = {
      autoStart: [app?.autoStart ?? false],
      showOnTray: [app?.showOnTray ?? true],
      cronEnabled: [app?.cronEnabled ?? false],
      cronExpression: [app?.cronExpression ?? null],
      watchEnabled: [app?.watchEnabled ?? false],
      watchDelay: [app?.watchDelay ?? 5],
      watchChangedOnly: [app?.watchChangedOnly ?? false],
      source,
      options: optionsGroup,
    };
    if (dest) group['dest'] = dest;

    return this.fb.group(group);
  }

  private async loadRuntimeRemoteFields(type: string): Promise<void> {
    this.isLoadingRuntimeRemoteFields.set(true);
    try {
      const fields = await this.remoteManagementService.getRemoteConfigFields(type);
      this.runtimeRemoteFields.set(fields);

      const group: FormGroup = this.fb.group({
        type: [type],
      });
      const runtimeSeed =
        (this.seedRcloneConfig?.['runtimeRemote'] as Record<string, unknown> | undefined) ??
        this.seedRcloneConfig;
      for (const f of fields) {
        const key = f.Name || f.FieldName;
        if (!key || key === 'type') continue;
        const seedVal = runtimeSeed?.[key];
        const val = seedVal !== undefined ? seedVal : (f.Value ?? f.Default ?? null);
        group.addControl(key, new FormControl(val, f.Required ? [Validators.required] : []));
      }
      this.runtimeRemoteForm.set(group);
    } catch (err) {
      console.warn('[QuickRunEditor] loadRuntimeRemoteFields failed:', err);
    } finally {
      this.isLoadingRuntimeRemoteFields.set(false);
    }
  }

  private populateFormFromSeed(seed?: QuickRunConfig): void {
    if (!seed || !seed.rclone) return;
    const rawRclone = seed.rclone as Record<string, unknown>;
    this.seedRcloneConfig = rawRclone;
    const opType = this.currentOpType();

    const opGroup = this.createOpConfigGroup(opType, seed);
    this.form.setControl(`${opType}Config`, opGroup);

    if (opType === 'serve') {
      const serveType =
        (opGroup.get('options.type')?.value as string) ||
        (rawRclone['type'] as string) ||
        ((rawRclone['serve'] as Record<string, unknown> | undefined)?.['type'] as string) ||
        'http';
      this.selectedServeType.set(serveType);
    }

    for (const shared of ['vfs', 'filter', 'backend'] as const) {
      const sharedObj = rawRclone[shared] as Record<string, unknown> | undefined;
      if (!sharedObj || typeof sharedObj !== 'object') continue;
      const optsGroup = this.form.get(`${shared}Config.options`) as FormGroup | null;
      if (!optsGroup) continue;

      for (const [k, v] of Object.entries(sharedObj)) {
        if (!optsGroup.contains(k)) {
          optsGroup.addControl(k, new FormControl(v));
        } else {
          optsGroup.get(k)?.setValue(v);
        }
      }
    }
  }

  private createPathGroup(initialPath?: string): FormGroup {
    let type = 'currentRemote';
    let path = initialPath ?? '';
    let remote = '';

    if (path) {
      if (path.startsWith('/') || /^[a-zA-Z]:[/\\]/.test(path)) {
        type = 'local';
      } else if (path.includes(':')) {
        const colonIdx = path.indexOf(':');
        const rName = path.slice(0, colonIdx);
        const relPath = path.slice(colonIdx + 1);
        const curRemote = (this.currentRemoteName() || '').replace(/:+$/, '');
        if (rName === curRemote) {
          type = 'currentRemote';
          path = relPath;
        } else {
          type = `otherRemote:${rName}`;
          path = relPath;
          remote = rName;
        }
      }
    }

    return this.fb.group({
      type: [type],
      path: [path],
      remote: [remote],
      filename: [''],
    });
  }

  private createDestGroup(initialPath: string | undefined): FormGroup {
    let type = 'local';
    let path = initialPath ?? '';
    let remote = '';

    if (path) {
      if (path.startsWith('/') || /^[a-zA-Z]:[/\\]/.test(path)) {
        type = 'local';
      } else if (path.includes(':')) {
        const colonIdx = path.indexOf(':');
        const rName = path.slice(0, colonIdx);
        const relPath = path.slice(colonIdx + 1);
        const curRemote = (this.currentRemoteName() || '').replace(/:+$/, '');
        if (rName === curRemote) {
          type = 'currentRemote';
          path = relPath;
        } else {
          type = `otherRemote:${rName}`;
          path = relPath;
          remote = rName;
        }
      }
    }

    return this.fb.group({
      type: [type],
      path: [path],
      remote: [remote],
    });
  }

  private extractSourcePath(rclone?: Record<string, unknown>): string {
    if (!rclone) return '';
    const opType = this.currentOpType();
    const subObj = rclone[opType] as Record<string, unknown> | undefined;
    const src =
      rclone['srcFs'] ??
      rclone['path1'] ??
      rclone['fs'] ??
      rclone['source'] ??
      subObj?.['srcFs'] ??
      subObj?.['path1'] ??
      subObj?.['fs'] ??
      subObj?.['source'];
    if (Array.isArray(src)) {
      return src[0] != null ? String(src[0]) : '';
    }
    return src != null ? String(src) : '';
  }

  private extractDestPath(rclone?: Record<string, unknown>): string {
    if (!rclone) return '';
    const opType = this.currentOpType();
    const subObj = rclone[opType] as Record<string, unknown> | undefined;
    const dst =
      rclone['mountPoint'] ??
      rclone['dstFs'] ??
      rclone['path2'] ??
      rclone['dest'] ??
      subObj?.['mountPoint'] ??
      subObj?.['dstFs'] ??
      subObj?.['path2'] ??
      subObj?.['dest'];
    if (Array.isArray(dst)) {
      return dst[0] != null ? String(dst[0]) : '';
    }
    return dst != null ? String(dst) : '';
  }

  private async loadServeFields(): Promise<void> {
    const t = this.selectedServeType() || 'http';
    const token = ++this._serveLoadToken.token;
    this.isLoadingServeFields.set(true);
    try {
      const fields = await this.flagConfigService.loadServeFlagFields(t);
      if (token !== this._serveLoadToken.token) return;
      this.dynamicServeFields.set(fields);
      this.rebuildServeOptionsGroup();
    } catch (err) {
      console.warn('[QuickRunEditor] loadServeFields failed:', err);
    } finally {
      if (token === this._serveLoadToken.token) {
        this.isLoadingServeFields.set(false);
      }
    }
  }

  async onServeTypeChange(type: string): Promise<void> {
    if (this.selectedServeType() === type) return;
    this.selectedServeType.set(type || 'http');
    const typeCtrl = this.form.get('serveConfig.options.type');
    if (typeCtrl && typeCtrl.value !== type) {
      typeCtrl.setValue(type, { emitEvent: false });
    }
    await this.loadServeFields();
  }

  rebuildServeOptionsGroup(): void {
    const g = this.form.get('serveConfig.options') as FormGroup | null;
    if (!g) return;
    this.syncDynamicControls(g, this.dynamicServeFields(), {
      preserveKeys: new Set(['type']),
    });
  }

  private async loadAllFlagFields(): Promise<void> {
    this.isLoadingFlags.set(true);
    try {
      const [all] = await Promise.all([
        this.flagConfigService.loadAllFlagFields(),
        this.loadServeFields(),
      ]);
      this.dynamicFlagFields.set(all as Record<string, RcConfigOption[]>);
      this.syncAllDynamicControls();
    } catch (err) {
      console.warn('[QuickRunEditor] loadAllFlagFields failed:', err);
    } finally {
      this.isLoadingFlags.set(false);
    }
  }

  /**
   * Sync dynamic flag controls into the `options` FormGroup of EVERY flag
   * type (operation + vfs + filter + backend). This is the equivalent of
   * `RemoteConfigStateService.addDynamicFieldsToForm()`.
   */
  private syncAllDynamicControls(): void {
    const fields = this.dynamicFlagFields();
    if (!fields) return;

    for (const type of ALL_FLAG_TYPES) {
      const configKey = `${type}Config`;
      const configGroup = this.form.get(configKey) as FormGroup | null;
      if (!configGroup) continue;
      const optionsGroup = configGroup.get('options') as FormGroup | null;
      if (!optionsGroup) continue;
      const typeFields = type === 'serve' ? this.dynamicServeFields() : (fields[type] ?? []);
      this.syncDynamicControls(optionsGroup, typeFields);
    }
  }

  /**
   * Add FormControl instances for each field that doesn't already exist on
   * the group. Existing controls are preserved.
   */
  private syncDynamicControls(
    group: FormGroup,
    fields: RcConfigOption[],
    opts?: { preserveKeys?: Set<string> }
  ): void {
    if (opts?.preserveKeys) {
      for (const k of Object.keys(group.controls)) {
        if (!opts.preserveKeys.has(k)) {
          group.removeControl(k);
        }
      }
    }
    for (const f of fields) {
      const key = f.Name || f.FieldName;
      if (!key || group.contains(key)) continue;
      group.addControl(
        key,
        new FormControl(f.Value ?? f.Default ?? null, f.Required ? [Validators.required] : [])
      );
    }
  }

  private checkAndSetDefaultDestPath(): void {
    if (this.targetQuickRun() || this.dialogData?.cloneData) return;
    const opType = this.currentOpType();
    const remoteName = this.currentRemoteName();
    if (!remoteName || (opType !== 'mount' && opType !== 'bisync')) return;

    const opKey = `${opType}Config`;
    const opGroup = this.form.get(opKey) as FormGroup | null;
    const destGroup = opGroup?.get('dest') as FormGroup | null;
    const pathCtrl = destGroup?.get('path');

    if (destGroup && pathCtrl && (!pathCtrl.value || pathCtrl.pristine)) {
      const gen = ++this.destPathGeneration;
      void this.pathInspectionService
        .resolveDefaultPath(remoteName, opType as DefaultPathOp)
        .then(defaultPath => {
          if (gen !== this.destPathGeneration) return;
          if (destGroup && pathCtrl && (!pathCtrl.value || pathCtrl.pristine)) {
            destGroup.patchValue({ type: 'local', path: defaultPath });
          }
        });
    }
  }

  // ── Actions ───────────────────────────────────────────────────────────────

  toggleSidebar(): void {
    this.isSidebarOpen.update(v => !v);
  }

  selectTab(tabKey: FlagType | 'runtimeRemote'): void {
    this.activeTab.set(tabKey);
    if (this.sidebarMode() === 'over') {
      this.isSidebarOpen.set(false);
    }
  }

  selectOperation(opKey: PrimaryActionType | string): void {
    const newOp = opKey as PrimaryActionType;
    const prevOp = this.currentOpType();
    if (prevOp === newOp) return;

    this.form.get('operationType')?.setValue(newOp);
  }

  close(): void {
    this.closed.emit();
    this.dialogRef?.close();
  }

  async submit(): Promise<void> {
    const opGroup = this.getOpFormGroup(this.currentOpType());
    if (this.form.get('name')?.invalid || this.form.get('remoteName')?.invalid || opGroup.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const input = this.buildInput();

    try {
      await this.pathInspectionService.createRequiredDirectoriesForOperation(
        input.operationType,
        input.config.rclone as Record<string, unknown>
      );
    } catch (err) {
      console.error('Failed to create required directories for Quick Run:', err);
    }

    const node = this.targetNode();
    if (this.isWorkflowMode() && node) {
      if (this.workflowStateService) {
        this.workflowStateService.updateNode(node.id, {
          title: input.name,
          subtitle: input.description,
          config: {
            remoteName: input.remoteName,
            config: input.config,
          },
        });
      }
      this.notificationService.showSuccess(
        this.translate.instant('flow.workflow.editor.nodeSaved')
      );
      this.closed.emit();
      this.dialogRef?.close(true);
      return;
    }

    const saved = await this.quickRunService.save(input);
    if (!saved) return;
    this.closed.emit();
    this.dialogRef?.close(true);
  }

  toggleSearch(): void {
    this.showSearch.update(v => !v);
    if (!this.showSearch()) {
      this.searchQuery.set('');
    } else {
      this.showCliImport.set(false);
      this.showObscureTool.set(false);
    }
    if (this.sidebarMode() === 'over') {
      this.isSidebarOpen.set(false);
    }
  }

  toggleCliImport(): void {
    this.showCliImport.update(v => !v);
    if (this.showCliImport()) {
      this.showSearch.set(false);
      this.showObscureTool.set(false);
      if (this.sidebarMode() === 'over') this.isSidebarOpen.set(false);
    }
  }

  toggleObscureTool(): void {
    this.showObscureTool.update(v => !v);
    if (this.showObscureTool()) {
      this.showSearch.set(false);
      this.showCliImport.set(false);
      if (this.sidebarMode() === 'over') this.isSidebarOpen.set(false);
    }
  }

  applyObscuredValue(key: string, value: string): void {
    const tab = this.activeTab();
    if (tab === 'runtimeRemote') {
      const ctrl = this.runtimeRemoteForm().get(key);
      if (ctrl) {
        ctrl.setValue(value);
        ctrl.markAsDirty();
        ctrl.markAsTouched();
      }
    } else {
      const groupKey = `${tab}Config`;
      const configGroup = this.form.get(groupKey) as FormGroup | null;
      const optsGroup = configGroup?.get('options') as FormGroup | null;
      const ctrl = optsGroup?.get(key);
      if (ctrl) {
        ctrl.setValue(value);
        ctrl.markAsDirty();
        ctrl.markAsTouched();
      }
    }
  }

  applyDefaultPresets(): void {
    const remoteType = this.selectedRemoteType();
    if (!remoteType) {
      const warningMsg = this.translate.instant('wizards.presets.noRemoteSelected');
      this.notificationService.showWarning(
        warningMsg !== 'wizards.presets.noRemoteSelected'
          ? warningMsg
          : 'Please select a remote first'
      );
      return;
    }

    const preset = this.remotePresetsService.resolvePresets(remoteType);

    this.patchGroupOptions('vfsConfig', preset.vfs);
    this.patchGroupOptions('backendConfig', preset.backend);

    const currentOp = this.currentOpType();
    if (currentOp === 'mount' && preset.mount) {
      this.patchGroupOptions('mountConfig', preset.mount);
    }

    if (preset.remote) {
      const rtGroup = this.runtimeRemoteForm();
      for (const [k, v] of Object.entries(preset.remote)) {
        if (rtGroup.contains(k)) {
          rtGroup.get(k)?.setValue(v);
        }
      }
    }

    const msg = this.translate.instant('wizards.presets.applied');
    this.notificationService.showSuccess(
      msg !== 'wizards.presets.applied' ? msg : 'Default presets applied successfully'
    );
  }

  private parseAndSetPath(targetGroup: FormGroup, rawPath: string, currentRemote: string): void {
    const existingRemotes = this.existingRemoteNames() || [];
    const defaultType = currentRemote ? 'currentRemote' : 'local';
    const parsed = this.pathService.parseFsString(
      rawPath.trim(),
      defaultType,
      currentRemote,
      existingRemotes
    );

    targetGroup.patchValue({
      type: parsed.type,
      path: parsed.path,
      ...(targetGroup.contains('remote') ? { remote: parsed.remote } : {}),
    });
    targetGroup.markAsDirty();
  }

  onCliImportApply(event: {
    result: ImportResult;
    importSourcePath: boolean;
    importDestPath: boolean;
  }): void {
    const { result, importSourcePath, importDestPath } = event;

    if (result.verb && result.verb !== this.currentOpType()) {
      if (ALL_PRIMARY_ACTIONS.includes(result.verb as PrimaryActionType)) {
        this.selectOperation(result.verb as PrimaryActionType);
      }
    }

    const currentOp = this.currentOpType();
    const opGroup = this.getOpFormGroup(currentOp);
    const remoteName = this.currentRemoteName();

    if (importSourcePath && result.sourcePath && opGroup) {
      const sourceCtrl = opGroup.get('source');
      if (sourceCtrl instanceof FormArray && sourceCtrl.length > 0) {
        this.parseAndSetPath(sourceCtrl.at(0) as FormGroup, result.sourcePath, remoteName);
      } else if (sourceCtrl instanceof FormGroup) {
        this.parseAndSetPath(sourceCtrl, result.sourcePath, remoteName);
      }
    }

    if (importDestPath && result.destPath && opGroup) {
      const destCtrl = opGroup.get('dest') as FormGroup | null;
      if (destCtrl) {
        this.parseAndSetPath(destCtrl, result.destPath, remoteName);
      }
    }

    const newHighlighted = new Set<string>();
    let appliedCount = 0;

    for (const cls of result.classified) {
      if (cls.status !== 'mapped' || !cls.fieldName) continue;

      const flagType = cls.flagType || currentOp;
      const targetGroup =
        flagType === 'runtimeRemote'
          ? this.runtimeRemoteForm()
          : (this.form.get(`${flagType}Config.options`) as FormGroup | null);

      if (targetGroup) {
        const key = cls.fieldName;
        if (!targetGroup.contains(key)) {
          targetGroup.addControl(key, new FormControl(cls.coercedValue));
        } else {
          targetGroup.get(key)?.setValue(cls.coercedValue);
        }
        targetGroup.get(key)?.markAsDirty();
        newHighlighted.add(key);
        appliedCount++;
      }
    }

    if (result.mountSubtype && currentOp === 'mount') {
      const mountOpts = this.form.get('mountConfig.options') as FormGroup | null;
      mountOpts?.get('mountType')?.setValue(result.mountSubtype);
    }
    if (result.serveSubtype && currentOp === 'serve') {
      void this.onServeTypeChange(result.serveSubtype);
    }

    this.highlightedFields.set(newHighlighted);
    this.showCliImport.set(false);

    const msg = this.translate.instant('wizards.cliImport.appliedToast', { count: appliedCount });
    this.notificationService.showSuccess(
      msg !== 'wizards.cliImport.appliedToast'
        ? msg
        : `Successfully imported ${appliedCount} option(s)`
    );
  }

  /**
   * Build a {@link QuickRunInput} from the current form state.
   */
  private buildInput(): QuickRunInput {
    const opType = this.currentOpType();
    const remoteName = this.currentRemoteName();
    const name = (this.form.get('name')?.value as string).trim();
    const description = (this.form.get('description')?.value as string)?.trim() || undefined;
    const inner = this.getOpFormGroup(opType);

    const rawValue = inner.getRawValue() as Record<string, unknown>;

    const app: AppConfig = {
      autoStart: !!rawValue['autoStart'],
      showOnTray: rawValue['showOnTray'] !== undefined ? !!rawValue['showOnTray'] : true,
      cronEnabled: !!rawValue['cronEnabled'],
      cronExpression: (rawValue['cronExpression'] as string | null) ?? null,
      watchEnabled: !!rawValue['watchEnabled'],
      watchDelay: (rawValue['watchDelay'] as number) ?? 5,
      watchChangedOnly: !!rawValue['watchChangedOnly'],
    };

    const opConfig: Record<string, unknown> = {};

    const sourceValue = rawValue['source'];
    if (sourceValue) {
      if (Array.isArray(sourceValue)) {
        const paths = (sourceValue as Record<string, unknown>[]).map(item =>
          opType === 'copyurl'
            ? String(item['path'] ?? '').trim()
            : this.resolvePath(item, remoteName)
        );
        if (opType === 'bisync') opConfig['path1'] = paths[0] ?? '';
        else if (opType === 'copyurl')
          opConfig['url'] = paths.length === 1 ? (paths[0] ?? '') : paths;
        else opConfig['srcFs'] = paths.length === 1 ? (paths[0] ?? '') : paths;
      } else if (typeof sourceValue === 'object') {
        const path =
          opType === 'copyurl'
            ? String((sourceValue as Record<string, unknown>)['path'] ?? '').trim()
            : this.resolvePath(sourceValue as Record<string, unknown>, remoteName);
        if (opType === 'mount') opConfig['srcFs'] = path;
        else if (opType === 'serve') opConfig['fs'] = path;
        else if (opType === 'bisync') opConfig['path1'] = path;
        else if (opType === 'copyurl') opConfig['url'] = path;
        else opConfig['srcFs'] = path;
      }
    }

    const destValue = rawValue['dest'] as Record<string, unknown> | undefined;
    if (destValue) {
      const destPath = this.resolvePath(destValue, remoteName);
      if (opType === 'mount') opConfig['mountPoint'] = destPath;
      else if (opType === 'bisync') opConfig['path2'] = destPath;
      else opConfig['dstFs'] = destPath;
    }

    const fields = this.dynamicFlagFields();

    const opOptsGroup = inner.get('options') as FormGroup | null;
    if (opOptsGroup) {
      const opFields =
        opType === 'serve' ? this.dynamicServeFields() : (fields[opType as FlagType] ?? []);
      const cleanedOp = this.valueMapper.cleanData(
        opOptsGroup.getRawValue() as Record<string, unknown>,
        opFields
      );
      Object.assign(opConfig, cleanedOp);

      if (opType === 'mount') {
        const mt = opOptsGroup.get('mountType')?.value;
        if (mt && mt !== 'mount') {
          opConfig['mountType'] = mt;
        }
      } else if (opType === 'serve') {
        const st = opOptsGroup.get('type')?.value;
        if (st) {
          opConfig['type'] = st;
        }
      }
    }

    const rclone: Record<string, unknown> = {
      ...opConfig,
    };

    const sharedTypes =
      opType === 'mount' || opType === 'serve'
        ? (['vfs', 'filter', 'backend'] as const)
        : (['filter', 'backend'] as const);

    for (const flagType of sharedTypes) {
      const groupKey = `${flagType}Config`;
      const configGroup = this.form.get(groupKey) as FormGroup | null;
      if (!configGroup) continue;

      const optsGroup = configGroup.get('options') as FormGroup | null;
      if (!optsGroup) continue;

      const optsValue = optsGroup.getRawValue() as Record<string, unknown>;
      const typeFields = fields[flagType as FlagType] ?? [];
      const cleaned = this.valueMapper.cleanData(optsValue, typeFields);
      if (Object.keys(cleaned).length > 0) {
        rclone[flagType] = cleaned;
      }
    }

    const runtimeRaw = this.runtimeRemoteForm().getRawValue() as Record<string, unknown>;
    delete runtimeRaw['type'];
    const cleanedRuntime = this.valueMapper.cleanData(runtimeRaw, this.runtimeRemoteFields());
    if (Object.keys(cleanedRuntime).length > 0) {
      rclone['runtimeRemote'] = cleanedRuntime;
    }

    return {
      id: this.targetQuickRun()?.id,
      name,
      description,
      operationType: opType,
      remoteName,
      config: { app, rclone },
    };
  }

  private resolvePath(item: Record<string, unknown>, currentRemote: string): string {
    const type = String(item['type'] ?? 'currentRemote');
    const rawPath = String(item['path'] ?? '').trim();
    const cleanCurrent = (currentRemote || '').replace(/:+$/, '');

    if (type === 'currentRemote') {
      if (!cleanCurrent) return rawPath;
      if (rawPath.startsWith(`${cleanCurrent}:`)) return rawPath;
      return rawPath ? `${cleanCurrent}:${rawPath}` : `${cleanCurrent}:`;
    }

    if (type.startsWith('otherRemote:')) {
      const otherRemote = type.slice('otherRemote:'.length).replace(/:+$/, '');
      if (!otherRemote) return rawPath;
      if (rawPath.startsWith(`${otherRemote}:`)) return rawPath;
      return rawPath ? `${otherRemote}:${rawPath}` : `${otherRemote}:`;
    }

    if (type === 'local' || rawPath.startsWith('/') || /^[a-zA-Z]:[/\\]/.test(rawPath)) {
      return rawPath;
    }

    return rawPath;
  }

  // ── Template helpers ─────────────────────────────────────────────────────

  getOperationLabel(opKey: string): string {
    const def = this.operations.find(o => o.key === opKey);
    return def?.typeLabel ?? def?.actionLabel ?? opKey;
  }

  getFlagFields(type: FlagType | string): RcConfigOption[] {
    if (type === 'serve') {
      return this.dynamicServeFields();
    }
    return this.dynamicFlagFields()[type] ?? [];
  }

  private readonly formVersion = signal(0);

  readonly currentValues = computed(() => {
    this.formVersion();
    const raw = this.form.getRawValue();
    const fields = this.dynamicFlagFields();
    const opType = this.currentOpType();

    const getCleanOptions = (flagType: string): Record<string, unknown> => {
      const opts =
        (raw[`${flagType}Config`] as { options?: Record<string, unknown> } | undefined)?.options ??
        {};
      const typeFields =
        flagType === 'serve' ? this.dynamicServeFields() : (fields[flagType as FlagType] ?? []);
      return this.valueMapper.cleanData(opts, typeFields);
    };

    const isVfsApplicable = opType === 'mount' || opType === 'serve';

    const res: Partial<Record<TemplateCategory, Record<string, unknown>>> = {
      vfs: isVfsApplicable ? getCleanOptions('vfs') : {},
      mount: getCleanOptions('mount'),
      serve: getCleanOptions('serve'),
      backend: getCleanOptions('backend'),
      filter: getCleanOptions('filter'),
      sync: getCleanOptions('sync'),
      copy: getCleanOptions('copy'),
    };

    if (opType) {
      const cleanedOp = getCleanOptions(opType);
      (res as Record<string, unknown>)[opType] = cleanedOp;
    }

    return res;
  });

  private patchGroupOptions(
    configKey: string,
    opts?: Record<string, unknown>,
    ignoredKeys?: readonly string[]
  ): void {
    if (!opts) return;
    const groupKey = configKey.endsWith('Config') ? configKey : `${configKey}Config`;
    const configGroup = this.form.get(groupKey) as FormGroup | null;
    if (!configGroup) return;

    const optsGroup = configGroup.get('options') as FormGroup | null;
    if (optsGroup) {
      for (const [k, v] of Object.entries(opts)) {
        if (ignoredKeys ? ignoredKeys.includes(k) : isRclonePathKey(k)) continue;
        if (!optsGroup.contains(k)) {
          optsGroup.addControl(k, new FormControl(v));
        } else {
          optsGroup.get(k)?.setValue(v);
        }
      }
    }
  }

  onApplyTemplate(event: ApplyTemplateEvent): void {
    const { values } = event;

    if (values.vfs) this.patchGroupOptions('vfsConfig', values.vfs);
    if (values.mount) this.patchGroupOptions('mountConfig', values.mount);
    if (values.backend) this.patchGroupOptions('backendConfig', values.backend);
    if (values.filter) this.patchGroupOptions('filterConfig', values.filter);
    if (values.sync) this.patchGroupOptions('syncConfig', values.sync);
    if (values.copy) this.patchGroupOptions('copyConfig', values.copy);
    const serveValues = (values as Record<string, Record<string, unknown> | undefined>)['serve'];
    if (serveValues) {
      this.patchGroupOptions('serveConfig', serveValues);
      const sType = serveValues['type'] as string | undefined;
      if (sType) void this.onServeTypeChange(sType);
    }

    const currentOp = this.currentOpType();
    if (currentOp) {
      const opGroup = this.getOpFormGroup(currentOp);
      const opOpts = (values as Record<string, Record<string, unknown> | undefined>)[currentOp];
      if (opOpts && typeof opOpts === 'object') {
        this.patchGroupOptions(`${currentOp}Config`, opOpts);

        const srcPath = extractProfileSource(opOpts) as string | undefined;
        if (srcPath && typeof srcPath === 'string') {
          const sourceCtrl = opGroup.get('source');
          if (sourceCtrl instanceof FormArray && sourceCtrl.length > 0) {
            (sourceCtrl.at(0) as FormGroup).get('path')?.setValue(srcPath);
          } else if (sourceCtrl instanceof FormGroup) {
            sourceCtrl.get('path')?.setValue(srcPath);
          }
        }
        const dstPath = extractProfileDest(opOpts) as string | undefined;
        if (dstPath && typeof dstPath === 'string') {
          const destCtrl = opGroup.get('dest') as FormGroup | null;
          destCtrl?.get('path')?.setValue(dstPath);
        }
      }
    }

    const msg = this.translate.instant('templates.applySuccess', { name: event.sourceName });
    this.notificationService.showSuccess(msg);
  }
}
