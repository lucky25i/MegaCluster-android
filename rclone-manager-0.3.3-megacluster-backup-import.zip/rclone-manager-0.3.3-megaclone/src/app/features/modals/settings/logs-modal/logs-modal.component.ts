import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnInit,
  computed,
  effect,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatButtonModule } from '@angular/material/button';
import { DatePipe, UpperCasePipe } from '@angular/common';
import { LogContext, RemoteLogEntry, LOG_LEVELS, LogLevel } from '@app/types';
import { LoggingService } from 'src/app/services/infrastructure/platform/logging.service';
import { BackendTranslationService } from 'src/app/services/i18n/backend-translation.service';
import { AnsiToHtmlPipe } from '@app/pipes';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { CopyToClipboardDirective } from '../../../../shared/directives/copy-to-clipboard.directive';
import { EscapeCloseDirective } from '../../../../shared/directives/escape-close.directive';

@Component({
  selector: 'app-logs-modal',
  standalone: true,
  hostDirectives: [EscapeCloseDirective],
  imports: [
    MatIconModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    FormsModule,
    MatSnackBarModule,
    MatButtonModule,
    AnsiToHtmlPipe,
    DatePipe,
    UpperCasePipe,
    TranslatePipe,
    CopyToClipboardDirective,
  ],
  templateUrl: './logs-modal.component.html',
  styleUrls: ['./logs-modal.component.scss', '../../../../styles/_shared-modal.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LogsModalComponent implements OnInit {
  // --- Dependencies ---
  private readonly dialogRef = inject(MatDialogRef<LogsModalComponent>);
  public readonly data = inject(MAT_DIALOG_DATA) as { remoteName: string };
  private readonly snackBar = inject(MatSnackBar);
  private readonly loggingService = inject(LoggingService);
  private readonly backendTranslation = inject(BackendTranslationService);
  private readonly translate = inject(TranslateService);

  public readonly logLevels = LOG_LEVELS;

  // --- State Signals ---
  readonly logs = signal<RemoteLogEntry[]>([]);
  readonly loading = signal(false);
  readonly selectedLevel = signal<LogLevel | ''>('');
  readonly searchText = signal<string>('');
  readonly expandedLogs = signal<Set<string>>(new Set());

  // --- Computed Logic ---
  private readonly searchableLogs = computed(() => {
    const logs = this.logs();
    return logs.map(log => ({
      log,
      haystack: `${log.message.toLowerCase()} ${
        log.context ? JSON.stringify(log.context).toLowerCase() : ''
      }`,
    }));
  });

  readonly filteredLogs = computed(() => {
    const level = this.selectedLevel();
    const search = this.searchText().toLowerCase();
    const items = this.searchableLogs();

    return items
      .filter(({ log, haystack }) => {
        const matchesLevel = level ? log.level === level : true;
        const matchesSearch = search ? haystack.includes(search) : true;
        return matchesLevel && matchesSearch;
      })
      .map(({ log }) => log);
  });

  readonly logVm = computed(() => {
    const map = new Map<
      string,
      {
        copyText: string;
        contextStr: string | null;
        output: string | null;
        translatedMessage: string;
      }
    >();
    for (const log of this.logs()) {
      const id = this.getLogId(log);
      map.set(id, {
        copyText: this.getFormattedLog(log),
        contextStr: log.context ? this.formatContext(log.context) : null,
        output: this.getCommandOutput(log),
        translatedMessage: this.translateLogMessage(log.message),
      });
    }
    return map;
  });

  readonly terminalLogArea = viewChild<ElementRef<HTMLDivElement>>('terminalLogArea');

  constructor() {
    effect(() => {
      if (this.logs().length > 0) {
        requestAnimationFrame(() => this.scrollToBottom());
      }
    });
  }

  ngOnInit(): void {
    this.loadLogs();
  }

  async loadLogs(): Promise<void> {
    this.loading.set(true);
    try {
      const fetchedLogs = (await this.loggingService.getRemoteLogs(
        this.data.remoteName
      )) as unknown as RemoteLogEntry[];
      this.logs.set(fetchedLogs);
    } catch {
      const message = this.translate.instant('modals.logs.fetchError');
      this.snackBar.open(message, undefined, { duration: 3000 });
    } finally {
      this.loading.set(false);
    }
  }

  async clearLogs(): Promise<void> {
    this.loading.set(true);
    try {
      await this.loggingService.clearRemoteLogs(this.data.remoteName);
      this.logs.set([]);
    } catch {
      const message = this.translate.instant('modals.logs.clearError');
      this.snackBar.open(message, undefined, { duration: 3000 });
    } finally {
      this.loading.set(false);
    }
  }

  // --- Log Parsing Helpers ---
  getLogId(log: RemoteLogEntry): string {
    return `${log.timestamp}-${log.message.substring(0, 15)}`;
  }

  isExpanded(log: RemoteLogEntry): boolean {
    return this.expandedLogs().has(this.getLogId(log));
  }

  toggleDetails(log: RemoteLogEntry): void {
    if (!log.context) return;
    const id = this.getLogId(log);
    this.expandedLogs.update(current => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  /**
   * Smart extractor for Rclone's nested error outputs.
   * Handles the specific bisync error structure: status -> output -> output
   */
  getCommandOutput(log: RemoteLogEntry): string | null {
    if (!log.context) return null;

    const ctx = log.context as Record<string, unknown>;
    const status = ctx['status'] as Record<string, unknown> | undefined;
    const statusOutput = status?.['output'] as Record<string, unknown> | undefined;

    if (typeof statusOutput?.['output'] === 'string') return statusOutput['output'];
    if (typeof ctx['output'] === 'string') return ctx['output'];
    if (ctx['output'] && typeof ctx['output'] === 'object')
      return JSON.stringify(ctx['output'], null, 2);

    return null;
  }

  formatContext(context: LogContext): string {
    try {
      const displayContext = { ...context } as Record<string, unknown>;
      if (typeof displayContext['response'] === 'string') {
        try {
          displayContext['response'] = JSON.parse(displayContext['response']);
        } catch {
          /* not valid JSON, keep as-is */
        }
      }
      return JSON.stringify(displayContext, null, 2);
    } catch (e) {
      console.error('Error formatting log context:', e);
      return JSON.stringify(context, null, 2);
    }
  }

  translateLogMessage(message: string): string {
    return this.backendTranslation.translateBackendMessage(message);
  }

  getFormattedLog(log: RemoteLogEntry): string {
    const output = this.getCommandOutput(log);
    const translatedMessage = this.translateLogMessage(log.message);
    let text = `[${log.timestamp}] [${log.level.toUpperCase()}] ${translatedMessage}`;

    if (output) {
      // eslint-disable-next-line no-control-regex
      const cleanOutput = output.replace(/\u001b\[\d+;?\d*m/g, '');
      text += `\n\nOutput:\n${cleanOutput}`;
    }

    if (log.context) {
      text += `\n\nDetails:\n${this.formatContext(log.context)}`;
    }

    return text;
  }

  scrollToBottom(): void {
    this.terminalLogArea()?.nativeElement.scrollTo({
      top: Number.MAX_SAFE_INTEGER,
      behavior: 'smooth',
    });
  }

  scrollToTop(): void {
    this.terminalLogArea()?.nativeElement.scrollTo({ top: 0, behavior: 'smooth' });
  }

  close(): void {
    this.dialogRef.close();
  }
}
