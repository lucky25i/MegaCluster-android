import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';

import { AlertService } from 'src/app/services/alerts/alert.service';
import { NotificationService } from 'src/app/services/ui/notification.service';
import { AlertAction } from '@app/types';
import { SearchContainerComponent } from 'src/app/shared/components/search-container/search-container.component';
import { MatDialog } from '@angular/material/dialog';
import { AlertActionEditorComponent } from './alert-action-editor/alert-action-editor.component';

@Component({
  selector: 'app-alert-actions',
  imports: [
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatSlideToggleModule,
    TranslatePipe,
    SearchContainerComponent,
  ],
  template: `
    <div class="actions-container">
      <!-- Toolbar -->
      <div class="toolbar">
        <button
          matIconButton
          (click)="searchVisible.set(!searchVisible())"
          [attr.title]="'shared.search.toggle' | translate"
        >
          <mat-icon svgIcon="search"></mat-icon>
        </button>

        <button matButton="filled" (click)="createAction()">
          <mat-icon svgIcon="plus"></mat-icon>
          {{ 'alerts.createAction' | translate }}
        </button>
      </div>

      <app-search-container
        [visible]="searchVisible()"
        [searchText]="alerts.actionsSearchTerm()"
        (searchTextChange)="onSearchChange($event)"
      ></app-search-container>

      <div class="table-wrap" [class.loading]="alerts.isLoading()">
        <!-- Loading -->
        @if (alerts.isLoading() && alerts.actions().length === 0) {
          <div class="empty-state">
            <mat-icon svgIcon="spinner" class="colorful-spinner"></mat-icon>
          </div>
        }

        <!-- Empty -->
        @if (!alerts.isLoading() && alerts.actions().length === 0) {
          <div class="empty-state">
            <mat-icon svgIcon="bolt"></mat-icon>
            <span>{{ 'alerts.noActions' | translate }}</span>
            <p>{{ 'alerts.noActionsHint' | translate }}</p>
          </div>
        }

        <!-- Table -->
        @if (alerts.actions().length > 0) {
          <table mat-table [dataSource]="alerts.actions()">
            <!-- Kind -->
            <ng-container matColumnDef="kind">
              <th mat-header-cell *matHeaderCellDef>
                {{ 'alerts.action.kind' | translate }}
              </th>
              <td mat-cell *matCellDef="let action">
                <span class="app-pill p-dim">
                  <mat-icon [svgIcon]="alerts.getActionIcon(action.kind)"></mat-icon>
                  {{ 'alerts.action.' + action.kind | translate }}
                </span>
              </td>
            </ng-container>

            <!-- Name -->
            <ng-container matColumnDef="name">
              <th mat-header-cell *matHeaderCellDef>
                {{ 'common.name' | translate }}
              </th>
              <td mat-cell *matCellDef="let action">
                <!-- ⚠ No | translate here — action.name is a user string, not an i18n key -->
                <span class="action-name">{{ action.name }}</span>
              </td>
            </ng-container>

            <!-- Status -->
            <ng-container matColumnDef="status">
              <th mat-header-cell *matHeaderCellDef>
                {{ 'common.status' | translate }}
              </th>
              <td mat-cell *matCellDef="let action">
                <mat-slide-toggle
                  [checked]="action.enabled"
                  (change)="toggleAction(action)"
                  [attr.title]="
                    (action.enabled ? 'automation.status.enabled' : 'automation.status.disabled')
                      | translate
                  "
                ></mat-slide-toggle>
              </td>
            </ng-container>

            <!-- Row actions -->
            <ng-container matColumnDef="actions">
              <th mat-header-cell *matHeaderCellDef></th>
              <td mat-cell *matCellDef="let action">
                <div class="row-actions">
                  <!-- Test -->
                  <button
                    matIconButton
                    (click)="testAction(action)"
                    [attr.title]="'alerts.testAction' | translate"
                    [disabled]="alerts.testingActionIds().has(action.id)"
                  >
                    @if (alerts.testingActionIds().has(action.id)) {
                      <mat-icon svgIcon="spinner" class="colorful-spinner"></mat-icon>
                    } @else {
                      <mat-icon svgIcon="play"></mat-icon>
                    }
                  </button>

                  <!-- Edit -->
                  <button
                    matIconButton
                    (click)="editAction(action)"
                    [attr.title]="'common.edit' | translate"
                  >
                    <mat-icon svgIcon="pen"></mat-icon>
                  </button>

                  <!-- Delete -->
                  <button
                    matIconButton
                    (click)="deleteAction(action)"
                    [attr.title]="'common.delete' | translate"
                  >
                    <mat-icon svgIcon="trash"></mat-icon>
                  </button>
                </div>
              </td>
            </ng-container>

            <tr mat-header-row *matHeaderRowDef="displayedColumns; sticky: true"></tr>
            <tr
              mat-row
              *matRowDef="let row; columns: displayedColumns"
              [class.row-disabled]="!row.enabled"
            ></tr>
          </table>
        }
      </div>
    </div>
  `,
  styles: `
    :host {
      display: block;
      height: 100%;
    }

    .actions-container {
      display: flex;
      flex-direction: column;
      height: 100%;
    }

    .toolbar {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      gap: var(--space-xs);
      padding: var(--space-md);
      flex-shrink: 0;
    }

    .table-wrap {
      flex: 1;
      overflow: auto;
      position: relative;
      border-top: 1px solid var(--border-color);
      transition: opacity 0.2s ease;

      &.loading {
        opacity: 0.5;
        pointer-events: none;
      }

      table {
        width: 100%;
        min-width: 640px;
      }
    }

    .mat-mdc-header-row {
      height: 44px;
    }

    /* ── Sticky Header ───────────────────────────────── */
    .mat-mdc-header-cell {
      background: var(--window-bg-color) !important;
      position: sticky;
      top: 0;
      z-index: 2;
      border-bottom: 2px solid var(--border-color) !important;
      border-right: 1px solid var(--border-color);
      font-weight: 700;
      font-size: var(--font-size-xs);
      letter-spacing: 0.05em;
      color: var(--dim-color);
      white-space: nowrap;
      padding: 0 var(--space-sm) !important;
    }

    .mat-mdc-cell {
      padding: var(--space-sm) !important;
      border-bottom: 1px solid var(--border-color) !important;
      border-right: 1px solid var(--border-color);
      vertical-align: middle;
    }

    .mat-mdc-row {
      transition: background 0.1s ease;

      &:hover {
        background: var(--hover-bg-color);
      }
      &.row-disabled {
        opacity: 0.5;
      }
    }

    .mat-column-kind {
      width: 160px;
    }
    .mat-column-name {
      min-width: 180px;
    }
    .mat-column-status {
      width: 90px;
    }
    .mat-column-actions {
      width: 136px;
    }

    .action-name {
      font-weight: 600;
      font-size: var(--font-size-md);
      color: var(--window-fg-color);
    }

    .row-actions {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      gap: var(--space-xxs);
    }
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AlertActionsComponent {
  public readonly alerts = inject(AlertService);
  private readonly dialog = inject(MatDialog);
  private readonly notificationService = inject(NotificationService);
  private readonly translate = inject(TranslateService);

  readonly searchVisible = signal(false);
  readonly displayedColumns = ['kind', 'name', 'status', 'actions'];

  onSearchChange(term: string): void {
    this.alerts.actionsSearchTerm.set(term);
  }

  createAction(): void {
    this.dialog
      .open(AlertActionEditorComponent, {
        width: '600px',
        maxHeight: '80vh',
        disableClose: false,
        data: { actionId: undefined },
        panelClass: 'mobile-sheet-dialog',
      })
      .afterClosed()
      .subscribe(async action => {
        if (action) await this.alerts.saveAlertAction(action);
      });
  }

  editAction(action: AlertAction): void {
    this.dialog
      .open(AlertActionEditorComponent, {
        width: '600px',
        maxHeight: '80vh',
        disableClose: false,
        data: { actionId: action.id },
        panelClass: 'mobile-sheet-dialog',
      })
      .afterClosed()
      .subscribe(async updated => {
        if (updated) await this.alerts.saveAlertAction(updated);
      });
  }

  async deleteAction(action: AlertAction): Promise<void> {
    const confirmed = await this.notificationService.confirmModal(
      'common.delete',
      'alerts.deleteActionConfirm',
      'common.delete',
      'common.cancel'
    );
    if (confirmed) {
      await this.alerts.deleteAlertAction(action.id);
    }
  }

  async toggleAction(action: AlertAction): Promise<void> {
    await this.alerts.saveAlertAction({ ...action, enabled: !action.enabled });
  }

  async testAction(action: AlertAction): Promise<void> {
    try {
      const success = await this.alerts.testAlertAction(action.id);
      if (success) {
        this.notificationService.showSuccess(this.translate.instant('alerts.testActionSuccess'));
      } else {
        this.notificationService.showError(
          this.translate.instant('alerts.testActionFailed', {
            error: this.translate.instant('common.error'),
          })
        );
      }
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      this.notificationService.showError(
        this.translate.instant('alerts.testActionError', { error: errorMsg })
      );
      console.error('Test failed', err);
    }
  }
}
