import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  ElementRef,
  inject,
  signal,
  afterNextRender,
} from '@angular/core';
import { ReactiveFormsModule, FormGroup } from '@angular/forms';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatSidenavModule, MatDrawerMode } from '@angular/material/sidenav';
import { RemoteConfigStepComponent } from '../../../../shared/remote-config/remote-config-step/remote-config-step.component';
import { FlagConfigStepComponent } from '../../../../shared/remote-config/flag-config-step/flag-config-step.component';
import { OperationConfigComponent } from '../../../../shared/remote-config/app-operation-config/app-operation-config.component';
import { ObscureToolComponent } from '../../../../shared/remote-config/obscure-tool/obscure-tool.component';
import { CliImportComponent } from '../../../../shared/remote-config/cli-import/cli-import.component';
import { AlertBannerComponent } from '../../../../shared/components/alert-banner/alert-banner.component';
import { SearchContainerComponent } from '../../../../shared/components/search-container/search-container.component';
import { InteractiveConfigStepComponent } from 'src/app/shared/remote-config/interactive-config-step/interactive-config-step.component';
import { AuthStateService } from '../../../../services/security/auth-state.service';
import { NotificationService } from '../../../../services/ui/notification.service';
import { RemoteManagementService } from '../../../../services/remote/remote-management.service';
import {
  RemoteConfigStateService,
  DialogData,
} from '../../../../services/remote/remote-config-state.service';
import { RemoteCreationOrchestrator } from '../../../../services/remote/remote-creation-orchestrator.service';
import { RcloneValueMapperService } from '../../../../services/remote/rclone-value-mapper.service';
import { retargetProfilesRemote } from '../../../../services/remote/utils/remote-config.utils';
import {
  RemoteConfigSections,
  REMOTE_CONFIG_KEYS,
  LINKED_PROFILE_TYPES,
  PROFILE_ICONS,
  EditTarget,
  TemplateCategory,
  FlagType,
} from '@app/types';
import { CopyToClipboardDirective } from '../../../../shared/directives/copy-to-clipboard.directive';
import { ProfileSwitcherComponent } from './profile-switcher/profile-switcher.component';
import { ConfigModalSidebarComponent } from './config-modal-sidebar/config-modal-sidebar.component';
import { ConfigModalFooterComponent } from './config-modal-footer/config-modal-footer.component';
import { EscapeCloseDirective } from '../../../../shared/directives/escape-close.directive';
import { ApplyTemplateEvent } from '../../../../shared/remote-config/preset-template-bar/preset-template-bar.component';
import { syncResponsiveSidebar } from 'src/app/shared/utils';

@Component({
  selector: 'app-remote-config-modal',
  hostDirectives: [EscapeCloseDirective],
  imports: [
    ReactiveFormsModule,
    TranslatePipe,
    MatIconModule,
    MatButtonModule,
    MatSelectModule,
    MatFormFieldModule,
    MatExpansionModule,
    MatSidenavModule,
    RemoteConfigStepComponent,
    FlagConfigStepComponent,
    OperationConfigComponent,
    ObscureToolComponent,
    CliImportComponent,
    AlertBannerComponent,
    InteractiveConfigStepComponent,
    SearchContainerComponent,
    CopyToClipboardDirective,
    ProfileSwitcherComponent,
    ConfigModalSidebarComponent,
    ConfigModalFooterComponent,
  ],

  providers: [RemoteCreationOrchestrator, RemoteConfigStateService],
  templateUrl: './remote-config-modal.component.html',
  styleUrls: ['../../../../styles/_shared-modal.scss', './remote-config-modal.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RemoteConfigModalComponent {
  readonly state = inject(RemoteConfigStateService);

  private readonly dialogRef = inject(MatDialogRef<RemoteConfigModalComponent>);
  private readonly hostEl = inject(ElementRef<HTMLElement>);
  private readonly authStateService = inject(AuthStateService);
  private readonly remoteManagementService = inject(RemoteManagementService);
  private readonly dialogData = (inject(MAT_DIALOG_DATA, { optional: true }) ?? undefined) as
    DialogData | undefined;
  private readonly notificationService = inject(NotificationService);
  private readonly translate = inject(TranslateService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly orchestrator = inject(RemoteCreationOrchestrator);
  private readonly valueMapper = inject(RcloneValueMapperService);

  readonly LINKED_PROFILE_TYPES = LINKED_PROFILE_TYPES;

  readonly PROFILE_ICONS = PROFILE_ICONS;

  readonly isSidebarOpen = signal(true);
  readonly sidebarMode = signal<MatDrawerMode>('side');

  readonly remoteEditCategories = [
    { id: 'section-general', label: 'modals.remoteConfig.editMode.sections.general', icon: 'gear' },
    { id: 'section-auth', label: 'modals.remoteConfig.editMode.sections.auth', icon: 'lock' },
    {
      id: 'section-advanced',
      label: 'modals.remoteConfig.editMode.sections.advanced',
      icon: 'wrench',
    },
  ] as const;

  readonly visibleSections = this.state.remoteEditVisibleSections;

  constructor() {
    this.destroyRef.onDestroy(() => this.authStateService.cancelAuth());
    afterNextRender(() =>
      syncResponsiveSidebar(768, this.sidebarMode, this.isSidebarOpen, this.destroyRef)
    );
    this.initializeState();
  }

  private async initializeState(): Promise<void> {
    try {
      await this.state.init(this.dialogData);
      this.state.isInitializing.set(false);
    } catch (error) {
      console.error('Failed to initialize remote config state:', error);
      const errorMsg = this.translate.instant('modals.remoteConfig.errors.loadFailed');
      this.notificationService.showError(
        errorMsg !== 'modals.remoteConfig.errors.loadFailed'
          ? errorMsg
          : 'Failed to load remote configuration settings'
      );
      this.close();
    }
  }

  goToStep(step: number): void {
    if (!this.state.isStepClickable(step)) return;
    this.saveCurrentStepProfile();
    this.state.currentStep.set(step);
    this.scrollToTop();
    if (step === 1 && !this.state.editTarget()) {
      this.state.showObscureTool.set(false);
      this.state.showCliImport.set(false);
    }
  }

  nextStep(): void {
    const steps = this.state.applicableSteps();
    const idx = steps.indexOf(this.state.currentStep());
    if (idx !== -1 && idx < steps.length - 1) this.goToStep(steps[idx + 1]);
  }

  prevStep(): void {
    const steps = this.state.applicableSteps();
    const idx = steps.indexOf(this.state.currentStep());
    if (idx > 0) this.goToStep(steps[idx - 1]);
  }

  private scrollToTop(): void {
    this.hostEl.nativeElement.querySelector('.modal-content')?.scrollTo(0, 0);
  }

  handleInteractiveAnswerUpdate(newAnswer: string | number | boolean | null): void {
    this.orchestrator.updateInteractiveAnswer(newAnswer);
  }

  async onSubmit(): Promise<void> {
    if (this.state.isAuthInProgress()) return;
    try {
      const result = this.state.isEditingExisting()
        ? await this.handleEditMode()
        : await this.handleCreateMode();
      if (result.success && !this.state.isAuthCancelled()) this.close();
    } catch (error) {
      console.error('Submission error:', error);
      this.orchestrator.resetInteractiveFlow();

      let errorMessage = this.translate.instant(
        'modals.remoteConfig.errors.interactiveProcessingFailed'
      );
      if (error instanceof Error) {
        errorMessage = error.message;
      } else if (typeof error === 'string') {
        errorMessage = error;
      }
      this.notificationService.showError(errorMessage);
    } finally {
      if (!this.state.interactiveFlowState().isActive) {
        this.authStateService.resetAuthState();
      }
    }
  }

  private readonly requiresInteractiveFlow = computed(() =>
    this.state.commandOptions().some(o => o.key === 'nonInteractive' && o.value === true)
  );

  private async handleCreateMode(): Promise<{ success: boolean }> {
    const remoteData = this.state.cleanFormData(this.state.remoteForm.getRawValue());
    const finalConfig = this.buildFinalConfig();
    await this.authStateService.startAuth(remoteData.name, false);

    if (!this.requiresInteractiveFlow()) {
      await this.remoteManagementService.createRemote(
        remoteData.name,
        remoteData,
        this.remoteManagementService.buildOpt(this.state.commandOptions())
      );
      this.orchestrator.setPendingConfig(remoteData, finalConfig);
      await this.orchestrator.finalizeCreation();
      return { success: true };
    }

    this.orchestrator.setPendingConfig(remoteData, finalConfig);
    const completed = await this.orchestrator.startInteractiveCreation(
      remoteData,
      finalConfig,
      this.state.commandOptions()
    );
    return { success: completed };
  }

  private async handleEditMode(): Promise<{ success: boolean }> {
    const remoteName = this.state.currentRemoteName();
    await this.authStateService.startAuth(remoteName, true);

    if (this.state.editTarget() === 'remote' || this.state.editTarget() === null) {
      const remoteData = this.state.cleanFormData(this.state.remoteForm.getRawValue());
      if (this.requiresInteractiveFlow()) {
        const finalConfig = this.buildFinalConfig();
        this.orchestrator.setPendingConfig(remoteData, finalConfig);
        const completed = await this.orchestrator.startInteractiveCreation(
          remoteData,
          finalConfig,
          this.state.commandOptions()
        );
        return { success: completed };
      }
      await this.remoteManagementService.updateRemote(remoteData.name, remoteData);
      let profileSuccess = true;
      if (this.state.editTarget() === null) {
        profileSuccess = await this.state.saveRemoteProfiles(remoteName);
      }
      return { success: profileSuccess };
    }

    const target = this.state.editTarget();
    if (!target || target === 'remote') {
      return { success: false };
    }
    const success = await this.state.saveRemoteProfiles(remoteName, target);
    return { success };
  }

  private buildFinalConfig(): RemoteConfigSections {
    this.saveCurrentStepProfile();
    let p = this.state.profiles();

    if (this.state.cloneTarget()) {
      const cloneFrom = this.dialogData?.cloneFrom;
      const targetName = this.state.remoteForm.get('name')?.value || this.state.currentRemoteName();
      if (cloneFrom && targetName && cloneFrom !== targetName) {
        p = retargetProfilesRemote(p, cloneFrom, targetName);
      }
    }

    const sections = Object.fromEntries(
      Object.entries(REMOTE_CONFIG_KEYS).map(([type, key]) => [
        key,
        p[type as keyof typeof p] ?? {},
      ])
    ) as unknown as RemoteConfigSections;
    return { ...sections, showOnTray: true };
  }

  saveCurrentStepProfile(): void {
    const editTargetValue = this.state.editTarget();
    const stepIdx = this.state.currentStep() - 1;
    const type =
      editTargetValue && editTargetValue !== 'remote'
        ? editTargetValue
        : stepIdx >= 0
          ? this.state.stepConfigs()[stepIdx]?.type
          : undefined;
    if (type && type !== 'remote') this.state.saveCurrentProfile(type);
  }

  onInteractiveContinue(answer: string | number | boolean | null): void {
    if (this.state.interactiveFlowState().isProcessing) return;
    this.state.interactiveFlowState.update(s => ({
      ...s,
      isProcessing: true,
      answer: answer != null ? String(answer) : '',
    }));
    void this.orchestrator.submitInteractiveAnswer(answer, this.state.commandOptions()).then(() => {
      this.closeIfFlowComplete();
    });
  }

  private closeIfFlowComplete(): void {
    if (!this.state.interactiveFlowState().isActive) this.close();
  }

  async cancelAuth(): Promise<void> {
    await this.orchestrator.cancelAuth();
  }

  toggleSearchVisibility(): void {
    this.state.isSearchVisible.update(visible => !visible);
    if (!this.state.isSearchVisible()) this.state.searchQuery.set('');
  }

  onSearchInput(query: string): void {
    this.state.searchQuery.set(query);
  }

  scrollToSection(sectionId: string): void {
    this.hostEl.nativeElement
      .querySelector('#' + CSS.escape(sectionId))
      ?.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
  }

  toggleSidebar(): void {
    this.isSidebarOpen.update(v => !v);
  }

  private closeSidebarIfOver(): void {
    if (this.sidebarMode() === 'over') {
      this.isSidebarOpen.set(false);
    }
  }

  onStepSelected(step: number): void {
    this.goToStep(step);
    this.closeSidebarIfOver();
  }

  onSectionScrolled(sectionId: string): void {
    this.scrollToSection(sectionId);
    this.closeSidebarIfOver();
  }

  onProfileSelected(event: { type: EditTarget; name: string }): void {
    this.state.selectProfile(event.type, event.name);
    this.closeSidebarIfOver();
  }

  onSharedNavigated(type: EditTarget): void {
    this.state.navigateToShared(type);
    this.closeSidebarIfOver();
  }

  onReturnFromShared(): void {
    this.state.returnFromShared();
    this.closeSidebarIfOver();
  }

  onSearchToggled(): void {
    this.toggleSearchVisibility();
    this.closeSidebarIfOver();
  }

  onCliImportToggled(): void {
    this.state.toggleCliImportVisibility();
    if (this.state.showCliImport()) this.closeSidebarIfOver();
  }

  onObscureToolToggled(): void {
    this.state.toggleObscureToolVisibility();
    if (this.state.showObscureTool()) this.closeSidebarIfOver();
  }

  onApplyPresets(): void {
    const remoteType = this.state.remoteTypeSignal();
    if (!remoteType) return;
    this.state.applyPresets(remoteType);
    const msg = this.translate.instant('wizards.presets.applied');
    this.notificationService.showSuccess(
      msg !== 'wizards.presets.applied' ? msg : 'Default presets applied successfully'
    );
  }

  readonly currentValues = computed(() => {
    const rcf = this.state.remoteConfigForm;
    const getCleanOptions = (configKey: string, flagType: FlagType): Record<string, unknown> => {
      const opts = (rcf.get(`${configKey}.options`) as FormGroup | null)?.getRawValue() ?? {};
      const fields = this.state.getDynamicFlagFields(flagType);
      return this.valueMapper.cleanData(opts, fields);
    };

    const remoteRaw = this.state.remoteForm.getRawValue();
    const remoteClean = (this.state.cleanFormData(remoteRaw) as Record<string, unknown>) ?? {};
    const cleanRemoteData: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(remoteClean)) {
      if (k !== 'name' && k !== 'type') cleanRemoteData[k] = v;
    }

    const result: Partial<Record<TemplateCategory, Record<string, unknown>>> = {
      vfs: getCleanOptions('vfsConfig', 'vfs'),
      mount: getCleanOptions('mountConfig', 'mount'),
      backend: getCleanOptions('backendConfig', 'backend'),
      filter: getCleanOptions('filterConfig', 'filter'),
      remote: cleanRemoteData,
    };

    const activeFlag = this.state.activeFlagType();
    if (activeFlag && !result[activeFlag]) {
      result[activeFlag] = getCleanOptions(`${activeFlag}Config`, activeFlag);
    }

    return result;
  });

  onApplyTemplate(event: ApplyTemplateEvent): void {
    this.state.applyTemplate(event.values);
    const msg = this.translate.instant('templates.applySuccess', { name: event.sourceName });
    this.notificationService.showSuccess(msg);
  }

  close(): void {
    this.dialogRef.close();
  }
}
