// Nautilus file manager – handles tabs, split-view, rich file operations.
import {
  Component,
  computed,
  DestroyRef,
  effect,
  ElementRef,
  inject,
  OnInit,
  output,
  signal,
  untracked,
  viewChild,
  ChangeDetectionStrategy,
} from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { toSignal, takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { fromEvent } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

import { MatIconModule } from '@angular/material/icon';
import { MatSidenav, MatSidenavModule } from '@angular/material/sidenav';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { CdkMenuModule } from '@angular/cdk/menu';

import { NautilusService } from 'src/app/services/ui/nautilus.service';
import { UiStateService } from 'src/app/services/ui/state/ui-state.service';
import { NotificationService } from 'src/app/services/ui/notification.service';
import { PathService } from 'src/app/services/infrastructure/platform/path.service';
import { PathNavigationService } from 'src/app/services/infrastructure/platform/path-navigation.service';
import { isHeadlessMode } from 'src/app/services/infrastructure/platform/api-client.service';
import {
  Entry,
  ExplorerRoot,
  FileBrowserItem,
  FilePickerConfig,
  DEFAULT_PICKER_OPTIONS,
} from '@app/types';
import { FormatFileSizePipe } from '@app/pipes';
import { NautilusKeyboardDirective } from '../../shared/directives/nautilus-keyboard.directive';

import { NautilusFileOperationsService } from 'src/app/services/ui/nautilus-file-operations.service';
import { NautilusDragDropService } from 'src/app/services/ui/nautilus-drag-drop.service';
import { NautilusSettingsService } from 'src/app/services/ui/nautilus-settings.service';
import { NautilusTabService, PaneViewModel } from 'src/app/services/ui/nautilus-tab.service';
import { NautilusActionsService } from 'src/app/services/ui/nautilus-actions.service';
import { NautilusSelectionService } from 'src/app/services/ui/nautilus-selection.service';
import { FileViewerService } from 'src/app/services/ui/file-viewer.service';

import { NautilusSidebarComponent } from './sidebar/nautilus-sidebar.component';
import { NautilusToolbarComponent } from './toolbar/nautilus-toolbar.component';
import { NautilusTabsComponent } from './tabs/nautilus-tabs.component';
import { NautilusViewPaneComponent } from './view-pane/nautilus-view-pane.component';
import { NautilusBottomBarComponent } from './bottom-bar/nautilus-bottom-bar.component';
import { AndroidShareService } from 'src/app/services/ui/android-share.service';
import { NautilusContextMenuComponent } from './context-menu/nautilus-context-menu.component';

@Component({
  selector: 'app-nautilus',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    NautilusSidebarComponent,
    NautilusToolbarComponent,
    NautilusTabsComponent,
    NautilusViewPaneComponent,
    NautilusBottomBarComponent,
    TranslatePipe,
    MatIconModule,
    MatSidenavModule,
    MatButtonModule,
    MatDividerModule,
    CdkMenuModule,
    NautilusContextMenuComponent,
  ],
  providers: [
    FormatFileSizePipe,
    NautilusFileOperationsService,
    NautilusDragDropService,
    NautilusSettingsService,
    NautilusTabService,
    NautilusActionsService,
    NautilusSelectionService,
  ],
  hostDirectives: [NautilusKeyboardDirective],
  templateUrl: './nautilus.component.html',
  styleUrl: './nautilus.component.scss',
})
export class NautilusComponent implements OnInit {
  // ── Services ─────────────────────────────────────────────────────────────────
  private readonly destroyRef = inject(DestroyRef);
  private readonly translate = inject(TranslateService);
  private readonly notificationService = inject(NotificationService);
  private readonly pathService = inject(PathService);
  private readonly pathNav = inject(PathNavigationService);
  private readonly formatFileSizePipe = inject(FormatFileSizePipe);
  private readonly keyboard = inject(NautilusKeyboardDirective);

  protected readonly nautilusService = inject(NautilusService);
  private readonly uiStateService = inject(UiStateService);
  protected readonly fileOps = inject(NautilusFileOperationsService);
  protected readonly dragDrop = inject(NautilusDragDropService);
  protected readonly settings = inject(NautilusSettingsService);
  protected readonly tabSvc = inject(NautilusTabService);
  protected readonly actions = inject(NautilusActionsService);
  protected readonly selectionSvc = inject(NautilusSelectionService);
  protected readonly fileViewerSvc = inject(FileViewerService);
  protected readonly androidShare = inject(AndroidShareService);

  /** Paths shared into the app from another Android app (empty on desktop). */
  protected readonly pendingSharedPaths = this.androidShare.pendingSharedPaths;

  // ── Outputs & ViewChild ──────────────────────────────────────────────────────
  readonly closeOverlay = output<FileBrowserItem[] | null>();
  readonly sidenav = viewChild(MatSidenav);
  readonly fileUploadInput = viewChild<ElementRef<HTMLInputElement>>('fileUploadInput');
  readonly folderUploadInput = viewChild<ElementRef<HTMLInputElement>>('folderUploadInput');
  readonly contextMenu = viewChild(NautilusContextMenuComponent);

  // ── Responsive layout ────────────────────────────────────────────────────────
  private readonly _windowWidth = toSignal(
    fromEvent(window, 'resize').pipe(
      map(() => window.innerWidth),
      startWith(window.innerWidth)
    ),
    { initialValue: window.innerWidth }
  );

  protected readonly isMobile = computed(() => this._windowWidth() < 680);
  protected readonly isSidenavOpen = signal(!this.isMobile());
  protected readonly sidenavMode = computed(() => (this.isMobile() ? 'over' : 'side'));

  // ── Picker state ─────────────────────────────────────────────────────────────
  private readonly filePickerState = this.nautilusService.filePickerState;

  protected readonly isPickerMode = computed(() => this.filePickerState().isOpen);
  protected readonly isPrimaryRoutedView = computed(() => {
    if (this.isPickerMode() || this.nautilusService.isBrowserOverlayOpen()) {
      return false;
    }
    return (
      this.nautilusService.isStandaloneWindow() ||
      this.uiStateService.selectedMainView() === 'nautilus'
    );
  });
  protected readonly pickerOptions = computed(
    (): FilePickerConfig => this.filePickerState().options ?? DEFAULT_PICKER_OPTIONS
  );
  protected readonly isConfirmDisabled = computed(() => {
    if (!this.isPickerMode()) return false;
    const opts = this.pickerOptions();
    const count = this.tabSvc.activeSelection().size;
    if (count === 0) {
      return opts.selection === 'files';
    }
    return count < (opts.minSelection ?? 0);
  });
  protected readonly title = computed(() => {
    const state = this.filePickerState();
    if (!state.isOpen) return 'nautilus.titles.files';
    const sel = state.options?.selection;
    if (sel === 'folders') return 'nautilus.titles.selectFolder';
    if (sel === 'files') return 'nautilus.titles.selectFile';
    return 'nautilus.titles.selectItems';
  });

  // ── UI state ─────────────────────────────────────────────────────────────────
  protected readonly isEditingPath = signal(false);
  protected readonly isSearchMode = signal(false);
  protected readonly isCurrentPathRegistered = signal(false);
  protected readonly searchFilter = signal('');
  private readonly initialLocationApplied = signal(false);
  private readonly _initialUrlSyncDone = signal(false);
  private readonly _langChange = toSignal(this.translate.onLangChange.pipe(startWith(null)));

  // ── Computed path / breadcrumbs ──────────────────────────────────────────────
  protected readonly pathSegments = computed(() =>
    this.pathService.getPathSegments(this.tabSvc.activePath())
  );

  protected readonly fullPathInput = computed(() => {
    if (this.tabSvc.activeStarredMode()) return '';
    return this.pathService.getFullDisplayPath(
      this.tabSvc.activeRemote(),
      this.tabSvc.activePath()
    );
  });

  protected readonly bottomBarOffset = computed(() =>
    this.isMobile() || this.isPickerMode() ? '64px' : '4px'
  );

  // ── Sidebar data (filtered for picker mode) ──────────────────────────────────
  protected readonly filteredBookmarks = computed(() => {
    const marks = this.nautilusService.bookmarks();
    if (!this.isPickerMode()) return marks;
    const cfg = this.pickerOptions();
    return marks.filter(b => {
      if (cfg.mode === 'local' && !b.meta.isLocal) return false;
      if (cfg.mode === 'remote' && b.meta.isLocal) return false;
      if (cfg.allowedRemotes?.length && !b.meta.isLocal) {
        return cfg.allowedRemotes.includes(
          this.pathService.normalizeRemoteName(b.meta.remote ?? '')
        );
      }
      return true;
    });
  });

  protected readonly localDrives = computed<ExplorerRoot[]>(() => {
    const drives = this.nautilusService.localDrives();
    if (this.isPickerMode() && this.pickerOptions().mode === 'remote') return [];
    return drives;
  });

  protected readonly cloudRemotes = computed<ExplorerRoot[]>(() => {
    let list = this.nautilusService.cloudRemotes();
    if (this.isPickerMode() && this.pickerOptions().mode === 'local') return [];
    const allowed = this.pickerOptions().allowedRemotes;
    if (this.isPickerMode() && allowed?.length) {
      list = list.filter(r => allowed.includes(r.name));
    }
    return list;
  });

  protected readonly allRemotesLookup = computed(() => [
    ...this.localDrives(),
    ...this.cloudRemotes(),
  ]);

  // ── Sort options ─────────────────────────────────────────────────────────────
  protected readonly sortOptions = [
    { key: 'name-asc', label: 'nautilus.sort.az' },
    { key: 'name-desc', label: 'nautilus.sort.za' },
    { key: 'modified-desc', label: 'nautilus.sort.lastModified' },
    { key: 'modified-asc', label: 'nautilus.sort.firstModified' },
    { key: 'size-desc', label: 'nautilus.sort.sizeLargest' },
    { key: 'size-asc', label: 'nautilus.sort.sizeSmallest' },
  ];

  // ── File lists (filtered + sorted) ──────────────────────────────────────────
  protected readonly files = computed(() => this._getPaneFiles(0));
  protected readonly filesRight = computed(() => this._getPaneFiles(1));

  protected readonly visiblePanes = computed((): PaneViewModel[] => {
    const left: PaneViewModel = {
      index: 0,
      files: this.files(),
      selection: this.tabSvc.selectedItems(),
      loading: this.tabSvc.isLoading(),
      error: this.tabSvc.errorState(),
      starredMode: this.tabSvc.starredMode(),
    };
    if (!this.tabSvc.isSplitEnabled()) return [left];
    return [
      left,
      {
        index: 1,
        files: this.filesRight(),
        selection: this.tabSvc.selectedItemsRight(),
        loading: this.tabSvc.isLoadingRight(),
        error: this.tabSvc.errorStateRight(),
        starredMode: this.tabSvc.starredModeRight(),
      },
    ];
  });

  protected readonly selectionSummary = computed(() => {
    this._langChange(); // recompute on language change

    const selectedPaths = this.tabSvc.activeSelection();
    const count = selectedPaths.size;
    if (count === 0) return '';

    const allFiles = this.tabSvc.activePaneIndex() === 0 ? this.files() : this.filesRight();
    const selected = allFiles.filter(item => selectedPaths.has(this.getItemKey(item)));

    if (count === 1) {
      const item = selected[0];
      if (!item) return '';
      const name = `"${item.entry.Name}"`;
      const sel = this.translate.instant('nautilus.selection.selected');
      if (item.entry.IsDir) return `${name} ${sel}`;
      return `${name} ${sel} (${this.formatFileSizePipe.transform(item.entry.Size)})`;
    }

    const parts: string[] = [];
    const folderItems = selected.filter(i => i.entry.IsDir);
    const fileItems = selected.filter(i => !i.entry.IsDir);
    const sel = this.translate.instant('nautilus.selection.selected');

    if (folderItems.length) {
      const label = this.translate.instant(
        folderItems.length > 1 ? 'nautilus.selection.folders' : 'nautilus.selection.folder'
      );
      parts.push(`${folderItems.length} ${label} ${sel}`);
    }
    if (fileItems.length) {
      const totalSize = fileItems.reduce((sum, i) => sum + i.entry.Size, 0);
      const formattedSize = this.formatFileSizePipe.transform(totalSize);
      const label = this.translate.instant(
        fileItems.length > 1 ? 'nautilus.selection.items' : 'nautilus.selection.item'
      );
      parts.push(`${fileItems.length} ${label} ${sel} (${formattedSize})`);
    }

    return parts.join(', ');
  });

  // ---------------------------------------------------------------------------
  // Lifecycle
  // ---------------------------------------------------------------------------

  constructor() {
    this._setupEffects();
    this._registerKeyboard();
    this._registerDragDrop();

    this.uiStateService.registerMobileSidebar({
      view: 'nautilus',
      isOver: this.isMobile,
      isOpen: this.isSidenavOpen,
    });

    this.tabSvc.onCloseOverlay = (): void => this.closeOverlay.emit(null);

    this.destroyRef.onDestroy(() => {
      this.nautilusService.setWindowTitle('RClone Manager');
      this.uiStateService.unregisterMobileSidebar('nautilus');
    });
  }

  async ngOnInit(): Promise<void> {
    const applied = await this.tabSvc.setupInitialTab(this.localDrives(), this.cloudRemotes());
    this.initialLocationApplied.set(applied);
    void this.dragDrop.setupDesktopNativeDropListener();
  }

  // ---------------------------------------------------------------------------
  // Effects
  // ---------------------------------------------------------------------------

  private _setupEffects(): void {
    // Sync sidenav open state with screen size.
    effect(() => {
      this.isSidenavOpen.set(!this.isMobile());
    });

    // Check SendTo registration status
    effect(() => {
      const remote = this.tabSvc.activeRemote();
      const path = this.tabSvc.activePath();

      if (remote && !remote.isLocal) {
        this.nautilusService
          .isSendToRegistered(remote.name, path)
          .then(registered => {
            this.isCurrentPathRegistered.set(registered);
          })
          .catch(err => {
            console.error('Failed to check SendTo registration:', err);
          });
      } else {
        this.isCurrentPathRegistered.set(false);
      }
    });

    // Fallback: apply initialLocation if remote data wasn't ready during setupInitialTab.
    effect(() => {
      const open = this.isPickerMode();
      const applied = this.initialLocationApplied();
      const cfg = this.pickerOptions();

      if (open && !applied && cfg.initialLocation) {
        if (!this.tabSvc.isDataReadyForConfig(cfg, this.localDrives(), this.cloudRemotes())) return;
        if (this.tabSvc.isLocationAllowedByConfig(cfg.initialLocation, cfg)) {
          this.navigateToPath(cfg.initialLocation);
          this.initialLocationApplied.set(true);
        }
      }

      if (!open && applied) this.initialLocationApplied.set(false);
    });

    // Handle remote selection triggered externally (e.g. from system tray).
    effect(() => {
      const selectedMap = this.nautilusService.selectedNautilusRemote();
      if (selectedMap) {
        untracked(() => {
          const remote = this.allRemotesLookup().find(r => r.name === selectedMap);
          if (remote && this.tabSvc.tabs().length > 0) {
            this.selectRemote(remote);
            this.nautilusService.selectedNautilusRemote.set(null);
          }
        });
      }
    });

    // Handle path navigation triggered externally (e.g. from debug menu).
    effect(() => {
      const targetPath = this.nautilusService.targetPath();
      if (targetPath) {
        untracked(() => {
          const parsed = this.pathService.parseLocation(targetPath, this.allRemotesLookup());
          if (parsed && this.tabSvc.tabs().length > 0) {
            this.navigate(parsed.remote, parsed.path, true);
            this.nautilusService.targetPath.set(null);
          }
        });
      }
    });
    // Sync browser URL with active remote + path when Nautilus is the primary routed view.
    // In picker mode or overlay mode we do not mutate the browser URL.
    effect(() => {
      if (!this.isPrimaryRoutedView()) {
        return;
      }

      const remote = this.tabSvc.activeRemote();
      const path = this.tabSvc.activePath();

      untracked(() => {
        const displayPath = path;

        const remoteName = remote?.name ?? null;
        const desiredPath = this.pathNav.buildRelativeNautilusPath(
          remoteName,
          displayPath,
          this.pathService.pathStyleForRemote(remote)
        );
        const currentPath = this.pathNav.currentPath();

        if (currentPath === desiredPath) {
          this._initialUrlSyncDone.set(true);
          return;
        }

        if (!this._initialUrlSyncDone()) {
          this.pathNav.replaceCurrent(
            remoteName,
            displayPath,
            this.pathService.pathStyleForRemote(remote)
          );
          this._initialUrlSyncDone.set(true);
        } else {
          this.pathNav.navigateTo(
            remoteName,
            displayPath,
            this.pathService.pathStyleForRemote(remote)
          );
        }
      });
    });

    this.pathNav.locationChanges$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(loc => {
      if (!this.isPrimaryRoutedView()) {
        return;
      }

      const remote = loc.remote;
      if (!remote) {
        return;
      }

      const activeRemote = this.tabSvc.activeRemote();
      const activePath = this.tabSvc.activePath();
      const targetPath = loc.path ?? '';

      if (activeRemote && activeRemote.name === remote && activePath === targetPath) {
        return;
      }

      const remoteRoot = this.nautilusService.lookupRemoteByName(remote);

      void this.tabSvc.navigate(remoteRoot, targetPath, false);
    });

    effect(() => {
      const isPicker = this.isPickerMode();
      const remote = this.tabSvc.activeRemote();
      const path = this.tabSvc.activePath();
      const starred = this.tabSvc.activeStarredMode();
      this._langChange();

      const appSuffix = 'RClone Browser';
      let segment: string;

      if (isPicker) {
        segment = this.translate.instant(this.title());
      } else if (starred) {
        segment = this.translate.instant('nautilus.titles.starred');
      } else if (remote) {
        const seg = this.pathService.getDisplaySegment(remote, path, remote.label || remote.name);
        segment = this.translate.instant(seg);
      } else {
        segment = this.translate.instant('nautilus.titles.files');
      }

      const activeFile = this.fileViewerSvc.activeFileName();
      if (activeFile) {
        segment = segment ? `${activeFile} - ${segment}` : activeFile;
      }

      this.nautilusService.setWindowTitle(segment ? `${segment} - ${appSuffix}` : appSuffix);
    });
  }

  // ---------------------------------------------------------------------------
  // Registration helpers (called from constructor)
  // ---------------------------------------------------------------------------

  private _registerKeyboard(): void {
    this.keyboard.register({
      navigateTo: item => this.navigateTo(item),
      getSelectedItems: () => this.selectionSvc.getSelectedItemsList(this.getActivePaneFiles()),
      setContextItem: item => this.setContextItem(item),
      openInNewTab: () => this.actions.openContextMenuOpenInNewTab(),
      openInNewWindow: () => this.actions.openContextMenuOpenInNewWindow(),
      openRename: () => this.actions.openRename(),
      openNewFolder: () => this.actions.openNewFolder(),
      openProperties: () => this.actions.openPropertiesDialog('contextMenu'),
      deleteSelected: () => this.actions.deleteSelectedItems(),
      selectAll: () => this.selectAll(),
      clearSelection: () => this.selectionSvc.clearSelection(),
      clearClipboard: () => this.fileOps.clearClipboard(),
      pasteItems: () => this.pasteItems(),
      refresh: () => this.tabSvc.refresh(this.tabSvc.activePaneIndex()),
      toggleSplit: () => this.tabSvc.toggleSplit(),
      toggleSearch: () => this.toggleSearchMode(),
      toggleShowHidden: v => this.settings.toggleShowHidden(v),
      isEditingPath: this.isEditingPath,
      pathSegments: this.pathSegments,
      showHidden: this.settings.showHidden,
      isPickerMode: this.isPickerMode,
      isSearchMode: this.isSearchMode,
      navigateToSegment: index => this.navigateToSegment(index),
    });
  }

  private _registerDragDrop(): void {
    this.dragDrop.register({
      getContext: () => ({
        activeRemote: this.tabSvc.activeRemote(),
        activePath: this.tabSvc.activePath(),
        panes: [
          { remote: this.tabSvc.getPaneRef(0).remote(), path: this.tabSvc.getPaneRef(0).path() },
          { remote: this.tabSvc.getPaneRef(1).remote(), path: this.tabSvc.getPaneRef(1).path() },
        ],
        files: this.files(),
        filesRight: this.filesRight(),
        activePaneIndex: this.tabSvc.activePaneIndex(),
        pathSegments: this.pathSegments(),
        tabs: this.tabSvc.tabs().map(t => ({
          id: t.id,
          left: { remote: t.left.remote, path: t.left.path },
        })),
        allRemotesLookup: this.allRemotesLookup(),
        bookmarks: this.nautilusService.bookmarks(),
      }),
      navigateTo: item => this.navigateTo(item),
      navigateToSegment: index => this.navigateToSegment(index),
      updatePath: path => this.updatePath(path),
      switchTab: index => this.tabSvc.switchTab(index),
      switchPane: index => this.tabSvc.switchPane(index),
      selectStarred: () => this.selectStarred(),
      selectRemote: remote => this.selectRemote(remote),
      openBookmark: bm => this.openBookmark(bm),
      toggleStar: item => this.nautilusService.toggleItem('starred', item),
      isStarred: item => this.isStarred(item),
      toggleBookmark: item => this.nautilusService.toggleItem('bookmarks', item),
      refresh: (remote, path) => {
        if (remote) {
          this.tabSvc.refreshPath(remote, path ?? this.tabSvc.activePath());
        } else {
          this.tabSvc.refresh(this.tabSvc.activePaneIndex());
        }
      },
    });
  }

  // ---------------------------------------------------------------------------
  // Navigation
  // ---------------------------------------------------------------------------

  selectRemote(remote: ExplorerRoot | null): void {
    if (!remote) return;
    this.navigate(remote, '', true);
  }

  updatePath(newPath: string): void {
    this.navigate(this.tabSvc.activeRemote(), newPath, true);
  }

  navigateToSegment(index: number): void {
    if (index < 0) {
      this.updatePath('');
      return;
    }
    const seg = this.pathSegments()[index];
    if (seg) this.updatePath(seg.path);
  }

  navigateToPath(rawInput: string): void {
    this.isEditingPath.set(false);

    const parsed = this.pathService.parseLocation(rawInput, this.allRemotesLookup());
    if (parsed) {
      this.navigate(parsed.remote, parsed.path, true);
      return;
    }

    const normalized = this.pathService.normalizePath(rawInput);
    const currentPath = this.tabSvc.activePath();
    this.updatePath(currentPath ? `${currentPath}/${normalized}` : normalized);
  }

  protected onPopOutToWindow(): void {
    const remote = this.tabSvc.activeRemote()?.name ?? null;
    const path = this.tabSvc.activePath() ?? null;
    void this.nautilusService.newNautilusWindow(remote, path, true);
    this.closeOverlay.emit(null);
  }

  protected navigateTo(item: FileBrowserItem, isNewTab = false): void {
    const idx = this.tabSvc.activeTabIndex();
    const tab = this.tabSvc.tabs()[idx];
    if (!tab) return;
    const pane = this.tabSvc.activePaneIndex() === 0 ? tab.left : tab.right;
    if (!pane) return;

    if (item.entry.IsDir) {
      if (!isNewTab) {
        this.navigate(pane.remote, item.entry.Path, true);
      } else {
        this.tabSvc.createTab(pane.remote, item.entry.Path);
      }
    } else {
      if (this.isPickerMode()) {
        if (this.pickerOptions().multi) {
          return;
        }
        const pIdx = this.tabSvc.activePaneIndex();
        this.tabSvc.syncSelection(new Set([this.selectionSvc.getItemKey(item)]), pIdx);
        this.confirmSelection();
        return;
      }
      const files = this.getActivePaneFiles();
      void this.actions.openFilePreview(item, files);
    }
  }

  protected navigate(remote: ExplorerRoot | null, path: string, newHistory = true): void {
    this.tabSvc.navigate(remote, path, newHistory);
  }

  openBookmark(bookmark: FileBrowserItem): void {
    const remoteDetails = this.nautilusService.lookupRemoteByName(bookmark.meta.remote);
    if (!remoteDetails) {
      this.notificationService.showError(
        this.translate.instant('nautilus.errors.bookmarkRemoteNotFound', {
          remote: bookmark.meta.remote,
        })
      );
      return;
    }
    this.selectRemote(remoteDetails);
    this.updatePath(bookmark.entry.Path);
    if (this.isMobile()) this.sidenav()?.close();
  }

  selectStarred(): void {
    if (this.tabSvc.activeStarredMode()) return;
    this.navigate(null, '', true);
  }

  // ---------------------------------------------------------------------------
  // Split divider
  // ---------------------------------------------------------------------------

  onSplitDividerDrag(event: MouseEvent): void {
    event.preventDefault();
    const container = (event.target as HTMLElement).parentElement;
    if (!container) return;

    const onMouseMove = (e: MouseEvent): void => {
      const rect = container.getBoundingClientRect();
      const pos = ((e.clientX - rect.left) / rect.width) * 100;
      this.tabSvc.splitDividerPos.set(Math.max(20, Math.min(80, pos)));
    };

    const onMouseUp = (): void => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      this.settings.saveSplitDividerPos(this.tabSvc.splitDividerPos());
    };

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
  }

  // ---------------------------------------------------------------------------
  // Selection
  // ---------------------------------------------------------------------------

  getActivePaneFiles(paneIndex?: 0 | 1): FileBrowserItem[] {
    const idx = paneIndex ?? this.tabSvc.activePaneIndex();
    return idx === 0 ? this.files() : this.filesRight();
  }

  onItemClick(item: FileBrowserItem, event: Event, index: number, paneIndex: 0 | 1): void {
    const files = this.getActivePaneFiles(paneIndex);
    this.selectionSvc.handleItemClick(item, event as MouseEvent, index, paneIndex, files);

    // On mobile, single tap navigates/opens immediately.
    if (this.isMobile() && !(event as MouseEvent).ctrlKey && !(event as MouseEvent).shiftKey) {
      if (item.entry.IsDir || !this.isPickerMode() || !this.pickerOptions().multi) {
        this.navigateTo(item);
      }
    }
  }

  setContextItem(item: FileBrowserItem | null, paneIndex?: 0 | 1): void {
    this.contextMenu()?.reset();
    this.actions.contextMenuItem.set(item);
    const pIdx = paneIndex ?? this.tabSvc.activePaneIndex();
    const files = this.getActivePaneFiles(pIdx);
    this.selectionSvc.handleContextItem(item, pIdx, files);
  }

  protected onUpdateSelection(selection: Set<string>, paneIndex: 0 | 1): void {
    this.tabSvc.syncSelection(selection, paneIndex);
  }

  selectAll(): void {
    const files = this.getActivePaneFiles();
    this.selectionSvc.selectAll(this.tabSvc.activePaneIndex(), files);
  }

  protected readonly getItemKey = (item: FileBrowserItem | null): string =>
    this.selectionSvc.getItemKey(item);

  isItemSelectable = (item: Entry): boolean => this.selectionSvc.isItemSelectable(item);

  // ---------------------------------------------------------------------------
  // Clipboard & file ops (thin wrappers over NautilusFileOperationsService)
  // ---------------------------------------------------------------------------

  protected async pasteItems(targetFolder?: FileBrowserItem): Promise<void> {
    const contextItem = this.actions.contextMenuItem();
    const target = targetFolder ?? (contextItem?.entry?.IsDir ? contextItem : undefined);
    const dstPath = target?.entry?.IsDir
      ? this.pathService.joinPath(this.tabSvc.activePath(), target.entry.Name)
      : this.tabSvc.activePath();

    await this.fileOps.pasteItems(this.tabSvc.activeRemote(), dstPath, this.allRemotesLookup());
    this.tabSvc.refresh(this.tabSvc.activePaneIndex());
  }

  // ── Stars & bookmarks ────────────────────────────────────────────────────────
  isStarred(item: FileBrowserItem): boolean {
    const remote = item.meta.remote || this.tabSvc.nautilusRemote()?.name;
    if (!remote) return false;
    return this.nautilusService.isSaved('starred', remote, item.entry.Path);
  }

  // ── Misc ─────────────────────────────────────────────────────────────────────
  cancelLoad(paneIndex: 0 | 1 = 0): void {
    const pane = this.tabSvc.getPaneRef(paneIndex);
    pane.loading.set(false);
    void this.tabSvc.stopListReadGroup(this.tabSvc.listReadGroups[paneIndex]);
  }

  handleGoBack(): void {
    if (this.isSearchMode()) {
      this.isSearchMode.set(false);
      this.searchFilter.set('');
    } else if (this.tabSvc.canGoBack()) {
      this.tabSvc.goBack();
    }
  }

  toggleSearchMode(): void {
    this.isSearchMode.update(v => {
      const next = !v;
      if (!next) {
        this.searchFilter.set('');
      }
      return next;
    });
  }

  onSidebarSidenavAction(action: 'close' | 'toggle'): void {
    const sidenav = this.sidenav();
    if (!sidenav) return;
    if (action === 'close') sidenav.close();
    else sidenav.toggle();
  }

  // ---------------------------------------------------------------------------
  // Upload
  // ---------------------------------------------------------------------------

  /**
   * Triggered by toolbar "Upload Files" button.
   * Desktop: opens native file picker (Tauri IPC path).
   * Web:     triggers the hidden <input type="file"> (HTTP streaming path).
   */
  async uploadFiles(): Promise<void> {
    if (isHeadlessMode()) {
      this.fileUploadInput()?.nativeElement.click();
      return;
    }
    const remote = this.tabSvc.activeRemote();
    if (!remote) return;
    const success = await this.fileOps.uploadExternalFiles(remote, this.tabSvc.activePath());
    if (success) this.tabSvc.refresh(this.tabSvc.activePaneIndex());
  }

  /**
   * Triggered by toolbar "Upload Folder" button.
   * Desktop: opens native folder picker (Tauri IPC path).
   * Web:     triggers the hidden <input webkitdirectory> (HTTP streaming path).
   */
  async uploadFolder(): Promise<void> {
    if (isHeadlessMode()) {
      this.folderUploadInput()?.nativeElement.click();
      return;
    }
    const remote = this.tabSvc.activeRemote();
    if (!remote) return;
    const success = await this.fileOps.uploadExternalFolder(remote, this.tabSvc.activePath());
    if (success) this.tabSvc.refresh(this.tabSvc.activePaneIndex());
  }

  /**
   * Triggered when the user taps "Upload here" in the Android share banner.
   * Uses the paths stored in AndroidShareService and uploads them to the
   * current remote/folder.
   */
  async uploadSharedFiles(): Promise<void> {
    const remote = this.tabSvc.activeRemote();
    if (!remote) {
      this.notificationService.showError(
        this.translate.instant('nautilus.errors.noRemoteSelected')
      );
      return;
    }
    const paths = this.androidShare.consumePendingPaths();
    if (!paths.length) return;
    const success = await this.fileOps.uploadSharedPaths(remote, this.tabSvc.activePath(), paths);
    if (success) this.tabSvc.refresh(this.tabSvc.activePaneIndex());
  }

  /** Cancel the pending Android share without uploading. */
  cancelSharedFiles(): void {
    this.androidShare.cancelPendingShare();
  }

  /** Handler for the hidden file <input> — headless mode only. */
  async onWebUploadFiles(event: Event): Promise<void> {
    await this._handleWebUpload(event);
  }

  /** Handler for the hidden folder <input> — headless mode only. */
  async onWebUploadFolder(event: Event): Promise<void> {
    await this._handleWebUpload(event);
  }

  private async _handleWebUpload(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) return;
    const remote = this.tabSvc.activeRemote();
    if (remote) {
      const success = await this.fileOps.uploadWebFiles(
        remote,
        this.tabSvc.activePath(),
        input.files
      );
      if (success) this.tabSvc.refresh(this.tabSvc.activePaneIndex());
    }
    input.value = '';
  }

  // ---------------------------------------------------------------------------
  // Drag/drop passthrough (delegates to NautilusDragDropService)
  // ---------------------------------------------------------------------------

  onDragStarted(event: DragEvent, item: FileBrowserItem): void {
    const currentSelected = this.tabSvc.activeSelection();
    const items = currentSelected.has(this.getItemKey(item))
      ? (this.tabSvc.activePaneIndex() === 0 ? this.files() : this.filesRight()).filter(f =>
          currentSelected.has(this.getItemKey(f))
        )
      : [item];
    this.dragDrop.startDrag(event, items, this.tabSvc.activePaneIndex());
  }

  onDragEnded(): void {
    this.dragDrop.endDrag();
  }
  onDragOver(event: DragEvent): void {
    this.dragDrop.onDragOver(event);
  }
  onContainerDragEnter(event: DragEvent): void {
    this.dragDrop.onContainerDragEnter(event);
  }
  onContainerDragLeave(event: DragEvent): void {
    this.dragDrop.onContainerDragLeave(event);
  }
  onContainerDrop(event: DragEvent): void {
    this.dragDrop.onContainerDrop(event);
  }
  onDropToStarred(event: DragEvent): void {
    this.dragDrop.dropToStarred(event);
  }
  onDropToLocal(event: DragEvent): void {
    this.dragDrop.dropToLocal(event);
  }
  async onDropToBookmark(e: DragEvent, bm: FileBrowserItem): Promise<void> {
    await this.dragDrop.dropToBookmark(e, bm);
  }
  async onDropToRemote(e: DragEvent, remote: ExplorerRoot): Promise<void> {
    await this.dragDrop.dropToRemote(e, remote);
  }
  async onDropToCurrentDirectory(e: DragEvent, paneIndex: number): Promise<void> {
    await this.dragDrop.dropToCurrentDirectory(e, paneIndex);
  }
  async onDropToSegment(e: DragEvent, segIdx: number): Promise<void> {
    await this.dragDrop.dropToSegment(e, segIdx);
  }

  // ---------------------------------------------------------------------------
  // Picker confirmation
  // ---------------------------------------------------------------------------

  confirmSelection(): void {
    const files = this.getActivePaneFiles();
    let items = this.selectionSvc.getSelectedItemsList(files);
    const remote = this.tabSvc.activeRemote();
    const currentPath = this.tabSvc.activePath();

    if (this.isPickerMode()) {
      const opts = this.pickerOptions();
      // If picking files and user selected a single folder, opening it navigates into the folder
      if (opts.selection === 'files' && items.length === 1 && items[0].entry.IsDir) {
        this.navigateTo(items[0]);
        return;
      }
      // If picking files, filter out folders from confirmed selection
      if (opts.selection === 'files') {
        items = items.filter(i => !i.entry.IsDir);
      }
    }

    // Allow confirming the current folder when no individual item is selected.
    if (
      items.length === 0 &&
      (this.pickerOptions().selection === 'folders' || this.pickerOptions().selection === 'both') &&
      remote
    ) {
      const name = this.pathService.extractName(currentPath, remote.name);
      items = [
        {
          entry: {
            Name: name,
            Path: currentPath,
            IsDir: true,
            Size: -1,
            ModTime: new Date().toISOString(),
            ID: '',
            MimeType: 'inode/directory',
          },
          meta: { remote: remote.name, isLocal: remote.isLocal, remoteType: remote.type },
        },
      ];
    }

    const minSel = this.pickerOptions().minSelection ?? 0;
    if (this.isPickerMode() && items.length < minSel) {
      this.notificationService.showError(
        this.translate.instant('nautilus.errors.minSelection', {
          min: minSel,
          s: minSel > 1 ? 's' : '',
        })
      );
      return;
    }

    this.closeOverlay.emit(items);
  }

  // ---------------------------------------------------------------------------
  // Private helpers
  // ---------------------------------------------------------------------------

  private _getPaneFiles(paneIndex: number): FileBrowserItem[] {
    const isStarred = paneIndex === 0 ? this.tabSvc.starredMode() : this.tabSvc.starredModeRight();
    const rawFiles = paneIndex === 0 ? this.tabSvc.rawFiles() : this.tabSvc.rawFilesRight();
    const cfg = this.pickerOptions();
    const isPicker = this.isPickerMode();

    let files: FileBrowserItem[];

    if (isStarred) {
      files = this.nautilusService.starredItems();
      if (isPicker) {
        files = files.filter(i => {
          if (cfg.mode === 'local' && !i.meta.isLocal) return false;
          if (cfg.mode === 'remote' && i.meta.isLocal) return false;
          if (cfg.allowedRemotes?.length && !i.meta.isLocal) {
            return cfg.allowedRemotes.includes(
              this.pathService.normalizeRemoteName(i.meta.remote ?? '')
            );
          }
          return true;
        });
      }
    } else {
      files = rawFiles;
    }

    if (isPicker) {
      if (cfg.selection === 'folders') {
        files = files.filter(f => f.entry.IsDir);
      } else if (cfg.selection === 'files') {
        // In 'files' mode, we usually still show folders for navigation,
        // but we've already handled their selectability in selection.service.
        // If the user wants to HIDE them, we could filter here, but usually
        // folders are kept for navigation.
      }
    }

    if (!this.settings.showHidden() && !isStarred) {
      files = files.filter(f => !f.entry.Name.startsWith('.'));
    }

    const search = this.searchFilter().toLowerCase().trim();
    if (search) {
      files = files.filter(f => f.entry.Name.toLowerCase().includes(search));
    }

    return this._sortFiles(files);
  }

  private _sortFiles(files: FileBrowserItem[]): FileBrowserItem[] {
    const list = [...files];
    const sort = this.settings.sortColumn();
    const multiplier = this.settings.sortAscending() ? 1 : -1;

    if (sort === 'modified') {
      const timeMap = new Map<string, number>();
      for (const item of list) {
        timeMap.set(this.getItemKey(item), Date.parse(item.entry.ModTime) || 0);
      }
      return list.sort((a, b) => {
        if (a.entry.IsDir !== b.entry.IsDir) return a.entry.IsDir ? -1 : 1;
        const aHidden = a.entry.Name.startsWith('.');
        const bHidden = b.entry.Name.startsWith('.');
        if (aHidden !== bHidden) return aHidden ? 1 : -1;
        const aTime = timeMap.get(this.getItemKey(a)) ?? 0;
        const bTime = timeMap.get(this.getItemKey(b)) ?? 0;
        return (aTime - bTime) * multiplier;
      });
    }

    return list.sort((a, b) => {
      if (a.entry.IsDir !== b.entry.IsDir) return a.entry.IsDir ? -1 : 1;
      const aHidden = a.entry.Name.startsWith('.');
      const bHidden = b.entry.Name.startsWith('.');
      if (aHidden !== bHidden) return aHidden ? 1 : -1;

      switch (sort) {
        case 'name':
          return (
            a.entry.Name.localeCompare(b.entry.Name, undefined, { numeric: true }) * multiplier
          );
        case 'size':
          return (a.entry.Size - b.entry.Size) * multiplier;
        default:
          return 0;
      }
    });
  }

  protected async toggleSendToRegistration(): Promise<void> {
    const remote = this.tabSvc.activeRemote();
    const path = this.tabSvc.activePath();
    if (!remote || remote.isLocal) return;

    const registered = this.isCurrentPathRegistered();

    try {
      if (registered) {
        await this.nautilusService.unregisterSendTo(remote.name, path);
      } else {
        await this.nautilusService.registerSendTo(remote.name, path);
      }
      this.isCurrentPathRegistered.set(!registered);

      const msgKey = registered
        ? 'nautilus.notifications.sendToRemoved'
        : 'nautilus.notifications.sendToAdded';
      this.notificationService.showSuccess(
        this.translate.instant(msgKey, { remote: remote.name, path: path || '/' })
      );
    } catch (e) {
      this.notificationService.showError(
        this.translate.instant('nautilus.errors.sendToFailed', { error: (e as Error).message })
      );
    }
  }
}
