import {
  Component,
  effect,
  input,
  output,
  signal,
  computed,
  untracked,
  inject,
  ChangeDetectionStrategy,
} from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { toSignal } from '@angular/core/rxjs-interop';
import { startWith } from 'rxjs';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatButtonModule } from '@angular/material/button';
import { MatIcon } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { TranslatePipe } from '@ngx-translate/core';
import {
  RcConfigOption,
  RemoteType,
  RemoteConfigStepVisibility,
  CommandOption,
  PREDEFINED_OPTIONS,
} from '@app/types';
import { IconService } from 'src/app/services/ui/icon.service';
import { matchesConfigSearch } from 'src/app/services/remote/utils/remote-config.utils';
import { RemoteManagementService } from 'src/app/services/remote/remote-management.service';
import { JsonEditorComponent } from 'src/app/shared/components/json-editor/json-editor.component';
import { SettingControlComponent } from 'src/app/shared/components/setting-control/setting-control.component';
import {
  INITIAL_COMMAND_OPTIONS,
  syncNonInteractiveOption,
} from 'src/app/services/remote/utils/command-options.util';
import { findUniqueName } from 'src/app/services/remote/utils/unique-name.util';

import { UiStateService } from 'src/app/services/ui/state/ui-state.service';

@Component({
  selector: 'app-remote-config-step',
  imports: [
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSlideToggleModule,
    MatAutocompleteModule,
    MatButtonModule,
    MatSelectModule,
    SettingControlComponent,
    JsonEditorComponent,
    TranslatePipe,
    MatIcon,
  ],
  templateUrl: './remote-config-step.component.html',
  styleUrl: './remote-config-step.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RemoteConfigStepComponent {
  private readonly remoteManagementService = inject(RemoteManagementService);
  private readonly iconService = inject(IconService);
  private readonly uiStateService = inject(UiStateService);

  // ── Inputs ─────────────────

  readonly form = input.required<FormGroup>();
  readonly remoteFields = input<RcConfigOption[]>([]);
  readonly isLoading = input<boolean>(false);
  readonly existingRemotes = input<string[]>([]);
  readonly isTypeLocked = input(false);
  readonly isNameLocked = input(false);
  readonly remoteTypes = input<RemoteType[]>([]);
  readonly visibility = input<RemoteConfigStepVisibility>({});
  readonly showAdvancedOptions = input<boolean>(false);
  readonly searchQuery = input<string>('');
  readonly initialCommandOptions = input<CommandOption[]>([]);

  // ── Outputs ───────────────────────────────────────────────────────────────

  readonly remoteTypeChanged = output<void>();
  readonly advancedOptionsToggled = output<boolean>();
  readonly fieldChanged = output<{ fieldName: string; isChanged: boolean }>();
  readonly commandOptionsChanged = output<CommandOption[]>();

  // ── Visibility ────────────────────────────────────────────────────────────

  readonly showTypeField = computed(() => this.visibility().type ?? true);
  readonly showAdvancedToggle = computed(() => this.visibility().advanced ?? true);
  readonly showNameField = computed(() => this.visibility().name ?? true);
  readonly showCommandField = computed(() => this.visibility().commands !== false);

  // ── Local form controls ───────────────────────────────────────────────────

  readonly remoteSearchCtrl = new FormControl('');
  readonly providerSearchCtrl = new FormControl('');

  readonly remoteTypeValue = signal('');

  private readonly remoteSearchTerm = toSignal(this.remoteSearchCtrl.valueChanges, {
    initialValue: this.remoteSearchCtrl.value ?? '',
  });

  private readonly providerSearchTerm = toSignal(this.providerSearchCtrl.valueChanges, {
    initialValue: this.providerSearchCtrl.value ?? '',
  });

  // ── Signals ───────────────────────────────────────────────────────────────

  readonly selectedProvider = signal<string | undefined>(undefined);
  readonly showJsonMode = this.uiStateService.showJsonMode;
  readonly showCommandOptions = signal(false);
  readonly commandOptions = signal<CommandOption[]>(INITIAL_COMMAND_OPTIONS);
  readonly newOptionKey = signal('');
  readonly newOptionType = signal<'boolean' | 'string' | 'number' | 'array'>('boolean');
  readonly randomIcon = signal('cloud');
  readonly suggestedRemotes = signal<{ label: string; value: string; icon: string }[]>([]);

  // ── Computed View Models ──────────────────────────────────────────────────

  readonly remoteTypeIcon = computed(() =>
    this.iconService.getIconName(this.remoteTypeValue() || 'hard-drive')
  );
  readonly currentProviderIcon = computed(() =>
    this.iconService.getIconName(this.selectedProvider() || 'hard-drive')
  );

  readonly remoteTypesWithIcons = computed(() =>
    this.remoteTypes().map(r => ({ ...r, icon: this.iconService.getIconName(r.value) }))
  );

  readonly filteredRemotes = computed(() => {
    const term = (this.remoteSearchTerm() ?? '').toLowerCase();
    return this.remoteTypesWithIcons().filter(
      r => r.label.toLowerCase().includes(term) || r.value.toLowerCase().includes(term)
    );
  });

  readonly providerField = computed(() => {
    const fields = this.remoteFields();
    const byName = fields.find(f => f.Name === 'provider' && f.Examples?.length);
    if (byName) return byName;
    if (!fields.some(f => f.Provider)) return null;
    return fields.find(f => f.Examples?.length) ?? null;
  });

  readonly filteredProvidersView = computed(() => {
    const field = this.providerField();
    if (!field?.Examples) return [];
    const term = (this.providerSearchTerm() ?? '').toLowerCase();
    return field.Examples.filter(
      o => o.Value?.toLowerCase().includes(term) || o.Help?.toLowerCase().includes(term)
    ).map(o => ({
      ...o,
      icon: this.iconService.getIconName(o.Value || 'hard-drive'),
    }));
  });

  readonly basicFields = computed(() => this.getFieldsByAdvanced(false));
  readonly advancedFields = computed(() => this.getFieldsByAdvanced(true));

  readonly providerReady = computed(
    () => !!this.remoteTypeValue() && (!this.providerField() || !!this.selectedProvider())
  );

  readonly jsonExcludeKeys = ['name', 'type'];

  readonly availablePredefinedOptions = computed(() => {
    const active = new Set(this.commandOptions().map(o => o.key));
    return PREDEFINED_OPTIONS.filter(p => !active.has(p.key));
  });

  readonly commandOptionsView = computed(() => {
    return this.commandOptions().map(opt => {
      const isArray = Array.isArray(opt.value);
      const typeOfVal = typeof opt.value;
      const type = isArray
        ? 'array'
        : typeOfVal === 'boolean' || typeOfVal === 'number'
          ? typeOfVal
          : 'string';

      return {
        ...opt,
        type,
        booleanValue: type === 'boolean' ? (opt.value as boolean) : false,
        stringValue: type === 'string' || type === 'number' ? String(opt.value) : '',
        arrayValue: isArray ? (opt.value as string[]) : [],
      };
    });
  });

  // ── Effects ───────────────────────────────────────────────────────────────

  constructor() {
    // Track remote type control value changes
    effect(onCleanup => {
      const form = this.form();
      const typeCtrl = form?.get('type');
      if (!typeCtrl) return;

      this.remoteTypeValue.set((typeCtrl.value as string) || '');
      const sub = typeCtrl.valueChanges.subscribe(val => this.remoteTypeValue.set(val || ''));
      onCleanup(() => sub.unsubscribe());
    });

    // Emit command options changes (skip initial)
    let isFirstCommandOptionsRun = true;
    effect(() => {
      const opts = this.commandOptions();
      if (isFirstCommandOptionsRun) {
        isFirstCommandOptionsRun = false;
        return;
      }
      this.commandOptionsChanged.emit(opts);
    });

    effect(() => {
      const initial = this.initialCommandOptions();
      if (initial !== undefined && initial.length > 0) {
        untracked(() => this.commandOptions.set(initial));
      }
    });

    effect(onCleanup => {
      const typeControl = this.form().get('type');
      if (!typeControl) return;

      const sub = typeControl.valueChanges
        .pipe(startWith(typeControl.value))
        .subscribe(val =>
          this.remoteSearchCtrl.setValue(this.displayRemote(val), { emitEvent: false })
        );

      onCleanup(() => sub.unsubscribe());
    });

    effect(onCleanup => {
      const fieldDef = this.providerField();
      if (!fieldDef) return;

      const control = this.form().get(fieldDef.Name);
      if (!control) return;

      const sub = control.valueChanges.pipe(startWith(control.value)).subscribe(val => {
        const prev = untracked(this.selectedProvider);
        if (val === prev) return;

        untracked(() => {
          this.selectedProvider.set(val);
          if (prev) this.clearProviderDependentFields(this.remoteFields(), this.form(), val);

          const display = this.displayProvider(val);
          if (display !== this.providerSearchCtrl.value) {
            this.providerSearchCtrl.setValue(display, { emitEvent: false });
          }
        });
      });

      onCleanup(() => sub.unsubscribe());
    });

    effect(() => {
      const opts = { emitEvent: false } as const;
      if (this.isTypeLocked()) {
        this.remoteSearchCtrl.disable(opts);
      } else {
        this.remoteSearchCtrl.enable(opts);
      }
    });

    effect(() => {
      const opts = { emitEvent: false } as const;
      const nameControl = this.form().get('name');
      if (!nameControl) return;

      if (this.isNameLocked()) {
        nameControl.disable(opts);
      } else {
        nameControl.enable(opts);
      }
    });

    effect(() => {
      const types = this.remoteTypesWithIcons();
      if (types.length > 0 && untracked(this.suggestedRemotes).length === 0) {
        this.suggestedRemotes.set(this.shuffleSample(types));
      }
    });

    effect(() => {
      const isInteractive = this.remoteManagementService.isInteractiveRemote(
        this.remoteTypeValue()
      );

      untracked(() => {
        const current = this.commandOptions();
        const next = syncNonInteractiveOption(current, isInteractive);
        if (next !== current) this.commandOptions.set(next);
      });
    });

    effect(onCleanup => {
      if (this.showTypeField() && !this.remoteTypeValue() && !this.isLoading()) {
        const types = this.remoteTypesWithIcons();
        if (types.length === 0) return;

        const pickNextIcon = (): string => {
          if (types.length === 1) return types[0].icon;
          const current = this.randomIcon();
          let nextIcon: string;
          do {
            nextIcon = types[Math.floor(Math.random() * types.length)].icon;
          } while (nextIcon === current);
          return nextIcon;
        };

        const id = setInterval(() => {
          this.randomIcon.set(pickNextIcon());
        }, 3000);
        onCleanup(() => clearInterval(id));
      } else {
        this.randomIcon.set('cloud');
      }
    });
  }

  // ── Private helpers ───────────────────────────────────────────────────────

  private matchesProviderRule(rule: string | undefined, provider?: string): boolean {
    if (!rule) return true;
    if (!provider) return false;
    const negated = rule.startsWith('!');
    const parts = (negated ? rule.slice(1) : rule).split(',').map(p => p.trim());
    return negated ? !parts.includes(provider) : parts.includes(provider);
  }

  private getFilteredField(field: RcConfigOption, provider?: string): RcConfigOption {
    if (!field.Examples?.length || !provider) return field;
    return {
      ...field,
      Examples: field.Examples.filter(ex => this.matchesProviderRule(ex.Provider, provider)),
    };
  }

  private getFieldsByAdvanced(isAdvanced: boolean): RcConfigOption[] {
    const providerName = this.providerField()?.Name;
    const currentProvider = this.selectedProvider();
    const query = this.searchQuery().trim();

    return this.remoteFields()
      .filter(f => !!f.Advanced === isAdvanced)
      .filter(f => f.Name !== providerName)
      .filter(f => this.matchesProviderRule(f.Provider, currentProvider))
      .map(f => this.getFilteredField(f, currentProvider))
      .filter(f => matchesConfigSearch(f, query));
  }

  private clearProviderDependentFields(
    fields: RcConfigOption[],
    form: FormGroup,
    newProvider: string
  ): void {
    for (const field of fields) {
      const control = form.get(field.Name);
      if (!control) continue;

      if (field.Provider && !this.matchesProviderRule(field.Provider, newProvider)) {
        control.setValue(null);
        continue;
      }

      if (field.Examples?.length) {
        const current = control.value;
        if (current && !this.isValueValidForProvider(field, current, newProvider)) {
          control.setValue('');
        }
      }
    }
  }

  private isValueValidForProvider(field: RcConfigOption, value: string, provider: string): boolean {
    const match = field.Examples?.find(ex => ex.Value === value);
    return !(match && !this.matchesProviderRule(match.Provider, provider));
  }

  private shuffleSample<T>(list: T[], count = 5): T[] {
    const copy = [...list];
    for (let i = copy.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy.slice(0, count);
  }

  // ── Template bindings ─────────────────────────────────────────────────────

  readonly displayRemote = (value: string): string =>
    this.remoteTypes().find(t => t.value === value)?.label ?? value ?? '';

  readonly displayProvider = (value: string): string =>
    this.providerField()?.Examples?.find(o => o.Value === value)?.Help ?? value;

  onTypeSelected(value: string): void {
    this.form().get('type')?.setValue(value);
    this.generateRemoteName(value);
    this.remoteTypeChanged.emit();
  }

  clearType(): void {
    this.form().get('type')?.setValue('');
    this.remoteSearchCtrl.setValue('');
    this.remoteTypeChanged.emit();
  }

  stopAndClearType(event: MouseEvent): void {
    event.stopPropagation();
    this.clearType();
  }

  private generateRemoteName(remoteType: string): void {
    const nameControl = this.form().get('name');
    if (!nameControl || (nameControl.value && nameControl.dirty)) return;

    const base = remoteType.replace(/\s+/g, '');
    const name = findUniqueName(base, this.existingRemotes());

    nameControl.setValue(name, { emitEvent: true });
    nameControl.updateValueAndValidity({ emitEvent: false });
    if (nameControl.invalid) nameControl.markAsTouched();
  }

  toggleJsonMode(): void {
    this.uiStateService.toggleShowJsonMode();
  }

  toggleAdvancedOptions(): void {
    const nextVal = !this.showAdvancedOptions();
    this.advancedOptionsToggled.emit(nextVal);
  }

  toggleCommandOptions(): void {
    this.showCommandOptions.update(v => !v);
  }

  onProviderSelected(value: string): void {
    const field = this.providerField();
    if (field) this.form().get(field.Name)?.setValue(value);
  }

  onFieldChanged(fieldName: string, isChanged: boolean): void {
    this.fieldChanged.emit({ fieldName, isChanged });
  }

  // ── Command option mutations ──────────────────────────────────────────────

  addPredefinedOption(predefined: CommandOption): void {
    this.commandOptions.update(opts => [...opts, { ...predefined }]);
  }

  addCustomOption(): void {
    const key = this.newOptionKey().trim();
    if (!key) return;

    const type = this.newOptionType();
    const value: CommandOption['value'] =
      type === 'boolean' ? true : type === 'number' ? 0 : type === 'array' ? [] : '';

    this.commandOptions.update(opts => [...opts, { key, value }]);
    this.newOptionKey.set('');
  }

  removeOption(key: string): void {
    this.commandOptions.update(opts => opts.filter(o => o.key !== key));
  }

  updateOption(key: string, value: CommandOption['value']): void {
    this.commandOptions.update(opts => opts.map(o => (o.key === key ? { ...o, value } : o)));
  }

  updateNumberOption(key: string, rawValue: string): void {
    const num = parseFloat(rawValue);
    if (!isNaN(num)) this.updateOption(key, num);
  }

  addArrayChip(key: string, value: string, input: HTMLInputElement): void {
    const val = value.trim();
    if (!val) return;
    this.commandOptions.update(opts =>
      opts.map(o => (o.key === key ? { ...o, value: [...(o.value as string[]), val] } : o))
    );
    input.value = '';
  }

  handleArrayChipKeydown(key: string, event: KeyboardEvent | Event, input: HTMLInputElement): void {
    if (event instanceof KeyboardEvent) {
      if (event.key !== 'Enter' && event.key !== ',') return;
      event.preventDefault();
    }
    this.addArrayChip(key, input.value, input);
  }

  removeArrayChip(key: string, index: number): void {
    this.commandOptions.update(opts =>
      opts.map(o =>
        o.key === key ? { ...o, value: (o.value as string[]).filter((_, i) => i !== index) } : o
      )
    );
  }

  reshuffleSuggestions(): void {
    this.suggestedRemotes.set(this.shuffleSample(this.remoteTypesWithIcons()));
  }
}
