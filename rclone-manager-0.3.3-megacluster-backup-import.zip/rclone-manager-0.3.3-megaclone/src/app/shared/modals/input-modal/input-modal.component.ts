import {
  Component,
  HostListener,
  inject,
  OnInit,
  DestroyRef,
  ChangeDetectionStrategy,
  signal,
  computed,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import {
  FormsModule,
  ReactiveFormsModule,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { PathService } from 'src/app/services/infrastructure/platform/path.service';
import { ValidatorRegistryService } from 'src/app/services/ui/validation/validator-registry.service';
import { UrlPreviewComponent } from '../../components/url-preview/url-preview.component';
import { EscapeCloseDirective } from '../../directives/escape-close.directive';

export interface InputFieldConfig {
  key: string;
  label?: string;
  placeholder?: string;
  initialValue?: string;
  type?: 'text' | 'password' | 'url';
  required?: boolean;
  forbiddenChars?: boolean;
  uniqueness?: {
    existingNames: string[];
    typeLabel?: string;
  };
}

export interface InputModalData {
  title?: string;
  label?: string;
  icon: string;
  placeholder?: string;
  initialValue?: string;
  existingNames?: string[];
  existingNameType?: string;
  createLabel?: string;
  forbiddenCharsMessage?: string;
  fields?: InputFieldConfig[];
  destinationPath?: string;
  showUrlPreview?: boolean;
}

@Component({
  selector: 'app-input-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    TranslatePipe,
    UrlPreviewComponent,
  ],
  templateUrl: './input-modal.component.html',
  hostDirectives: [EscapeCloseDirective],
  styleUrls: ['./input-modal.component.scss', '../../../styles/_shared-modal.scss'],
})
export class InputModalComponent implements OnInit {
  public readonly dialogRef = inject(MatDialogRef<InputModalComponent>);
  public readonly data = inject<InputModalData>(MAT_DIALOG_DATA);
  protected readonly translate = inject(TranslateService);
  private readonly pathService = inject(PathService);
  private readonly validatorRegistry = inject(ValidatorRegistryService);
  private readonly destroyRef = inject(DestroyRef);

  public form = new FormGroup<Record<string, FormControl>>({});
  public fields: InputFieldConfig[] = [];

  readonly urlValue = signal('');
  readonly filenameValue = signal('');
  readonly hasUrlField = computed(
    () => this.fields.some(f => f.type === 'url') || !!this.data.showUrlPreview
  );

  ngOnInit(): void {
    if (this.data.fields && this.data.fields.length > 0) {
      this.fields = this.data.fields;
    } else {
      // Create a default field for backward compatibility
      this.fields = [
        {
          key: 'single',
          label: this.data.label,
          placeholder: this.data.placeholder,
          initialValue: this.data.initialValue,
          required: true,
          forbiddenChars: true,
          uniqueness: this.data.existingNames
            ? {
                existingNames: this.data.existingNames,
                typeLabel: this.data.existingNameType,
              }
            : undefined,
        },
      ];
    }

    this.initForm();
  }

  private initForm(): void {
    for (const field of this.fields) {
      const validators = [];
      if (field.required) validators.push(Validators.required);
      if (field.uniqueness)
        validators.push(this.validatorRegistry.createUniqueNameValidator(field.uniqueness));
      if (field.forbiddenChars)
        validators.push(this.validatorRegistry.createForbiddenCharsValidator());

      const control = new FormControl(field.initialValue || '', {
        nonNullable: true,
        validators,
      });

      this.form.addControl(field.key, control);
    }
    this.form.updateValueAndValidity();

    // Initial signal values
    const urlKey = this.fields.find(f => f.type === 'url')?.key || 'url';
    this.urlValue.set(this.form.get(urlKey)?.value || '');
    this.filenameValue.set(this.form.get('filename')?.value || '');

    // Track live changes
    this.form.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(val => {
      this.urlValue.set(val[urlKey] || '');
      this.filenameValue.set(val['filename'] || '');
    });

    this.setupUrlAutoFilename();
  }

  private setupUrlAutoFilename(): void {
    const urlControl = this.form.get('url');
    const filenameControl = this.form.get('filename');

    if (urlControl && filenameControl) {
      urlControl.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(url => {
        if (!url) return;

        const currentFilename = (filenameControl.value || '').toString().trim();
        if (!currentFilename || filenameControl.pristine) {
          const extracted = this.extractFilenameFromUrl(url);
          if (extracted) {
            filenameControl.setValue(extracted);
            filenameControl.markAsPristine();
          }
        }
      });
    }
  }

  private extractFilenameFromUrl(url: string): string | null {
    try {
      const parsed = new URL(url);
      const path = parsed.pathname || '';
      const candidate = this.pathService.getFilename(path).trim();
      const filename = candidate.split('?')[0].split('#')[0];
      if (!filename) return null;
      if (filename.includes('.') && !filename.endsWith('.')) {
        return filename;
      }
      return null;
    } catch {
      return null;
    }
  }

  @HostListener('document:keydown.enter')
  onEnterKey(): void {
    if (this.form.valid) this.onConfirm();
  }

  getControl(key: string): FormControl {
    return this.form.get(key) as FormControl;
  }

  onConfirm(): void {
    const val = this.form.getRawValue() as Record<string, unknown>;
    // If it was a single field (legacy or just one defined), return the string value for convenience
    const keys = Object.keys(val);
    if (keys.length === 1 && (keys[0] === 'single' || !this.data.fields)) {
      const result = val[keys[0]];
      this.dialogRef.close(typeof result === 'string' ? result.trim() : result);
    } else {
      this.dialogRef.close(val);
    }
  }

  onCancel(): void {
    this.dialogRef.close(null);
  }
}
