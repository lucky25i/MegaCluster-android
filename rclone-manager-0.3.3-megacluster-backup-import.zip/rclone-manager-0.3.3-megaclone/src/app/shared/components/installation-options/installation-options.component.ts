import {
  Component,
  inject,
  OnInit,
  ChangeDetectionStrategy,
  input,
  output,
  signal,
  computed,
} from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import { FileSystemService } from 'src/app/services/operations/file-system.service';
import { SystemInfoService } from 'src/app/services/infrastructure/system/system-info.service';
import {
  InstallationOptionsData,
  InstallationTabOption,
  LocationType,
  BinaryStatus,
} from '@app/types';

@Component({
  selector: 'app-installation-options',
  imports: [
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    TranslatePipe,
  ],
  templateUrl: './installation-options.component.html',
  styleUrl: './installation-options.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class InstallationOptionsComponent implements OnInit {
  disabled = input(false);
  mode = input<'install' | 'config'>('install');
  tabOptions = input<readonly InstallationTabOption[]>([
    { key: 'default', label: 'shared.installationOptions.tabs.quickFix', icon: 'bolt' },
    { key: 'custom', label: 'shared.installationOptions.tabs.custom', icon: 'folder' },
    { key: 'existing', label: 'shared.installationOptions.tabs.existing', icon: 'file' },
  ]);

  dataChange = output<InstallationOptionsData>();
  validChange = output<boolean>();

  installLocation = signal<LocationType>('default');
  binaryTestResult = signal<BinaryStatus>('untested');

  customPathControl = new FormControl('');
  existingBinaryControl = new FormControl('');

  private fs = inject(FileSystemService);
  private system = inject(SystemInfoService);
  private translate = inject(TranslateService);

  readonly statusText = computed(() => {
    const labels: Record<BinaryStatus, string> = {
      untested: 'shared.installationOptions.status.untested',
      testing: 'shared.installationOptions.status.testing',
      valid: 'shared.installationOptions.status.valid',
      invalid: 'shared.installationOptions.status.invalid',
    };
    return this.translate.instant(labels[this.binaryTestResult()]);
  });

  readonly statusIcon = computed(() => {
    const icons: Record<BinaryStatus, string> = {
      untested: 'help',
      testing: 'spinner',
      valid: 'check-circle',
      invalid: 'circle-xmark',
    };
    return icons[this.binaryTestResult()];
  });

  constructor() {
    this.customPathControl.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => this.emit());

    this.existingBinaryControl.valueChanges.pipe(takeUntilDestroyed()).subscribe(() => {
      if (this.installLocation() === 'existing') {
        this.binaryTestResult.set('untested');
      }
      this.emit();
    });
  }

  ngOnInit(): void {
    this.emit();
  }

  setLocation(location: LocationType): void {
    this.installLocation.set(location);

    if (location !== 'custom') this.customPathControl.setValue('', { emitEvent: false });
    if (location !== 'existing') {
      this.existingBinaryControl.setValue('', { emitEvent: false });
      this.binaryTestResult.set('untested');
    }

    if (location === 'existing' && this.existingBinaryControl.value?.trim()) {
      this.testBinary();
    }

    this.emit();
  }

  async selectCustomPath(): Promise<void> {
    const path =
      this.mode() === 'config' ? await this.fs.selectFile() : await this.fs.selectFolder();
    if (path) this.customPathControl.setValue(path);
  }

  async selectBinary(): Promise<void> {
    const path = await this.fs.selectFile();
    if (path) {
      this.existingBinaryControl.setValue(path);
      this.binaryTestResult.set('untested');
      await this.testBinary();
    }
  }

  async testBinary(): Promise<void> {
    const path = this.existingBinaryControl.value?.trim();
    if (!path) {
      this.binaryTestResult.set('untested');
      this.emit();
      return;
    }

    this.binaryTestResult.set('testing');
    this.emit();

    try {
      const valid = await this.system.isRcloneAvailable(path);
      this.binaryTestResult.set(valid ? 'valid' : 'invalid');
    } catch {
      this.binaryTestResult.set('invalid');
    }

    this.emit();
  }

  getError(control: FormControl): string {
    if (control.hasError('required'))
      return this.translate.instant('shared.installationOptions.errors.required');
    return '';
  }

  private emit(): void {
    const data: InstallationOptionsData = {
      installLocation: this.installLocation(),
      customPath: this.customPathControl.value || '',
      existingBinaryPath: this.existingBinaryControl.value || '',
      binaryTestResult: this.binaryTestResult(),
    };

    this.dataChange.emit(data);
    this.validChange.emit(this.isValid());
  }

  private isValid(): boolean {
    switch (this.installLocation()) {
      case 'default':
        return true;
      case 'custom':
        return !!this.customPathControl.value?.trim() && this.customPathControl.valid;
      case 'existing':
        return (
          !!this.existingBinaryControl.value?.trim() &&
          this.existingBinaryControl.valid &&
          this.binaryTestResult() === 'valid'
        );
    }
  }
}
