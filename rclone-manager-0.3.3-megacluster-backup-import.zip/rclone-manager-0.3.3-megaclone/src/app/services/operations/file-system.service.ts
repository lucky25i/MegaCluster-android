import { inject, Injectable } from '@angular/core';
import { TauriBaseService } from '../infrastructure/platform/tauri-base.service';
import { NautilusService } from '../ui/nautilus.service';
import { FilePickerConfig, FilePickerResult } from '@app/types';
import { PathService } from '../infrastructure/platform/path.service';
import { filter, firstValueFrom } from 'rxjs';
import { isMobile } from '../infrastructure/platform/api-client.service';
import { BackendService } from '../infrastructure/system/backend.service';
import { generatePrefixedId } from 'src/app/shared/utils';

/**
 * Service for file system operations
 * Handles file/folder selection and system integration
 */
@Injectable({
  providedIn: 'root',
})
export class FileSystemService extends TauriBaseService {
  private nautilusService = inject(NautilusService);
  private backendService = inject(BackendService);
  private pathService = inject(PathService);

  /**
   * Returns true if the internal Nautilus browser should be used instead of native system dialogs.
   * This is true in headless mode or when a remote rclone backend is active.
   */
  private isInternalBrowserPreferred(): boolean {
    return !this.isTauri || this.backendService.activeBackend() !== 'Local' || isMobile();
  }

  /**
   * Select a folder with optional empty requirement
   * @param requireEmpty - If true, require the folder to be empty (for mount destinations)
   * @param initialPath - Optional initial path to open the picker to
   */
  async selectFolder(requireEmpty?: boolean, initialPath?: string): Promise<string> {
    // If internal browser is preferred (headless or remote backend), use Nautilus
    if (this.isInternalBrowserPreferred()) {
      const config: FilePickerConfig = {
        mode: 'local',
        selection: 'folders',
        multi: false,
        initialLocation: initialPath,
      };
      const result = await this.selectPathWithNautilus(config);
      if (result.cancelled || (result.items.length === 0 && result.paths.length === 0)) {
        throw new Error('Folder selection cancelled');
      }
      // Return full path constructed by Nautilus
      return result.paths[0];
    }

    // In Tauri mode, use native dialog
    try {
      return await this.invokeCommand<string>('get_folder_location', {
        requireEmpty: requireEmpty || false,
        initialPath,
      });
    } catch (error) {
      this.notificationService.confirmModal(
        this.translate.instant('common.error'),
        String(error),
        '',
        'common.close',
        {
          icon: 'circle-exclamation',
          color: 'warn',
        }
      );
      throw error;
    }
  }

  /**
   * Select a path using the integrated Nautilus file browser
   */
  async selectPathWithNautilus(config: FilePickerConfig): Promise<FilePickerResult> {
    const requestId = config.requestId ?? generatePrefixedId('picker');

    this.nautilusService.openFilePicker({ ...config, requestId });
    return firstValueFrom(
      this.nautilusService.filePickerResult$.pipe(filter(result => result.requestId === requestId))
    );
  }

  /**
   * Select a file
   * @param initialPath - Optional initial path to open the picker to
   */
  async selectFile(initialPath?: string): Promise<string> {
    // If internal browser is preferred (headless or remote backend), use Nautilus
    if (this.isInternalBrowserPreferred()) {
      const config: FilePickerConfig = {
        mode: 'local',
        selection: 'files',
        multi: false,
        initialLocation: initialPath,
      };
      const result = await this.selectPathWithNautilus(config);
      if (result.cancelled || (result.items.length === 0 && result.paths.length === 0)) {
        throw new Error('File selection cancelled');
      }
      // Return full path constructed by Nautilus
      return result.paths[0];
    }

    // In Tauri mode, use native dialog
    try {
      return await this.invokeCommand<string>('get_file_location', { initialPath });
    } catch (error) {
      this.notificationService.confirmModal(
        this.translate.instant('common.error'),
        String(error),
        '',
        'common.close',
        {
          icon: 'circle-exclamation',
          color: 'warn',
        }
      );
      throw error;
    }
  }

  /**
   * Select multiple local files for uploading.
   * On mobile/headless: uses Nautilus in local-only mode.
   * On desktop: uses native multi-file dialog.
   */
  async selectFilesForUpload(): Promise<string[]> {
    if (this.isInternalBrowserPreferred()) {
      const config: FilePickerConfig = {
        mode: 'local',
        selection: 'files',
        multi: true,
      };
      const result = await this.selectPathWithNautilus(config);
      if (result.cancelled) return [];
      return result.paths;
    }
    try {
      const paths = await this.invokeCommand<string[] | null>('get_files_location');
      return paths ?? [];
    } catch {
      return [];
    }
  }

  /**
   * Open a path in the system file manager
   */
  async openInFiles(path: string): Promise<void> {
    if (!path) return;

    if (!this.isTauri) {
      const { remote, remainder } = this.pathService.splitLocalPath(path);
      return this.nautilusService.newNautilusWindow(remote, remainder);
    }

    if (!this.pathService.isTrulyLocalPath(path) && !path.startsWith('saf://')) {
      const { remote, path: relativePath } = this.pathService.splitFsPath(path);
      if (remote) {
        return this.nautilusService.newNautilusWindow(remote, relativePath);
      }
    }

    if (isMobile()) {
      const isInternalAppPath =
        path.startsWith('/data/') ||
        path.startsWith('/data/user/') ||
        path.includes('com.rclone.manager');
      if (isInternalAppPath) {
        const { remote, remainder } = this.pathService.splitLocalPath(path);
        return this.nautilusService.newNautilusWindow(remote, remainder);
      }
    }

    try {
      return await this.invokeCommand('open_in_files', { path });
    } catch (error) {
      const translatedError = this.backendTranslation.translateBackendMessage(error);
      this.notificationService.showError(
        this.translate.instant('home.errors.openFailed', { name: path }) + ': ' + translatedError
      );
      throw error;
    }
  }
}
