import { DestroyRef, inject, Injectable } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TranslateService } from '@ngx-translate/core';
import { ApiClientService } from '../platform/api-client.service';
import { EventListenersService } from './event-listeners.service';
import { NotificationService } from '../../ui/notification.service';
import { NautilusService } from '../../ui/nautilus.service';
import { FlowOverlayService } from '../../ui/flow-overlay.service';
import { MainUiOverlayService } from '../../ui/main-ui-overlay.service';
import { ActiveOperationsSummary, SystemPowerAction } from '@app/types';

@Injectable({ providedIn: 'root' })
export class AppLifecycleService {
  private readonly eventListenersService = inject(EventListenersService);
  private readonly notificationService = inject(NotificationService);
  private readonly translate = inject(TranslateService);
  private readonly apiClient = inject(ApiClientService);
  private readonly nautilusService = inject(NautilusService);
  private readonly flowOverlayService = inject(FlowOverlayService);
  private readonly mainUiOverlayService = inject(MainUiOverlayService);
  private readonly destroyRef = inject(DestroyRef);

  private exitListenerInitialized = false;
  private isConfirmModalOpen = false;

  public initialize(): void {
    if (this.exitListenerInitialized) {
      return;
    }

    this.exitListenerInitialized = true;

    // Do not handle app exit in secondary standalone windows
    if (this.isStandaloneWindow()) {
      return;
    }

    // Check if window was created or restored due to a pending exit request
    void this.checkPendingExit();

    this.eventListenersService
      .listenToAppExitRequested()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(summary => {
        void this.promptExitConfirmation(summary);
      });
  }

  private async checkPendingExit(): Promise<void> {
    try {
      const summary = await this.apiClient.invoke<ActiveOperationsSummary | null>(
        'check_pending_app_exit'
      );
      if (summary?.hasActiveOperations) {
        await this.promptExitConfirmation(summary);
      }
    } catch {
      // Ignore if not supported or failed
    }
  }

  private async promptExitConfirmation(summary: ActiveOperationsSummary): Promise<void> {
    if (this.isConfirmModalOpen) {
      return;
    }
    this.isConfirmModalOpen = true;

    try {
      const confirmed = await this.notificationService.confirmModal(
        'app.shutdown.confirmTitle',
        this.translate.instant('app.shutdown.confirmMessage', {
          jobs: summary.activeJobsCount,
          mounts: summary.activeMountsCount,
          serves: summary.activeServesCount,
        }),
        'app.shutdown.stopAndQuit',
        'common.cancel',
        { icon: 'warning', color: 'warn' }
      );

      if (confirmed) {
        await this.shutdownApp();
      }
    } finally {
      this.isConfirmModalOpen = false;
    }
  }

  async shutdownApp(): Promise<void> {
    await this.apiClient.invoke('shutdown_app');
  }

  async relaunchApp(): Promise<void> {
    await this.apiClient.invoke('relaunch_app');
  }

  async executeSystemPower(action: SystemPowerAction): Promise<void> {
    await this.apiClient.invoke('execute_system_power', { action });
  }

  private isStandaloneWindow(): boolean {
    return (
      this.nautilusService.isStandaloneWindow() ||
      this.flowOverlayService.isStandaloneWindow() ||
      this.mainUiOverlayService.isStandaloneWindow()
    );
  }
}
