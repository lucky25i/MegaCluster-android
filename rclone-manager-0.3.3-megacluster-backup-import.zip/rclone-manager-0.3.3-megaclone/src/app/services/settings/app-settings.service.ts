import { computed, inject, Injectable, signal } from '@angular/core';
import { TauriBaseService } from '../infrastructure/platform/tauri-base.service';
import { firstValueFrom, Observable } from 'rxjs';
import { map, distinctUntilChanged, filter, first } from 'rxjs/operators';
import {
  SettingMetadata,
  SettingsChangeEvent,
  BackendsRemotesLayout,
  ConfigValue,
} from '@app/types';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';
import { EventListenersService } from '../infrastructure/system/event-listeners.service';

@Injectable({
  providedIn: 'root',
})
export class AppSettingsService extends TauriBaseService {
  private eventListeners = inject(EventListenersService);

  private readonly _options = signal<Record<string, SettingMetadata> | null>(null);
  public readonly options = this._options.asReadonly();
  public readonly options$ = toObservable(this._options);

  public readonly isTrayAvailable = computed(() => {
    const setting = this._options()?.['general.tray_enabled'];
    return setting?.value === true;
  });

  constructor() {
    super();

    this.eventListeners
      .listenToSystemSettingsChanged()
      .pipe(takeUntilDestroyed())
      .subscribe(payload => {
        this.updateStateFromEvent(payload);
      });

    this.setupLanguageChangeListener();
  }

  async loadSettings(): Promise<void> {
    if (this._options()) {
      return;
    }
    try {
      const response = await this.invokeCommand<{ options: Record<string, SettingMetadata> }>(
        'load_settings'
      );
      this._options.set(response.options);
    } catch (error) {
      console.error('Failed to load settings:', error);
      this.notificationService.showError(this.translate.instant('settings.loadFailed'));
    }
  }

  /**
   * Apply the saved UI language to the translation service
   */
  async applySavedLanguage(defaultLang = 'en-US'): Promise<string> {
    const savedLang = (await this.getSettingValue<string>('general.language')) || defaultLang;

    if (!this.translate.getCurrentLang() || savedLang !== this.translate.getCurrentLang()) {
      this.translate.use(savedLang);
    }

    return savedLang;
  }

  selectSetting(key: string): Observable<SettingMetadata | undefined> {
    return this.options$.pipe(
      filter((options): options is Record<string, SettingMetadata> => options !== null),
      map(options => options[key]),
      distinctUntilChanged()
    );
  }

  async getSettingValue<T = unknown>(key: string): Promise<T | undefined> {
    // Fast path: once settings are loaded (the common case after app boot),
    // skip the observable dance entirely and read synchronously.
    const current = this._options();
    if (current) {
      return current[key]?.value as T | undefined;
    }
    const setting$ = this.options$.pipe(
      filter(options => options !== null),
      first(),
      map(options => options?.[key]?.value as T)
    );
    return firstValueFrom(setting$);
  }

  async saveSetting(category: string, key: string, value: unknown): Promise<void> {
    return this.invokeCommand('save_setting', { category, key, value });
  }

  async resetSetting(category: string, key: string): Promise<unknown> {
    const fullKey = `${category}.${key}`;
    return this.invokeWithNotification(
      'reset_setting',
      { category, key },
      {
        errorKey: 'settings.resetFailed',
        errorParams: { key: fullKey },
      }
    );
  }

  async resetSettings(): Promise<boolean> {
    const confirmed = await this.notificationService.confirmModal(
      this.translate.instant('settings.resetAll.title'),
      this.translate.instant('settings.resetAll.message'),
      'common.yes',
      'common.no',
      {
        icon: 'rotate-right',
        color: 'warn',
      }
    );

    if (confirmed) {
      await this.invokeWithNotification('reset_settings', undefined, {
        successKey: 'settings.resetSuccess',
      });
      return true;
    }
    return false;
  }

  /**
   * Merges incoming changes from backend events into the current state.
   */
  private updateStateFromEvent(payload: SettingsChangeEvent): void {
    const currentState = this._options();
    if (!currentState) return;

    if (payload.category === '*' && payload.key === '*') {
      // Matches the resetAll settings event payload shape
      this._options.set(null);
      this.loadSettings();
      void this.applySavedLanguage();
      return;
    }

    const fullKey = `${payload.category}.${payload.key}`;
    const newValue = payload.value;

    if (currentState[fullKey]) {
      // Only update if the value actually changed
      if (currentState[fullKey].value !== newValue) {
        const newState: Record<string, SettingMetadata> = {
          ...currentState,
          [fullKey]: {
            ...currentState[fullKey],
            value: newValue as ConfigValue,
          },
        };
        this._options.set(newState);
      }
    }
  }

  private setupLanguageChangeListener(): void {
    this.eventListeners
      .listenToLanguageChanged()
      .pipe(takeUntilDestroyed())
      .subscribe(lang => {
        if (lang !== this.translate.getCurrentLang()) {
          this.translate.use(lang);
        }
      });
  }

  /**
   * Save remote-specific settings
   */
  async saveRemoteSettings(remoteName: string, settings: Record<string, unknown>): Promise<void> {
    return this.invokeCommand('save_remote_settings', { remoteName, settings });
  }

  /**
   * Get remote settings
   */
  async getRemoteSettings(): Promise<Record<string, Record<string, unknown>>> {
    return this.invokeCommand('get_settings');
  }

  /**
   * Reset settings for a specific remote
   */
  async resetRemoteSettings(remoteName: string): Promise<void> {
    await this.invokeWithNotification(
      'delete_remote_settings',
      { remoteName },
      {
        successKey: 'settings.remoteResetSuccess',
        successParams: { remote: remoteName },
      }
    );
  }

  /**
   * Remove a backend's remote layout configuration
   */
  async removeBackendLayout(backendName: string): Promise<void> {
    const allLayouts =
      (await this.getSettingValue<BackendsRemotesLayout>('runtime.remote_layouts')) || {};

    if (allLayouts[backendName]) {
      delete allLayouts[backendName];
      await this.saveSetting('runtime', 'remote_layouts', allLayouts);
    }
  }
}
