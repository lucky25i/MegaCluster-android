Generate the standard Gradle wrapper with Gradle 8.9 before local builds. GitHub Actions can also be adjusted to use a setup-gradle action.
